export type CurrencyCode = 'NPR' | 'USD' | 'INR' | 'GBP' | 'EUR' | 'AUD' | 'CAD';

export interface User {
  id: string;
  name: string;
  email: string;
  country: string;
  currency: CurrencyCode;
  ageRange: string;
  occupation?: string;
  riskTolerance: 'conservative' | 'moderate' | 'aggressive';
  investmentHorizonYears: number;
  createdAt: string;
}

export type SheetType = 'personal' | 'family' | 'friend' | 'scenario' | 'other';

export interface FinancialSheet {
  id: string;
  userId: string;
  name: string;
  type: SheetType;
  description?: string;
  isDefault: boolean;
  currency: CurrencyCode;
  createdAt: string;
  membersCount?: number;
}

export type IncomeFrequency = 'monthly' | 'yearly' | 'weekly' | 'biweekly';
export type IncomeCategory = 'salary' | 'freelance' | 'business' | 'rental' | 'dividend' | 'other';

export interface IncomeSource {
  id: string;
  sheetId: string;
  title: string;
  amount: number;
  frequency: IncomeFrequency;
  category: IncomeCategory;
  notes?: string;
}

export type ExpenseFrequency = 'monthly' | 'yearly' | 'weekly';
export type ExpenseCategory =
  | 'housing'
  | 'food'
  | 'transportation'
  | 'utilities'
  | 'education'
  | 'healthcare'
  | 'family'
  | 'entertainment'
  | 'shopping'
  | 'subscriptions'
  | 'insurance'
  | 'debt_payment'
  | 'other';

export interface Expense {
  id: string;
  sheetId: string;
  title: string;
  amount: number;
  frequency: ExpenseFrequency;
  category: ExpenseCategory;
  isFixed: boolean;
  notes?: string;
}

export type LoanType = 'education' | 'home' | 'vehicle' | 'personal' | 'credit_card' | 'other';

export interface Debt {
  id: string;
  sheetId: string;
  name: string;
  principal: number;
  remainingBalance: number;
  interestRate: number; // e.g. 9.5 for 9.5%
  monthlyPayment: number;
  remainingMonths: number;
  loanType: LoanType;
}

export type AssetType = 'cash' | 'bank' | 'emergency_fund' | 'investments' | 'other';

export interface SavingsAsset {
  id: string;
  sheetId: string;
  type: AssetType;
  title: string;
  amount: number;
  institution?: string;
}

export interface FinancialGoal {
  id: string;
  sheetId: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string; // YYYY-MM-DD
  priority: 'high' | 'medium' | 'low';
  category: string;
  monthlyAllocated?: number;
}

export interface Transaction {
  id: string;
  sheetId: string;
  amount: number;
  type: 'income' | 'expense' | 'transfer';
  category: string;
  date: string; // YYYY-MM-DD
  description: string;
  paymentMethod?: string;
  isRecurring?: boolean;
}

export interface BudgetLimit {
  id: string;
  sheetId: string;
  category: ExpenseCategory | string;
  monthlyLimit: number;
}

export interface HealthScoreBreakdownItem {
  category: string;
  score: number;
  maxScore: number;
  status: 'OPTIMAL' | 'GOOD' | 'FAIR' | 'ATTENTION';
  detail: string;
  benchmark: string;
}

export interface HealthScoreResult {
  overall: number; // 0-100
  status: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'NEEDS_ATTENTION';
  emergencyScore: number; // /25
  debtScore: number;      // /20
  savingsScore: number;   // /20
  expenseScore: number;   // /15
  goalScore: number;      // /10
  investmentScore: number;// /10
  explanation: string;
  breakdown: HealthScoreBreakdownItem[];
}

export interface FinancialResilienceResult {
  overall: number; // 0-100
  status: 'HIGH_RESILIENCE' | 'MODERATE' | 'VULNERABLE' | 'CRITICAL';
  survivalMonthsNoIncome: number;
  debtPressure: 'LOW' | 'MODERATE' | 'HIGH';
  unexpectedExpenseCapacity: number;
  explanation: string;
  breakdown: { label: string; score: number; maxScore: number; detail: string }[];
}

export interface MoneyLeakItem {
  id: string;
  category: string;
  title: string;
  description: string;
  monthlyCost: number;
  annualImpact: number;
  severity: 'low' | 'medium' | 'high';
  actionSuggestion: string;
}

export interface FinancialReminderItem {
  id: string;
  title: string;
  amount: number;
  dueDate: string;
  category: string;
  type: 'bill' | 'sip' | 'goal' | 'loan' | 'salary';
  isCompleted: boolean;
}

export interface FinancialProfileCalculated {
  totalMonthlyIncome: number;
  totalMonthlyExpenses: number;
  fixedExpenses: number;
  variableExpenses: number;
  totalMonthlyDebt: number;
  totalDebtBalance: number;
  monthlySurplus: number;
  savingsRate: number; // percentage, e.g. 31.25
  expenseRatio: number; // expenses / income %
  debtToIncomeRatio: number; // debt / income %
  emergencyFundTotal: number;
  emergencyFundCoverageMonths: number;
  totalLiquidSavings: number;
  totalAssets: number;
  totalLiabilities: number;
  netWorth: number;
  safeDailySpending: number;
  daysPassedInMonth: number;
  daysRemainingInMonth: number;
  monthCompletionPct: number;
  healthScore: HealthScoreResult;
  resilienceScore: FinancialResilienceResult;
  moneyLeaks: MoneyLeakItem[];
  upcomingReminders: FinancialReminderItem[];
  needsWantsSavingsSplit: {
    needs: number; // percentage
    wants: number; // percentage
    savings: number; // percentage
    debt: number; // percentage
  };
}

export interface AffordabilityAnalysis {
  status: 'affordable' | 'trade_off' | 'not_recommended';
  verdictTitle: string;
  reason: string;
  details: {
    price: number;
    monthlySurplus: number;
    surplusImpactPercent: number;
    emergencyMonthsLeft: number;
    goalDelayEstimateMonths: number;
  };
  recommendations: string[];
  timingOptions: {
    option: 'buy_now' | 'wait_1m' | 'wait_3m' | 'save_monthly';
    title: string;
    description: string;
    impact: string;
  }[];
}

export interface SIPProjectionYear {
  year: number;
  contributed: number;
  interestEarned: number;
  balance: number;
}

export interface SIPProjectionResult {
  monthlyContribution: number;
  durationYears: number;
  expectedReturnRate: number;
  initialInvestment: number;
  totalContributed: number;
  estimatedGrowth: number;
  estimatedFutureValue: number;
  yearlyBreakdown: SIPProjectionYear[];
  disclaimer: string;
}

export interface WhatIfScenarioAdjustment {
  incomeChangeMonthly?: number;
  rentChangeMonthly?: number;
  newLoanAmount?: number;
  newLoanRate?: number;
  newLoanMonths?: number;
  newSipMonthly?: number;
}

export interface WhatIfScenarioResult {
  originalSurplus: number;
  newSurplus: number;
  surplusDifference: number;
  originalSavingsRate: number;
  newSavingsRate: number;
  impactAnalysis: string[];
  recommendation: string;
}

export interface StressTestScenario {
  id: string;
  title: string;
  type: 'job_loss' | 'salary_drop' | 'emergency_expense' | 'rent_hike';
  description: string;
  survivalMonths: number;
  cashExhaustionMonths: { month: number; remainingBuffer: number; status: string }[];
  monthlyShortfall: number;
  recommendations: string[];
}

export interface TimeMachineProjection {
  horizon: '3m' | '6m' | '1y' | '3y' | '5y' | '10y';
  months: number;
  currentPath: { balance: number; savings: number; netWorth: number; goalsFundedCount: number };
  optimizedPath: { balance: number; savings: number; netWorth: number; goalsFundedCount: number };
  gainDifference: number;
  keyActionPointers: string[];
}

export interface FinancialChallenge {
  id: string;
  title: string;
  daysTotal: number;
  daysCompleted: number;
  savingsTarget: number;
  active: boolean;
  badge: string;
  description: string;
}

export interface ReceiptScanResult {
  merchant: string;
  date: string;
  amount: number;
  category: string;
  items: { name: string; price: number }[];
}

export interface AIMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  actions?: {
    label: string;
    actionType: string;
    payload?: any;
  }[];
}

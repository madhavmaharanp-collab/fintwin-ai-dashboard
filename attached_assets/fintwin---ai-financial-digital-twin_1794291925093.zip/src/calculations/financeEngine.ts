import {
  IncomeSource,
  Expense,
  Debt,
  SavingsAsset,
  FinancialGoal,
  Transaction,
  FinancialProfileCalculated,
  HealthScoreResult,
  HealthScoreBreakdownItem,
  FinancialResilienceResult,
  MoneyLeakItem,
  FinancialReminderItem,
  AffordabilityAnalysis,
  SIPProjectionResult,
  SIPProjectionYear,
  WhatIfScenarioAdjustment,
  WhatIfScenarioResult,
  StressTestScenario,
  TimeMachineProjection,
  CurrencyCode,
} from '../types/finance';

/**
 * Currency Symbol & Formatter
 */
export const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  NPR: 'रू',
  USD: '$',
  INR: '₹',
  GBP: '£',
  EUR: '€',
  AUD: 'A$',
  CAD: 'C$',
};

export function formatCurrency(amount: number, currency: CurrencyCode = 'NPR'): string {
  const rounded = Math.round(amount);
  const formattedNumber = new Intl.NumberFormat('en-US').format(rounded);
  return `${currency} ${formattedNumber}`;
}

export function formatCurrencyCompact(amount: number, currency: CurrencyCode = 'NPR'): string {
  if (Math.abs(amount) >= 1_000_000) {
    return `${currency} ${(amount / 1_000_000).toFixed(1)}M`;
  }
  if (Math.abs(amount) >= 1_000) {
    return `${currency} ${(amount / 1_000).toFixed(1)}k`;
  }
  return formatCurrency(amount, currency);
}

/**
 * Convert income amount to normalized monthly value
 */
export function convertIncomeToMonthly(amount: number, frequency: IncomeSource['frequency']): number {
  switch (frequency) {
    case 'yearly':
      return amount / 12;
    case 'weekly':
      return (amount * 52) / 12;
    case 'biweekly':
      return (amount * 26) / 12;
    case 'monthly':
    default:
      return amount;
  }
}

/**
 * Convert expense amount to normalized monthly value
 */
export function convertExpenseToMonthly(amount: number, frequency: Expense['frequency']): number {
  switch (frequency) {
    case 'yearly':
      return amount / 12;
    case 'weekly':
      return (amount * 52) / 12;
    case 'monthly':
    default:
      return amount;
  }
}

/**
 * Calculate total monthly income across all sources
 */
export function calculateMonthlyIncome(incomes: IncomeSource[]): number {
  return incomes.reduce((sum, item) => sum + convertIncomeToMonthly(item.amount, item.frequency), 0);
}

/**
 * Calculate total monthly expenses with fixed vs variable breakdown
 */
export function calculateMonthlyExpenses(expenses: Expense[]): {
  total: number;
  fixed: number;
  variable: number;
  byCategory: Record<string, number>;
} {
  let total = 0;
  let fixed = 0;
  let variable = 0;
  const byCategory: Record<string, number> = {};

  for (const exp of expenses) {
    const monthlyAmt = convertExpenseToMonthly(exp.amount, exp.frequency);
    total += monthlyAmt;
    if (exp.isFixed) {
      fixed += monthlyAmt;
    } else {
      variable += monthlyAmt;
    }
    byCategory[exp.category] = (byCategory[exp.category] || 0) + monthlyAmt;
  }

  return { total, fixed, variable, byCategory };
}

/**
 * Calculate monthly debt obligations & total principal debt balance
 */
export function calculateMonthlyDebt(debts: Debt[]): {
  totalMonthlyPayment: number;
  totalRemainingBalance: number;
} {
  let totalMonthlyPayment = 0;
  let totalRemainingBalance = 0;

  for (const debt of debts) {
    totalMonthlyPayment += debt.monthlyPayment;
    totalRemainingBalance += debt.remainingBalance;
  }

  return { totalMonthlyPayment, totalRemainingBalance };
}

/**
 * Calculate monthly surplus (free cashflow)
 */
export function calculateMonthlySurplus(
  monthlyIncome: number,
  monthlyExpenses: number,
  monthlyDebt: number
): number {
  return Math.max(0, monthlyIncome - monthlyExpenses - monthlyDebt);
}

/**
 * Calculate savings rate percentage
 */
export function calculateSavingsRate(monthlySurplus: number, monthlyIncome: number): number {
  if (monthlyIncome <= 0) return 0;
  return Math.min(100, Math.max(0, (monthlySurplus / monthlyIncome) * 100));
}

/**
 * Calculate emergency fund coverage in months of living expenses
 */
export function calculateEmergencyFundCoverage(
  emergencyFundTotal: number,
  monthlyExpenses: number
): number {
  if (monthlyExpenses <= 0) return emergencyFundTotal > 0 ? 12 : 0;
  return Number((emergencyFundTotal / monthlyExpenses).toFixed(1));
}

/**
 * Calculate loan EMI payment based on standard annuity formula
 */
export function calculateLoanPayment(principal: number, annualRatePct: number, months: number): number {
  if (principal <= 0 || months <= 0) return 0;
  if (annualRatePct <= 0) return principal / months;

  const monthlyRate = annualRatePct / 100 / 12;
  const factor = Math.pow(1 + monthlyRate, months);
  return (principal * monthlyRate * factor) / (factor - 1);
}

/**
 * Calculate Month Progress & Safe Daily Spending
 */
export function calculateMonthProgress(): {
  daysPassed: number;
  daysRemaining: number;
  totalDays: number;
  completionPct: number;
} {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const totalDays = new Date(year, month + 1, 0).getDate();
  const daysPassed = now.getDate();
  const daysRemaining = Math.max(1, totalDays - daysPassed);
  const completionPct = Math.round((daysPassed / totalDays) * 100);

  return {
    daysPassed,
    daysRemaining,
    totalDays,
    completionPct,
  };
}

export function calculateSafeDailySpending(monthlySurplus: number, daysRemaining: number): number {
  if (daysRemaining <= 0) return 0;
  return Math.max(0, Math.round(monthlySurplus / daysRemaining));
}

/**
 * FinTwin Money Leak Detector (Section 20 spec)
 */
export function detectMoneyLeaks(
  expenses: Expense[],
  transactions: Transaction[]
): MoneyLeakItem[] {
  const leaks: MoneyLeakItem[] = [];

  // Check food/dining vs groceries
  const diningExp = expenses.find((e) => e.category === 'entertainment' || e.title.toLowerCase().includes('dining'));
  const foodExp = expenses.find((e) => e.category === 'food');

  if (diningExp && foodExp && diningExp.amount > foodExp.amount * 0.5) {
    const extra = Math.round(diningExp.amount * 0.3);
    leaks.push({
      id: 'leak-dining',
      category: 'Dining & Cafes',
      title: 'High Dining Out Ratio Detected',
      description: `Dining out is currently ${Math.round((diningExp.amount / foodExp.amount) * 100)}% of your grocery budget.`,
      monthlyCost: extra,
      annualImpact: extra * 12,
      severity: 'medium',
      actionSuggestion: 'Batch cook twice a week to redirect ~NPR 2,000/mo into emergency reserves.',
    });
  }

  // Check subscription accumulation
  const subExpenses = expenses.filter((e) => e.category === 'subscriptions');
  const totalSubs = subExpenses.reduce((sum, s) => sum + s.amount, 0);
  if (totalSubs > 3000 || subExpenses.length >= 3) {
    const savingsPotential = Math.round(totalSubs * 0.4);
    leaks.push({
      id: 'leak-subscriptions',
      category: 'Subscriptions',
      title: 'Subscription Creep Accumulated',
      description: `You have ${subExpenses.length} recurring subscription tools totaling NPR ${totalSubs.toLocaleString()}/mo.`,
      monthlyCost: savingsPotential,
      annualImpact: savingsPotential * 12,
      severity: 'low',
      actionSuggestion: 'Audit and consolidate unused cloud tools and streaming apps.',
    });
  }

  // Check variable friction
  const variableExpenses = expenses.filter((e) => !e.isFixed);
  const totalVariable = variableExpenses.reduce((sum, v) => sum + v.amount, 0);
  if (totalVariable > 20000) {
    const trim = Math.round(totalVariable * 0.15);
    leaks.push({
      id: 'leak-variable',
      category: 'Discretionary Shopping',
      title: 'Flexible Spending Friction',
      description: `Variable categories absorb NPR ${totalVariable.toLocaleString()}/mo without strict caps.`,
      monthlyCost: trim,
      annualImpact: trim * 12,
      severity: 'medium',
      actionSuggestion: 'Set category spending caps to capture NPR 3,000+ surplus monthly.',
    });
  }

  return leaks;
}

/**
 * Deterministic Financial Resilience Score (0 - 100) (Section 12 spec)
 */
export function calculateFinancialResilienceScore(params: {
  emergencyCoverageMonths: number;
  debtToIncomeRatio: number;
  savingsRate: number;
  monthlySurplus: number;
  totalLiquidSavings: number;
  essentialMonthlyExpenses: number;
}): FinancialResilienceResult {
  const {
    emergencyCoverageMonths,
    debtToIncomeRatio,
    savingsRate,
    totalLiquidSavings,
    essentialMonthlyExpenses,
  } = params;

  let score = 0;
  const breakdown: { label: string; score: number; maxScore: number; detail: string }[] = [];

  // 1. Cash Runway (Max 40 points)
  let runwayScore = 0;
  if (emergencyCoverageMonths >= 6) {
    runwayScore = 40;
  } else if (emergencyCoverageMonths >= 3) {
    runwayScore = 28;
  } else if (emergencyCoverageMonths >= 1) {
    runwayScore = 15;
  } else {
    runwayScore = 5;
  }
  score += runwayScore;
  breakdown.push({
    label: 'Survival Runway Without Income',
    score: runwayScore,
    maxScore: 40,
    detail: `${emergencyCoverageMonths} months of essential living costs covered in cash.`,
  });

  // 2. Debt Exposure (Max 30 points)
  let debtScore = 0;
  let debtPressure: FinancialResilienceResult['debtPressure'] = 'LOW';
  if (debtToIncomeRatio <= 10) {
    debtScore = 30;
    debtPressure = 'LOW';
  } else if (debtToIncomeRatio <= 25) {
    debtScore = 22;
    debtPressure = 'LOW';
  } else if (debtToIncomeRatio <= 40) {
    debtScore = 14;
    debtPressure = 'MODERATE';
  } else {
    debtScore = 4;
    debtPressure = 'HIGH';
  }
  score += debtScore;
  breakdown.push({
    label: 'Debt Service Resistance',
    score: debtScore,
    maxScore: 30,
    detail: `Debt takes ${debtToIncomeRatio.toFixed(1)}% of monthly earnings (${debtPressure} pressure).`,
  });

  // 3. Shock Absorption (Max 30 points)
  let shockScore = 0;
  const unexpectedCapacity = totalLiquidSavings;
  if (unexpectedCapacity >= essentialMonthlyExpenses * 3 && savingsRate >= 20) {
    shockScore = 30;
  } else if (unexpectedCapacity >= essentialMonthlyExpenses * 1.5) {
    shockScore = 20;
  } else if (unexpectedCapacity >= 20000) {
    shockScore = 12;
  } else {
    shockScore = 4;
  }
  score += shockScore;
  breakdown.push({
    label: 'Sudden Emergency Expense Capacity',
    score: shockScore,
    maxScore: 30,
    detail: `Can absorb an immediate NPR ${unexpectedCapacity.toLocaleString()} shock without borrowing.`,
  });

  let status: FinancialResilienceResult['status'] = 'CRITICAL';
  let explanation = '';
  if (score >= 85) {
    status = 'HIGH_RESILIENCE';
    explanation = 'Exceptional resilience: You can navigate economic downturns or job changes for 6+ months with low distress.';
  } else if (score >= 70) {
    status = 'MODERATE';
    explanation = 'Good resilience: You can manage moderate unexpected events, but aim for a 6-month buffer for total security.';
  } else if (score >= 50) {
    status = 'VULNERABLE';
    explanation = 'Vulnerable cushion: An income disruption lasting beyond 60 days would cause acute liquidity strain.';
  } else {
    status = 'CRITICAL';
    explanation = 'Critical exposure: Minimal reserves. A single unexpected expense could force high-interest borrowing.';
  }

  return {
    overall: score,
    status,
    survivalMonthsNoIncome: emergencyCoverageMonths,
    debtPressure,
    unexpectedExpenseCapacity: unexpectedCapacity,
    explanation,
    breakdown,
  };
}

/**
 * Deterministic Transparent Financial Health Score (0 - 100)
 */
export function calculateFinancialHealthScore(params: {
  monthlyIncome: number;
  monthlyExpenses: number;
  monthlyDebt: number;
  monthlySurplus: number;
  savingsRate: number;
  emergencyFundTotal: number;
  emergencyFundCoverageMonths: number;
  debtToIncomeRatio: number;
  goals: FinancialGoal[];
}): HealthScoreResult {
  const {
    monthlyIncome,
    monthlyExpenses,
    monthlyDebt,
    savingsRate,
    emergencyFundCoverageMonths,
    debtToIncomeRatio,
    goals,
  } = params;

  const breakdown: HealthScoreBreakdownItem[] = [];

  // 1. Emergency Fund (Max 25 points)
  let emergencyScore = 0;
  let emergencyStatus: HealthScoreBreakdownItem['status'] = 'ATTENTION';
  let emergencyDetail = '';

  if (emergencyFundCoverageMonths >= 6) {
    emergencyScore = 25;
    emergencyStatus = 'OPTIMAL';
    emergencyDetail = `Strong safety net: ${emergencyFundCoverageMonths} months of expenses reserved.`;
  } else if (emergencyFundCoverageMonths >= 3) {
    emergencyScore = 18;
    emergencyStatus = 'GOOD';
    emergencyDetail = `Good cushion: ${emergencyFundCoverageMonths} months. Aim for 6 months for complete security.`;
  } else if (emergencyFundCoverageMonths >= 1) {
    emergencyScore = 10;
    emergencyStatus = 'FAIR';
    emergencyDetail = `Basic buffer: ${emergencyFundCoverageMonths} months. Highly vulnerable to unexpected shocks.`;
  } else {
    emergencyScore = 3;
    emergencyStatus = 'ATTENTION';
    emergencyDetail = `Critical: Less than 1 month of expenses saved. Prioritize building an emergency fund.`;
  }

  breakdown.push({
    category: 'Emergency Fund',
    score: emergencyScore,
    maxScore: 25,
    status: emergencyStatus,
    detail: emergencyDetail,
    benchmark: '3 - 6+ months of expenses',
  });

  // 2. Debt-To-Income (Max 20 points)
  let debtScore = 0;
  let debtStatus: HealthScoreBreakdownItem['status'] = 'OPTIMAL';
  let debtDetail = '';

  if (monthlyDebt === 0) {
    debtScore = 20;
    debtStatus = 'OPTIMAL';
    debtDetail = 'Debt-free: Zero monthly loan obligations.';
  } else if (debtToIncomeRatio <= 15) {
    debtScore = 18;
    debtStatus = 'OPTIMAL';
    debtDetail = `Very low debt load: ${debtToIncomeRatio.toFixed(1)}% of income. Well managed.`;
  } else if (debtToIncomeRatio <= 30) {
    debtScore = 14;
    debtStatus = 'GOOD';
    debtDetail = `Moderate debt: ${debtToIncomeRatio.toFixed(1)}% of income. Within healthy limits.`;
  } else if (debtToIncomeRatio <= 45) {
    debtScore = 8;
    debtStatus = 'FAIR';
    debtDetail = `Elevated debt burden: ${debtToIncomeRatio.toFixed(1)}% of income. Keep close track.`;
  } else {
    debtScore = 3;
    debtStatus = 'ATTENTION';
    debtDetail = `High debt strain: ${debtToIncomeRatio.toFixed(1)}% of income going to debt service.`;
  }

  breakdown.push({
    category: 'Debt Obligations (DTI)',
    score: debtScore,
    maxScore: 20,
    status: debtStatus,
    detail: debtDetail,
    benchmark: 'Under 25-30% of income',
  });

  // 3. Savings Rate (Max 20 points)
  let savingsScore = 0;
  let savingsStatus: HealthScoreBreakdownItem['status'] = 'ATTENTION';
  let savingsDetail = '';

  if (savingsRate >= 30) {
    savingsScore = 20;
    savingsStatus = 'OPTIMAL';
    savingsDetail = `Outstanding savings discipline: saving ${savingsRate.toFixed(1)}% of income.`;
  } else if (savingsRate >= 20) {
    savingsScore = 16;
    savingsStatus = 'GOOD';
    savingsDetail = `Healthy savings habit: saving ${savingsRate.toFixed(1)}% of income.`;
  } else if (savingsRate >= 10) {
    savingsScore = 11;
    savingsStatus = 'FAIR';
    savingsDetail = `Moderate savings: saving ${savingsRate.toFixed(1)}%. Strive to reach 20%.`;
  } else if (savingsRate > 0) {
    savingsScore = 5;
    savingsStatus = 'ATTENTION';
    savingsDetail = `Low surplus: saving ${savingsRate.toFixed(1)}%. Look for expense reductions.`;
  } else {
    savingsScore = 0;
    savingsStatus = 'ATTENTION';
    savingsDetail = 'No surplus: Spending equals or exceeds total income.';
  }

  breakdown.push({
    category: 'Monthly Savings Rate',
    score: savingsScore,
    maxScore: 20,
    status: savingsStatus,
    detail: savingsDetail,
    benchmark: '20% or higher',
  });

  // 4. Spending Discipline (Max 15 points)
  const expenseRatio = monthlyIncome > 0 ? (monthlyExpenses / monthlyIncome) * 100 : 100;
  let expenseScore = 0;
  let expenseStatus: HealthScoreBreakdownItem['status'] = 'ATTENTION';
  let expenseDetail = '';

  if (expenseRatio <= 55) {
    expenseScore = 15;
    expenseStatus = 'OPTIMAL';
    expenseDetail = `Excellent expense control: Living comfortably on ${expenseRatio.toFixed(1)}% of income.`;
  } else if (expenseRatio <= 70) {
    expenseScore = 12;
    expenseStatus = 'GOOD';
    expenseDetail = `Balanced spending: Operating on ${expenseRatio.toFixed(1)}% of income.`;
  } else if (expenseRatio <= 85) {
    expenseScore = 7;
    expenseStatus = 'FAIR';
    expenseDetail = `High living costs: Consuming ${expenseRatio.toFixed(1)}% of earnings.`;
  } else {
    expenseScore = 2;
    expenseStatus = 'ATTENTION';
    expenseDetail = `Tight margins: Expenses absorb ${expenseRatio.toFixed(1)}% of income.`;
  }

  breakdown.push({
    category: 'Spending Efficiency',
    score: expenseScore,
    maxScore: 15,
    status: expenseStatus,
    detail: expenseDetail,
    benchmark: '50-65% of income',
  });

  // 5. Goal Alignment (Max 10 points)
  let goalScore = 0;
  let goalStatus: HealthScoreBreakdownItem['status'] = 'ATTENTION';
  let goalDetail = '';

  if (goals.length === 0) {
    goalScore = 2;
    goalStatus = 'FAIR';
    goalDetail = 'No defined goals yet. Setting targets gives your savings purpose.';
  } else {
    const fundedGoals = goals.filter((g) => g.currentAmount > 0);
    const avgFunding =
      goals.reduce((acc, g) => acc + (g.targetAmount > 0 ? g.currentAmount / g.targetAmount : 0), 0) /
      goals.length;

    if (avgFunding >= 0.4 || fundedGoals.length >= 2) {
      goalScore = 10;
      goalStatus = 'OPTIMAL';
      goalDetail = `Strong momentum: ${goals.length} active goals with positive funding progress.`;
    } else {
      goalScore = 6;
      goalStatus = 'GOOD';
      goalDetail = `${goals.length} defined goals. Accelerate monthly contributions to hit deadlines.`;
    }
  }

  breakdown.push({
    category: 'Goal Readiness',
    score: goalScore,
    maxScore: 10,
    status: goalStatus,
    detail: goalDetail,
    benchmark: 'At least 1-2 active funded goals',
  });

  // 6. Resilience & Investment Capacity (Max 10 points)
  let investmentScore = 0;
  let investmentStatus: HealthScoreBreakdownItem['status'] = 'ATTENTION';
  let investmentDetail = '';

  if (emergencyFundCoverageMonths >= 3 && debtToIncomeRatio < 35 && savingsRate >= 15) {
    investmentScore = 10;
    investmentStatus = 'OPTIMAL';
    investmentDetail = 'Ready to invest: Healthy reserves and predictable cashflow.';
  } else if (emergencyFundCoverageMonths >= 1.5 && savingsRate > 10) {
    investmentScore = 6;
    investmentStatus = 'GOOD';
    investmentDetail = 'Partial readiness: Continue shoring up reserves alongside micro-SIPs.';
  } else {
    investmentScore = 2;
    investmentStatus = 'ATTENTION';
    investmentDetail = 'Not ready for market risk: Prioritize building cash reserves first.';
  }

  breakdown.push({
    category: 'Resilience & Investment Capacity',
    score: investmentScore,
    maxScore: 10,
    status: investmentStatus,
    detail: investmentDetail,
    benchmark: '3+ months reserve & stable surplus',
  });

  const overall = emergencyScore + debtScore + savingsScore + expenseScore + goalScore + investmentScore;

  let status: HealthScoreResult['status'] = 'NEEDS_ATTENTION';
  let explanation = '';

  if (overall >= 85) {
    status = 'EXCELLENT';
    explanation =
      'Outstanding financial health. You possess high liquidity, minimal debt friction, and strong savings capacity.';
  } else if (overall >= 70) {
    status = 'GOOD';
    explanation =
      'Solid financial foundation. Your income comfortably covers living costs and allows purposeful goal contributions.';
  } else if (overall >= 50) {
    status = 'FAIR';
    explanation =
      'Moderate financial stability. Cash reserves or debt payments leave narrower margins than ideal.';
  } else {
    status = 'NEEDS_ATTENTION';
    explanation =
      'High vulnerability. Build an emergency reserve and restructure expenses to protect your future.';
  }

  return {
    overall,
    status,
    emergencyScore,
    debtScore,
    savingsScore,
    expenseScore,
    goalScore,
    investmentScore,
    explanation,
    breakdown,
  };
}

/**
 * Compute Complete Financial Digital Twin Profile
 */
export function buildFinancialProfile(data: {
  incomes: IncomeSource[];
  expenses: Expense[];
  debts: Debt[];
  savings: SavingsAsset[];
  goals: FinancialGoal[];
  transactions?: Transaction[];
}): FinancialProfileCalculated {
  const totalMonthlyIncome = calculateMonthlyIncome(data.incomes);
  const { total: totalMonthlyExpenses, fixed: fixedExpenses, variable: variableExpenses } =
    calculateMonthlyExpenses(data.expenses);
  const { totalMonthlyPayment: totalMonthlyDebt, totalRemainingBalance: totalDebtBalance } =
    calculateMonthlyDebt(data.debts);

  const monthlySurplus = calculateMonthlySurplus(
    totalMonthlyIncome,
    totalMonthlyExpenses,
    totalMonthlyDebt
  );
  const savingsRate = calculateSavingsRate(monthlySurplus, totalMonthlyIncome);

  const expenseRatio = totalMonthlyIncome > 0 ? (totalMonthlyExpenses / totalMonthlyIncome) * 100 : 0;
  const debtToIncomeRatio =
    totalMonthlyIncome > 0 ? (totalMonthlyDebt / totalMonthlyIncome) * 100 : 0;

  // Calculate liquid savings & emergency funds
  const emergencyFundTotal = data.savings
    .filter((s) => s.type === 'emergency_fund' || s.title.toLowerCase().includes('emergency'))
    .reduce((sum, s) => sum + s.amount, 0);

  const totalLiquidSavings = data.savings.reduce((sum, s) => sum + s.amount, 0);

  const emergencyFundCoverageMonths = calculateEmergencyFundCoverage(
    emergencyFundTotal > 0 ? emergencyFundTotal : totalLiquidSavings * 0.7,
    totalMonthlyExpenses
  );

  // Net worth calculation
  const totalAssets = totalLiquidSavings + data.goals.reduce((acc, g) => acc + g.currentAmount, 0);
  const totalLiabilities = totalDebtBalance;
  const netWorth = totalAssets - totalLiabilities;

  // Month progress
  const monthProgress = calculateMonthProgress();
  const safeDailySpending = calculateSafeDailySpending(monthlySurplus, monthProgress.daysRemaining);

  const healthScore = calculateFinancialHealthScore({
    monthlyIncome: totalMonthlyIncome,
    monthlyExpenses: totalMonthlyExpenses,
    monthlyDebt: totalMonthlyDebt,
    monthlySurplus,
    savingsRate,
    emergencyFundTotal: emergencyFundTotal > 0 ? emergencyFundTotal : totalLiquidSavings * 0.7,
    emergencyFundCoverageMonths,
    debtToIncomeRatio,
    goals: data.goals,
  });

  const resilienceScore = calculateFinancialResilienceScore({
    emergencyCoverageMonths: emergencyFundCoverageMonths,
    debtToIncomeRatio,
    savingsRate,
    monthlySurplus,
    totalLiquidSavings,
    essentialMonthlyExpenses: fixedExpenses > 0 ? fixedExpenses : totalMonthlyExpenses * 0.7,
  });

  const moneyLeaks = detectMoneyLeaks(data.expenses, data.transactions || []);

  // Upcoming reminders for Today / This week
  const upcomingReminders: FinancialReminderItem[] = [
    {
      id: 'rem-1',
      title: 'Monthly SIP Growth Deposit',
      amount: 5000,
      dueDate: 'Today',
      category: 'Investments',
      type: 'sip',
      isCompleted: false,
    },
    {
      id: 'rem-2',
      title: 'High-speed Fiber & Cloud Utilities',
      amount: 4000,
      dueDate: 'In 3 days',
      category: 'Utilities',
      type: 'bill',
      isCompleted: false,
    },
    {
      id: 'rem-3',
      title: 'Education Loan EMI Auto-Debit',
      amount: totalMonthlyDebt > 0 ? totalMonthlyDebt : 5000,
      dueDate: 'In 6 days',
      category: 'Debt',
      type: 'loan',
      isCompleted: true,
    },
  ];

  // 50/30/20 budget framework allocation
  let needsAmt = 0;
  let wantsAmt = 0;

  for (const exp of data.expenses) {
    const amt = convertExpenseToMonthly(exp.amount, exp.frequency);
    if (['housing', 'food', 'transportation', 'utilities', 'healthcare', 'insurance', 'education'].includes(exp.category)) {
      needsAmt += amt;
    } else {
      wantsAmt += amt;
    }
  }

  const denominator = totalMonthlyIncome > 0 ? totalMonthlyIncome : 1;
  const needsPct = Math.round((needsAmt / denominator) * 100);
  const wantsPct = Math.round((wantsAmt / denominator) * 100);
  const debtPct = Math.round((totalMonthlyDebt / denominator) * 100);
  const savingsPct = Math.max(0, 100 - needsPct - wantsPct - debtPct);

  return {
    totalMonthlyIncome,
    totalMonthlyExpenses,
    fixedExpenses,
    variableExpenses,
    totalMonthlyDebt,
    totalDebtBalance,
    monthlySurplus,
    savingsRate,
    expenseRatio,
    debtToIncomeRatio,
    emergencyFundTotal: emergencyFundTotal > 0 ? emergencyFundTotal : totalLiquidSavings * 0.7,
    emergencyFundCoverageMonths,
    totalLiquidSavings,
    totalAssets,
    totalLiabilities,
    netWorth,
    safeDailySpending,
    daysPassedInMonth: monthProgress.daysPassed,
    daysRemainingInMonth: monthProgress.daysRemaining,
    monthCompletionPct: monthProgress.completionPct,
    healthScore,
    resilienceScore,
    moneyLeaks,
    upcomingReminders,
    needsWantsSavingsSplit: {
      needs: Math.min(100, needsPct),
      wants: Math.min(100, wantsPct),
      savings: Math.min(100, savingsPct),
      debt: Math.min(100, debtPct),
    },
  };
}

/**
 * Financial Stress Testing (Section 23 spec)
 */
export function calculateStressTest(
  scenarioType: StressTestScenario['type'],
  profile: FinancialProfileCalculated
): StressTestScenario {
  const essentialCosts = profile.fixedExpenses > 0 ? profile.fixedExpenses : profile.totalMonthlyExpenses * 0.75;
  const cashBuffer = profile.emergencyFundTotal > 0 ? profile.emergencyFundTotal : profile.totalLiquidSavings;

  switch (scenarioType) {
    case 'job_loss': {
      // Income drops to 0, essential costs remain
      const monthlyOutflow = essentialCosts + profile.totalMonthlyDebt;
      const survivalMonths = monthlyOutflow > 0 ? Number((cashBuffer / monthlyOutflow).toFixed(1)) : 12;

      const curve: { month: number; remainingBuffer: number; status: string }[] = [];
      let rem = cashBuffer;
      for (let m = 1; m <= 6; m++) {
        rem = Math.max(0, rem - monthlyOutflow);
        curve.push({
          month: m,
          remainingBuffer: Math.round(rem),
          status: rem > 0 ? 'Surviving' : 'Exhausted',
        });
      }

      return {
        id: 'stress-job-loss',
        title: 'Complete Sudden Job Loss',
        type: 'job_loss',
        description: 'Income drops to zero while apartment rent, essential food, and debt payments continue.',
        survivalMonths,
        cashExhaustionMonths: curve,
        monthlyShortfall: monthlyOutflow,
        recommendations: [
          'Immediately pause all discretionary subscriptions and dining out.',
          'Request a temporary loan moratorium or interest-only schedule on debt obligations.',
          `Build emergency reserve up to NPR ${(monthlyOutflow * 6).toLocaleString()} for true 6-month resilience.`,
        ],
      };
    }

    case 'salary_drop': {
      const dropAmount = profile.totalMonthlyIncome * 0.2;
      const newIncome = profile.totalMonthlyIncome - dropAmount;
      const newSurplus = Math.max(0, newIncome - profile.totalMonthlyExpenses - profile.totalMonthlyDebt);

      return {
        id: 'stress-salary-drop',
        title: '20% Salary Cut Scenario',
        type: 'salary_drop',
        description: 'Monthly income contracts by 20% due to corporate restructuring or economic shifts.',
        survivalMonths: newSurplus > 0 ? 99 : Number((cashBuffer / Math.abs(newIncome - profile.totalMonthlyExpenses)).toFixed(1)),
        cashExhaustionMonths: [
          { month: 1, remainingBuffer: cashBuffer, status: 'Surplus reduced' },
          { month: 3, remainingBuffer: cashBuffer, status: 'Active' },
          { month: 6, remainingBuffer: cashBuffer, status: 'Active' },
        ],
        monthlyShortfall: dropAmount,
        recommendations: [
          `Your monthly surplus adjusts from NPR ${profile.monthlySurplus.toLocaleString()} to NPR ${Math.round(newSurplus).toLocaleString()}.`,
          'Protect core emergency fund by pausing non-urgent tech purchases.',
          'Consider freelance or supplemental weekend income to bridge the 20% gap.',
        ],
      };
    }

    case 'emergency_expense': {
      const shockAmount = 100000;
      const newBuffer = Math.max(0, cashBuffer - shockAmount);
      const remainingCoverage = profile.totalMonthlyExpenses > 0 ? Number((newBuffer / profile.totalMonthlyExpenses).toFixed(1)) : 0;

      return {
        id: 'stress-emergency',
        title: 'NPR 100,000 Unplanned Crisis Shock',
        type: 'emergency_expense',
        description: 'Urgent medical bill or major appliance/home structural failure requiring immediate cash.',
        survivalMonths: remainingCoverage,
        cashExhaustionMonths: [
          { month: 1, remainingBuffer: newBuffer, status: newBuffer > 0 ? 'Buffer Absorbed' : 'Deficit' },
          { month: 3, remainingBuffer: Math.round(newBuffer + profile.monthlySurplus * 2), status: 'Rebuilding' },
          { month: 6, remainingBuffer: Math.round(newBuffer + profile.monthlySurplus * 5), status: 'Restored' },
        ],
        monthlyShortfall: shockAmount,
        recommendations: [
          `Paying this upfront leaves NPR ${newBuffer.toLocaleString()} in liquid cash (${remainingCoverage} months buffer).`,
          `At your current monthly surplus of NPR ${profile.monthlySurplus.toLocaleString()}, it takes ~${Math.ceil(shockAmount / profile.monthlySurplus)} months to fully restore your reserve.`,
          'Review health and property insurance coverage to mitigate out-of-pocket shocks.',
        ],
      };
    }

    case 'rent_hike':
    default: {
      const rentHike = Math.round(profile.totalMonthlyExpenses * 0.12);
      const newSurplus = Math.max(0, profile.monthlySurplus - rentHike);

      return {
        id: 'stress-rent-hike',
        title: 'Rent & Living Cost Inflation (+15%)',
        type: 'rent_hike',
        description: 'Landlord increases rent or overall energy and grocery bills rise sharply.',
        survivalMonths: 99,
        cashExhaustionMonths: [
          { month: 1, remainingBuffer: cashBuffer, status: 'Cashflow compressed' },
          { month: 6, remainingBuffer: cashBuffer, status: 'Stable' },
        ],
        monthlyShortfall: rentHike,
        recommendations: [
          `Free monthly surplus contracts by NPR ${rentHike.toLocaleString()}/mo.`,
          `Annual impact on wealth building: NPR ${(rentHike * 12).toLocaleString()} less saved per year.`,
          'Audit energy and grocery shopping routines to reclaim lost margin.',
        ],
      };
    }
  }
}

/**
 * Financial Time Machine (Section 24 & 25 spec)
 * Models Current Path vs Optimized Path over 3M, 6M, 1Y, 3Y, 5Y, 10Y
 */
export function calculateTimeMachine(
  months: number,
  profile: FinancialProfileCalculated
): TimeMachineProjection {
  const currentMonthlySavings = profile.monthlySurplus;
  // In optimized path, user trims 30% of leaks and routes into high-yield / SIP earning 9% p.a.
  const trimmedLeakSurplus = profile.moneyLeaks.reduce((sum, l) => sum + l.monthlyCost, 0);
  const optimizedMonthlySavings = currentMonthlySavings + Math.max(2000, trimmedLeakSurplus);

  const baselineInterest = 0.04 / 12; // 4% basic savings rate
  const optimizedInterest = 0.09 / 12; // 9% diversified SIP / investment rate

  // Current Path Future Value
  let currentBalance = profile.totalLiquidSavings;
  for (let m = 0; m < months; m++) {
    currentBalance = (currentBalance + currentMonthlySavings) * (1 + baselineInterest);
  }

  // Optimized Path Future Value
  let optimizedBalance = profile.totalLiquidSavings;
  for (let m = 0; m < months; m++) {
    optimizedBalance = (optimizedBalance + optimizedMonthlySavings) * (1 + optimizedInterest);
  }

  const gainDifference = Math.max(0, Math.round(optimizedBalance - currentBalance));

  let horizonLabel: TimeMachineProjection['horizon'] = '1y';
  if (months === 3) horizonLabel = '3m';
  else if (months === 6) horizonLabel = '6m';
  else if (months === 12) horizonLabel = '1y';
  else if (months === 36) horizonLabel = '3y';
  else if (months === 60) horizonLabel = '5y';
  else if (months >= 120) horizonLabel = '10y';

  return {
    horizon: horizonLabel,
    months,
    currentPath: {
      balance: Math.round(currentBalance),
      savings: Math.round(currentMonthlySavings * months),
      netWorth: Math.round(currentBalance - Math.max(0, profile.totalDebtBalance - (profile.totalMonthlyDebt * months))),
      goalsFundedCount: months >= 12 ? 2 : 1,
    },
    optimizedPath: {
      balance: Math.round(optimizedBalance),
      savings: Math.round(optimizedMonthlySavings * months),
      netWorth: Math.round(optimizedBalance - Math.max(0, profile.totalDebtBalance - (profile.totalMonthlyDebt * months))),
      goalsFundedCount: months >= 12 ? 3 : 2,
    },
    gainDifference,
    keyActionPointers: [
      `Plugged NPR ${Math.round(trimmedLeakSurplus).toLocaleString()}/mo in detected spending leaks.`,
      'Automated payday transfers directly into an emergency cushion.',
      'Invested incremental surplus in a diversified SIP yielding compounding returns.',
    ],
  };
}

/**
 * Calculate SIP / Regular Investment Projection with Compound Interest
 */
export function calculateSIPProjection(
  monthlyContribution: number,
  durationYears: number,
  expectedReturnRate: number,
  initialInvestment: number = 0
): SIPProjectionResult {
  const months = durationYears * 12;
  const monthlyRate = expectedReturnRate / 100 / 12;

  let futureValueFromSIP = 0;
  if (monthlyRate > 0) {
    futureValueFromSIP =
      monthlyContribution *
      ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) *
      (1 + monthlyRate);
  } else {
    futureValueFromSIP = monthlyContribution * months;
  }

  const futureValueFromInitial =
    initialInvestment * Math.pow(1 + monthlyRate, months);

  const estimatedFutureValue = Math.round(futureValueFromSIP + futureValueFromInitial);
  const totalContributed = Math.round(initialInvestment + monthlyContribution * months);
  const estimatedGrowth = Math.max(0, estimatedFutureValue - totalContributed);

  const yearlyBreakdown: SIPProjectionYear[] = [];
  let currentBalance = initialInvestment;
  let runningContributed = initialInvestment;

  for (let year = 1; year <= durationYears; year++) {
    for (let m = 0; m < 12; m++) {
      currentBalance = (currentBalance + monthlyContribution) * (1 + monthlyRate);
      runningContributed += monthlyContribution;
    }
    yearlyBreakdown.push({
      year,
      contributed: Math.round(runningContributed),
      interestEarned: Math.max(0, Math.round(currentBalance - runningContributed)),
      balance: Math.round(currentBalance),
    });
  }

  return {
    monthlyContribution,
    durationYears,
    expectedReturnRate,
    initialInvestment,
    totalContributed,
    estimatedGrowth,
    estimatedFutureValue,
    yearlyBreakdown,
    disclaimer:
      'Illustrative projection only — not guaranteed. Returns vary with market conditions and investments can lose value.',
  };
}

/**
 * Calculate Goal Timeline & Monthly Requirement
 */
export function calculateGoalTimeline(
  targetAmount: number,
  currentAmount: number,
  monthlyContribution: number
): {
  remainingAmount: number;
  monthsRequired: number;
  weeksRequired: number;
  requiredMonthlyForDate?: (targetDateStr: string) => number;
} {
  const remaining = Math.max(0, targetAmount - currentAmount);
  const monthsRequired =
    monthlyContribution > 0 ? Math.ceil(remaining / monthlyContribution) : 999;
  const weeksRequired = Math.ceil(monthsRequired * 4.33);

  const requiredMonthlyForDate = (targetDateStr: string): number => {
    const target = new Date(targetDateStr);
    const now = new Date();
    const diffMonths = Math.max(
      1,
      (target.getFullYear() - now.getFullYear()) * 12 + (target.getMonth() - now.getMonth())
    );
    return Math.ceil(remaining / diffMonths);
  };

  return {
    remainingAmount: remaining,
    monthsRequired,
    weeksRequired,
    requiredMonthlyForDate,
  };
}

/**
 * "Can I Afford This?" Mathematical Purchase Decision Engine (Section 21 spec)
 */
export function analyzeAffordability(
  price: number,
  profile: FinancialProfileCalculated
): AffordabilityAnalysis {
  const { monthlySurplus, emergencyFundTotal, totalMonthlyExpenses } = profile;

  const monthsOfSurplus = monthlySurplus > 0 ? price / monthlySurplus : 999;
  const surplusImpactPercent =
    monthlySurplus > 0 ? Math.min(100, Math.round((price / monthlySurplus) * 100)) : 100;

  const remainingCash = Math.max(0, emergencyFundTotal - price);
  const newEmergencyCoverage =
    totalMonthlyExpenses > 0 ? remainingCash / totalMonthlyExpenses : 0;

  let status: AffordabilityAnalysis['status'] = 'not_recommended';
  let verdictTitle = '';
  let reason = '';
  const recommendations: string[] = [];

  if (price <= monthlySurplus * 0.4 && newEmergencyCoverage >= 3) {
    status = 'affordable';
    verdictTitle = 'Affordable Within Normal Cashflow';
    reason = `This purchase consumes only ${surplusImpactPercent}% of your monthly surplus without touching your core emergency reserve.`;
    recommendations.push(
      'You can pay this directly from this month’s cash surplus.',
      'Maintain your standard goal contributions as planned.'
    );
  } else if (price <= monthlySurplus * 1.5 || (price <= emergencyFundTotal * 0.25 && newEmergencyCoverage >= 3)) {
    status = 'trade_off';
    verdictTitle = 'Possible With Calculated Trade-Offs';
    reason = `This purchase requires ${monthsOfSurplus.toFixed(1)} months of your full surplus. Proceeding will temporarily pause discretionary savings.`;
    recommendations.push(
      `Consider staggering over ${Math.ceil(monthsOfSurplus)} months to avoid impacting emergency liquidity.`,
      'Postpone non-essential shopping or dining this month to offset the cost.'
    );
  } else {
    status = 'not_recommended';
    verdictTitle = 'Not Recommended Right Now';
    reason = `At this time, spending this amount would deplete your emergency cushion or exceed ${monthsOfSurplus.toFixed(1)} months of net surplus.`;
    recommendations.push(
      'Establish a dedicated savings goal and save incrementally over 4-6 months.',
      'Focus on keeping your emergency fund intact (at least 3-6 months of expenses).'
    );
  }

  // Section 21: Timing Options matrix (Buy now, Wait 1 month, Wait 3 months, Save monthly)
  const timingOptions: AffordabilityAnalysis['timingOptions'] = [
    {
      option: 'buy_now',
      title: 'Buy Today Upfront',
      description: `Immediately withdraws ${formatCurrency(price)}.`,
      impact: status === 'affordable' ? 'Safe impact' : 'Depletes reserves & delays goals',
    },
    {
      option: 'wait_1m',
      title: 'Wait 1 Month',
      description: `Allows 1 extra salary cycle to clear pending bills.`,
      impact: 'Reduces cash shock by 35%',
    },
    {
      option: 'wait_3m',
      title: 'Wait 3 Months',
      description: `Saves half the cost from upcoming monthly surplus first.`,
      impact: 'Emergency cushion stays 100% protected',
    },
    {
      option: 'save_monthly',
      title: `Save ${formatCurrency(Math.ceil(price / 6))}/mo for 6 Months`,
      description: 'Zero impact on living comfort or existing emergency reserves.',
      impact: 'Optimal recommended financial path',
    },
  ];

  return {
    status,
    verdictTitle,
    reason,
    details: {
      price,
      monthlySurplus,
      surplusImpactPercent,
      emergencyMonthsLeft: Number(newEmergencyCoverage.toFixed(1)),
      goalDelayEstimateMonths: Math.max(1, Math.ceil(monthsOfSurplus)),
    },
    recommendations,
    timingOptions,
  };
}

/**
 * What-If Financial Scenario Simulator
 */
export function calculateWhatIfScenario(
  baseProfile: FinancialProfileCalculated,
  adjustments: WhatIfScenarioAdjustment
): WhatIfScenarioResult {
  let simulatedIncome = baseProfile.totalMonthlyIncome;
  let simulatedExpenses = baseProfile.totalMonthlyExpenses;
  let simulatedDebt = baseProfile.totalMonthlyDebt;

  const impactAnalysis: string[] = [];

  if (adjustments.incomeChangeMonthly) {
    simulatedIncome += adjustments.incomeChangeMonthly;
    const sign = adjustments.incomeChangeMonthly > 0 ? '+' : '';
    impactAnalysis.push(`Income adjusted by ${sign}${adjustments.incomeChangeMonthly.toLocaleString()} monthly.`);
  }

  if (adjustments.rentChangeMonthly) {
    simulatedExpenses += adjustments.rentChangeMonthly;
    const sign = adjustments.rentChangeMonthly > 0 ? '+' : '';
    impactAnalysis.push(`Housing expenses adjusted by ${sign}${adjustments.rentChangeMonthly.toLocaleString()} monthly.`);
  }

  if (adjustments.newLoanAmount && adjustments.newLoanMonths) {
    const loanRate = adjustments.newLoanRate || 10;
    const newEmi = calculateLoanPayment(
      adjustments.newLoanAmount,
      loanRate,
      adjustments.newLoanMonths
    );
    simulatedDebt += newEmi;
    impactAnalysis.push(
      `New loan obligation added: ${Math.round(newEmi).toLocaleString()}/month for ${adjustments.newLoanMonths} months (${loanRate}% p.a.).`
    );
  }

  if (adjustments.newSipMonthly) {
    impactAnalysis.push(`Allocating ${adjustments.newSipMonthly.toLocaleString()}/month toward investment portfolio.`);
  }

  const newSurplus = Math.max(0, simulatedIncome - simulatedExpenses - simulatedDebt);
  const surplusDifference = newSurplus - baseProfile.monthlySurplus;
  const newSavingsRate = simulatedIncome > 0 ? (newSurplus / simulatedIncome) * 100 : 0;

  let recommendation = '';
  if (surplusDifference > 0) {
    recommendation = `This scenario frees up ${Math.round(surplusDifference).toLocaleString()} extra cash monthly. Consider routing 50% toward emergency reserves and 50% toward goal funding.`;
  } else if (surplusDifference < 0) {
    recommendation = `This scenario reduces your free monthly cash by ${Math.abs(Math.round(surplusDifference)).toLocaleString()}. Review discretionary spending to prevent cashflow deficits.`;
  } else {
    recommendation = 'Neutral impact on overall net cashflow.';
  }

  return {
    originalSurplus: baseProfile.monthlySurplus,
    newSurplus: Math.round(newSurplus),
    surplusDifference: Math.round(surplusDifference),
    originalSavingsRate: Number(baseProfile.savingsRate.toFixed(1)),
    newSavingsRate: Number(newSavingsRate.toFixed(1)),
    impactAnalysis,
    recommendation,
  };
}

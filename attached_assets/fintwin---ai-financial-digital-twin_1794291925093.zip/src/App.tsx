/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { DeviceFrame } from './components/layout/DeviceFrame';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { BottomNavigation, ActiveTab } from './components/layout/BottomNavigation';
import { DashboardView } from './components/dashboard/DashboardView';
import { TransactionsView } from './components/transactions/TransactionsView';
import { GoalsView } from './components/goals/GoalsView';
import { SimulatorsView } from './components/simulators/SimulatorsView';
import { AICoachView } from './components/ai/AICoachView';
import { ReportsView } from './components/reports/ReportsView';
import { FinTwinView } from './components/fintwin/FinTwinView';
import { OnboardingFlow } from './components/onboarding/OnboardingFlow';
import { LandingPage } from './components/landing/LandingPage';
import { AuthModal } from './components/auth/AuthModal';
import { HealthScoreModal } from './components/modals/HealthScoreModal';
import { CanIAffordModal } from './components/modals/CanIAffordModal';
import { AddTransactionModal } from './components/modals/AddTransactionModal';
import { CreateSheetModal } from './components/modals/CreateSheetModal';

function MainApp() {
  const { user, isLoading, demoLogin } = useAuth();
  const { data, loading: financeLoading } = useFinance();

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Mobile App Phone Frame toggle (Default to false for classic desktop workspace)
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(false);

  // Modals state
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [showHealthModal, setShowHealthModal] = useState(false);
  const [showAffordabilityModal, setShowAffordabilityModal] = useState(false);
  const [showQuickAddModal, setShowQuickAddModal] = useState(false);
  const [showCreateSheetModal, setShowCreateSheetModal] = useState(false);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F6F6F2] flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-[#173F35] text-white flex items-center justify-center font-bold text-sm">
            fT
          </div>
          <div className="text-xs font-mono text-[#626861] tracking-wider uppercase">
            Loading Ledger...
          </div>
        </div>
      </div>
    );
  }

  // If user is not logged in, show classic landing page
  if (!user) {
    return (
      <>
        <LandingPage
          onOpenAuth={(mode) => {
            setAuthMode(mode);
            setShowAuthModal(true);
          }}
          onExploreDemo={async () => {
            await demoLogin();
          }}
        />

        <AuthModal
          isOpen={showAuthModal}
          initialMode={authMode}
          onClose={() => setShowAuthModal(false)}
          onRegisterSuccess={() => {
            setShowAuthModal(false);
            setNeedsOnboarding(false);
          }}
        />
      </>
    );
  }

  // If newly registered user with 0 incomes and expenses, show onboarding
  const hasData = data.incomes.length > 0 || data.expenses.length > 0;
  if (needsOnboarding || (!hasData && !financeLoading)) {
    return (
      <OnboardingFlow
        onComplete={() => {
          setNeedsOnboarding(false);
          setActiveTab('dashboard');
        }}
      />
    );
  }

  const renderMainTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            setActiveTab={setActiveTab}
            openHealthScoreModal={() => setShowHealthModal(true)}
            openAffordabilityModal={() => setShowAffordabilityModal(true)}
            openQuickAddModal={() => setShowQuickAddModal(true)}
          />
        );
      case 'fintwin':
        return (
          <FinTwinView
            openAffordability={() => setShowAffordabilityModal(true)}
            openAddTransaction={() => setShowQuickAddModal(true)}
          />
        );
      case 'transactions':
        return <TransactionsView openAddModal={() => setShowQuickAddModal(true)} />;
      case 'goals':
        return <GoalsView />;
      case 'simulators':
        return <SimulatorsView />;
      case 'ai':
        return <AICoachView />;
      case 'reports':
        return <ReportsView />;
      default:
        return (
          <DashboardView
            setActiveTab={setActiveTab}
            openHealthScoreModal={() => setShowHealthModal(true)}
            openAffordabilityModal={() => setShowAffordabilityModal(true)}
            openQuickAddModal={() => setShowQuickAddModal(true)}
          />
        );
    }
  };

  // Render Mobile Device Frame Simulation
  if (isMobileFrame) {
    return (
      <DeviceFrame isMobileFrame={true}>
        <Navbar
          activeTab={activeTab}
          isMobileFrame={true}
          setIsMobileFrame={setIsMobileFrame}
          openCreateSheet={() => setShowCreateSheetModal(true)}
          openAffordability={() => setShowAffordabilityModal(true)}
        />
        <main className="flex-1 w-full overflow-y-auto bg-[#F6F6F2]">
          {renderMainTab()}
        </main>
        <BottomNavigation
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          openQuickAdd={() => setShowQuickAddModal(true)}
        />

        {/* Feature Modals */}
        {showHealthModal && data.profile && (
          <HealthScoreModal
            scoreData={data.profile.healthScore}
            onClose={() => setShowHealthModal(false)}
            openSimulators={() => setActiveTab('simulators')}
          />
        )}
        {showAffordabilityModal && (
          <CanIAffordModal
            onClose={() => setShowAffordabilityModal(false)}
            openGoals={() => setActiveTab('goals')}
          />
        )}
        {showQuickAddModal && (
          <AddTransactionModal onClose={() => setShowQuickAddModal(false)} />
        )}
        {showCreateSheetModal && (
          <CreateSheetModal onClose={() => setShowCreateSheetModal(false)} />
        )}
      </DeviceFrame>
    );
  }

  // Classic Desktop Financial Workspace (Sections 7 & 8 spec)
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F6F6F2]">
      {/* Desktop Left Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openCreateSheet={() => setShowCreateSheetModal(true)}
        openAffordability={() => setShowAffordabilityModal(true)}
      />

      {/* Main Workspace Column */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top Classic Header */}
        <Navbar
          activeTab={activeTab}
          isMobileFrame={false}
          setIsMobileFrame={setIsMobileFrame}
          openCreateSheet={() => setShowCreateSheetModal(true)}
          openAffordability={() => setShowAffordabilityModal(true)}
        />

        {/* Scrollable Main Area */}
        <main className="flex-1 w-full overflow-y-auto bg-[#F6F6F2]">
          {renderMainTab()}
        </main>
      </div>

      {/* Feature Modals */}
      {showHealthModal && data.profile && (
        <HealthScoreModal
          scoreData={data.profile.healthScore}
          onClose={() => setShowHealthModal(false)}
          openSimulators={() => setActiveTab('simulators')}
        />
      )}

      {showAffordabilityModal && (
        <CanIAffordModal
          onClose={() => setShowAffordabilityModal(false)}
          openGoals={() => setActiveTab('goals')}
        />
      )}

      {showQuickAddModal && (
        <AddTransactionModal onClose={() => setShowQuickAddModal(false)} />
      )}

      {showCreateSheetModal && (
        <CreateSheetModal onClose={() => setShowCreateSheetModal(false)} />
      )}
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <FinanceProvider>
        <MainApp />
      </FinanceProvider>
    </AuthProvider>
  );
}

export default App;

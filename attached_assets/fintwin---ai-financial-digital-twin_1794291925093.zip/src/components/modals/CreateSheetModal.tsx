import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { X, Layers, Users, Sparkles, Check } from 'lucide-react';
import { SheetType } from '../../types/finance';

interface CreateSheetModalProps {
  onClose: () => void;
}

export const CreateSheetModal: React.FC<CreateSheetModalProps> = ({ onClose }) => {
  const { createSheet } = useFinance();
  const [name, setName] = useState('');
  const [type, setType] = useState<SheetType>('family');
  const [description, setDescription] = useState('');
  const [membersCount, setMembersCount] = useState('2');
  const [loading, setLoading] = useState(false);

  const presets = [
    { name: 'Family Household Finance', type: 'family' as SheetType, desc: 'Combined household income, living costs, and collective savings.' },
    { name: "Brother's Finance", type: 'friend' as SheetType, desc: "Separate plan to assist brother's education and budgeting." },
    { name: "Dad's Retirement Plan", type: 'family' as SheetType, desc: "Pension, medical expenses, and safe fixed deposit management." },
    { name: 'Wedding Planning Sheet', type: 'scenario' as SheetType, desc: 'Special earmarked budget and target savings for wedding event.' },
    { name: 'Side Business / Startup', type: 'scenario' as SheetType, desc: 'Freelance revenue, operational costs, and growth surplus.' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setLoading(true);
    const newId = await createSheet(
      name.trim(),
      type,
      description.trim(),
      type === 'family' ? Number(membersCount) || 2 : undefined
    );
    setLoading(false);
    if (newId) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-[#E5E8E3] overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-4 bg-[#173F35] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-[#C9F36B] text-[#173F35]">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold">New Financial Sheet</h2>
              <p className="text-[11px] text-emerald-100/70">Isolated budgets, goals, and calculations</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
          
          {/* Quick Presets */}
          <div>
            <label className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1.5">
              Quick Suggestions
            </label>
            <div className="flex flex-wrap gap-1.5">
              {presets.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setName(p.name);
                    setType(p.type);
                    setDescription(p.desc);
                  }}
                  className="px-2.5 py-1 text-[11px] bg-zinc-100 hover:bg-zinc-200 rounded-lg text-zinc-700 transition-colors"
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          {/* Sheet Name */}
          <div>
            <label className="text-xs font-semibold text-zinc-700 block mb-1">Sheet Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Family Household Finance, Brother's Finance"
              className="w-full px-3 py-2 text-sm rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
            />
          </div>

          {/* Sheet Type */}
          <div>
            <label className="text-xs font-semibold text-zinc-700 block mb-1">Sheet Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as SheetType)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
            >
              <option value="personal">Personal Finance</option>
              <option value="family">Family Mode (Household)</option>
              <option value="friend">Friend / Relative Plan</option>
              <option value="scenario">What-If / Event Scenario</option>
              <option value="other">Other Plan</option>
            </select>
          </div>

          {/* Members count (for family mode) */}
          {type === 'family' && (
            <div>
              <label className="text-xs font-semibold text-zinc-700 block mb-1">
                Household Members
              </label>
              <div className="relative">
                <Users className="w-4 h-4 absolute left-3 top-2.5 text-zinc-400" />
                <input
                  type="number"
                  min="1"
                  max="12"
                  value={membersCount}
                  onChange={(e) => setMembersCount(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-zinc-200"
                />
              </div>
            </div>
          )}

          {/* Description */}
          <div>
            <label className="text-xs font-semibold text-zinc-700 block mb-1">Optional Notes</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Notes on who this is for or goal targets..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading || !name.trim()}
              className="w-full py-2.5 rounded-xl bg-[#173F35] text-white text-xs font-bold hover:bg-[#1f5446] transition-colors shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <Check className="w-4 h-4 text-[#C9F36B]" />
              <span>{loading ? 'Creating Sheet...' : 'Create Financial Sheet'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

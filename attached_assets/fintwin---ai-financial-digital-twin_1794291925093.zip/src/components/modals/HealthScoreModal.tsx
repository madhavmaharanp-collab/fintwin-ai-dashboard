import React from 'react';
import { HealthScoreResult } from '../../types/finance';
import { X, ShieldCheck, CheckCircle2, AlertTriangle, AlertCircle, ArrowUpRight } from 'lucide-react';

interface HealthScoreModalProps {
  scoreData: HealthScoreResult | null;
  onClose: () => void;
  openSimulators: () => void;
}

export const HealthScoreModal: React.FC<HealthScoreModalProps> = ({
  scoreData,
  onClose,
  openSimulators,
}) => {
  if (!scoreData) return null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'OPTIMAL':
        return <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Optimal</span>;
      case 'GOOD':
        return <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-semibold flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Good</span>;
      case 'FAIR':
        return <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Fair</span>;
      default:
        return <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-100 text-red-800 font-semibold flex items-center gap-1"><AlertCircle className="w-3 h-3" /> Needs Attention</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-[#E5E8E3] overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="bg-[#173F35] text-white p-5 flex items-start justify-between relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 text-[#C9F36B] text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Transparent Scoring Algorithm</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold mt-1 text-white">Why is my score {scoreData.overall}?</h2>
            <p className="text-xs text-emerald-100/80 mt-1 max-w-sm">
              {scoreData.explanation}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1">
          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F8F5] border border-[#E5E8E3]">
            <div>
              <span className="text-xs font-medium text-zinc-500">Overall Rating</span>
              <div className="text-2xl font-black text-[#111412] tracking-tight">{scoreData.overall} <span className="text-sm font-normal text-zinc-400">/ 100</span></div>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#173F35] text-[#C9F36B]">
                {scoreData.status}
              </span>
              <div className="text-[10px] text-zinc-400 mt-1">Deterministic Formula</div>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider px-1">
              Category Score Breakdown
            </h3>

            {scoreData.breakdown.map((item, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl border border-[#E5E8E3] hover:border-zinc-300 transition-colors bg-white space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-900">{item.category}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-[#173F35]">
                      {item.score} / {item.maxScore} pts
                    </span>
                    {getStatusBadge(item.status)}
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#173F35] rounded-full transition-all duration-500"
                    style={{ width: `${(item.score / item.maxScore) * 100}%` }}
                  ></div>
                </div>

                <p className="text-[11px] text-zinc-600 leading-relaxed pt-0.5">{item.detail}</p>
                <div className="text-[10px] text-zinc-400 font-medium">
                  Ideal benchmark: <span className="text-zinc-600">{item.benchmark}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100 text-xs text-emerald-900 flex items-start gap-2">
            <div className="p-1 rounded bg-[#C9F36B] text-[#173F35] font-bold text-[10px] shrink-0 mt-0.5">
              TIP
            </div>
            <p className="text-[11px] leading-relaxed">
              To raise your score into the <strong>85+ EXCELLENT</strong> tier, keep emergency coverage above 6 months and ensure your monthly savings rate exceeds 25%.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-zinc-50 border-t border-[#E5E8E3] flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              openSimulators();
            }}
            className="flex items-center gap-1.5 text-xs text-[#173F35] font-semibold hover:underline"
          >
            <span>Simulate Improvement In Planner</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#173F35] text-white text-xs font-medium hover:bg-[#1f5446] transition-colors"
          >
            Got it
          </button>
        </div>

      </div>
    </div>
  );
};

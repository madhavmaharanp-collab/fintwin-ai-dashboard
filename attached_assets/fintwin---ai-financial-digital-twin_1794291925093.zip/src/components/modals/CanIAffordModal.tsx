import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { analyzeAffordability, formatCurrency } from '../../calculations/financeEngine';
import { X, CheckCircle2, AlertTriangle, AlertOctagon, ArrowRight, Target } from 'lucide-react';

interface CanIAffordModalProps {
  onClose: () => void;
  openGoals: () => void;
}

export const CanIAffordModal: React.FC<CanIAffordModalProps> = ({ onClose, openGoals }) => {
  const { data, currency, addGoal } = useFinance();
  const [itemName, setItemName] = useState('MacBook Pro');
  const [price, setPrice] = useState('150000');
  const [goalAdded, setGoalAdded] = useState(false);

  const numPrice = Number(price) || 0;
  const currentBalance = data.profile?.totalLiquidSavings || 425000;
  const analysis = data.profile ? analyzeAffordability(numPrice, data.profile) : null;

  const balanceAfter = Math.max(0, currentBalance - numPrice);
  const emergencyBefore = data.profile?.emergencyFundCoverageMonths || 3.8;
  const emergencyAfter = analysis?.details.emergencyMonthsLeft || Math.max(0, Number((emergencyBefore - (numPrice / (data.profile?.totalMonthlyExpenses || 48000))).toFixed(1)));

  const handleCreateGoalFromPurchase = async () => {
    if (!analysis || numPrice <= 0) return;
    const success = await addGoal({
      name: itemName,
      targetAmount: numPrice,
      currentAmount: 0,
      targetDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      priority: 'medium',
      category: 'Capital Purchase',
      monthlyAllocated: Math.round(numPrice / 6),
    });
    if (success) {
      setGoalAdded(true);
      setTimeout(() => {
        onClose();
        openGoals();
      }, 700);
    }
  };

  const getVerdictBadge = () => {
    if (!analysis) return null;
    if (analysis.status === 'affordable') {
      return (
        <div className="p-3 rounded border border-emerald-300 bg-emerald-50 text-[#2E7653] space-y-0.5">
          <span className="text-[10px] uppercase font-bold tracking-wider block">Decision Assessment</span>
          <div className="text-sm font-bold">APPROVED — FULLY AFFORDABLE</div>
          <p className="text-xs text-[#626861] mt-0.5">Does not compromise your 3-6 month core reserve buffer.</p>
        </div>
      );
    }
    if (analysis.status === 'trade_off') {
      return (
        <div className="p-3 rounded border border-amber-300 bg-amber-50 text-[#B78327] space-y-0.5">
          <span className="text-[10px] uppercase font-bold tracking-wider block">Decision Assessment</span>
          <div className="text-sm font-bold">POSSIBLE, BUT NOT IDEAL</div>
          <p className="text-xs text-[#626861] mt-0.5">Absorbs substantial surplus and delays active target milestones by ~2 months.</p>
        </div>
      );
    }
    return (
      <div className="p-3 rounded border border-red-300 bg-red-50 text-[#B94A48] space-y-0.5">
        <span className="text-[10px] uppercase font-bold tracking-wider block">Decision Assessment</span>
        <div className="text-sm font-bold">NOT RECOMMENDED AT CURRENT CASHFLOW</div>
        <p className="text-xs text-[#626861] mt-0.5">Depletes emergency reserves below the minimum safety threshold.</p>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 select-none">
      <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-[#DCDDD8] overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-4 border-b border-[#DCDDD8] flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-[#626861] font-bold block">
              Capital Assessment
            </span>
            <h2 className="text-base font-bold text-[#111412]">Purchase Analysis</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded text-[#626861] hover:text-[#111412]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input Parameters */}
        <div className="p-4 space-y-3 bg-[#F6F6F2] border-b border-[#DCDDD8]">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-[#626861] font-medium block mb-1">Purchase Item</label>
              <input
                type="text"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="e.g. MacBook Pro"
                className="w-full px-2.5 py-1.5 bg-white border border-[#DCDDD8] rounded text-[#111412] font-medium focus:outline-none focus:border-[#173F35]"
              />
            </div>
            <div>
              <label className="text-[#626861] font-medium block mb-1">Price ({currency})</label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="150000"
                className="w-full px-2.5 py-1.5 bg-white border border-[#DCDDD8] rounded text-[#111412] font-mono font-bold focus:outline-none focus:border-[#173F35]"
              />
            </div>
          </div>
        </div>

        {/* Financial Impact Breakdown (Section 21 spec) */}
        <div className="p-4 space-y-4 text-xs">
          {getVerdictBadge()}

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-2.5 rounded border border-[#DCDDD8] bg-white">
              <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">Current Balance</span>
              <span className="text-sm font-bold font-mono text-[#111412] mt-0.5 block">
                {formatCurrency(currentBalance, currency)}
              </span>
            </div>

            <div className="p-2.5 rounded border border-[#DCDDD8] bg-white">
              <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">After Purchase</span>
              <span className="text-sm font-bold font-mono text-[#173F35] mt-0.5 block">
                {formatCurrency(balanceAfter, currency)}
              </span>
            </div>

            <div className="p-2.5 rounded border border-[#DCDDD8] bg-white">
              <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">Emergency Fund</span>
              <span className="text-sm font-bold font-mono text-[#111412] mt-0.5 block">
                {emergencyBefore} mo → <strong className="text-[#B78327]">{emergencyAfter} mo</strong>
              </span>
            </div>

            <div className="p-2.5 rounded border border-[#DCDDD8] bg-white">
              <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">Goal Delay</span>
              <span className="text-sm font-bold font-mono text-[#B94A48] mt-0.5 block">
                +{analysis?.details.goalDelayEstimateMonths || 2} Months
              </span>
            </div>
          </div>

          {/* Timing Alternatives */}
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] font-bold text-[#111412] uppercase tracking-wider block">
              Strategic Purchase Timing
            </span>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
                <strong className="text-[#111412] block">Wait 1 Month</strong>
                <span className="text-[#626861]">Reduces cash shock by 35% using next salary.</span>
              </div>
              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
                <strong className="text-[#111412] block">Save Monthly (6 Mo)</strong>
                <span className="text-[#626861]">{formatCurrency(Math.ceil(numPrice / 6), currency)}/mo with 0% reserve risk.</span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 border-t border-[#DCDDD8] flex items-center justify-between gap-3">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded border border-[#DCDDD8] text-[#626861] hover:text-[#111412] text-xs font-semibold"
            >
              Dismiss
            </button>

            <button
              onClick={handleCreateGoalFromPurchase}
              disabled={goalAdded}
              className="px-4 py-1.5 rounded bg-[#173F35] text-white hover:bg-[#1f5446] text-xs font-semibold flex items-center gap-1.5"
            >
              <Target className="w-3.5 h-3.5" />
              <span>{goalAdded ? 'Converted to Plan' : 'Convert to 6-Month Goal'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

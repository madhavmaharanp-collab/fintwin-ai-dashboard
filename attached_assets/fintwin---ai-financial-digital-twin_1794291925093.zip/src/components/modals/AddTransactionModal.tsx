import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { X, ArrowDownRight, ArrowUpRight, Check } from 'lucide-react';
import { ExpenseCategory } from '../../types/finance';

interface AddTransactionModalProps {
  onClose: () => void;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({ onClose }) => {
  const { addTransaction, currency } = useFinance();
  const [type, setType] = useState<'expense' | 'income' | 'transfer'>('expense');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ExpenseCategory | string>('food');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [isRecurring, setIsRecurring] = useState(false);
  const [loading, setLoading] = useState(false);

  const categories = [
    { id: 'food', label: 'Food & Groceries' },
    { id: 'housing', label: 'Housing & Rent' },
    { id: 'transportation', label: 'Transportation & Fuel' },
    { id: 'utilities', label: 'Utilities & Internet' },
    { id: 'entertainment', label: 'Dining & Entertainment' },
    { id: 'shopping', label: 'Shopping' },
    { id: 'subscriptions', label: 'Subscriptions' },
    { id: 'healthcare', label: 'Healthcare' },
    { id: 'education', label: 'Education' },
    { id: 'debt_payment', label: 'Debt EMI' },
    { id: 'salary', label: 'Salary / Client Pay' },
    { id: 'other', label: 'Other' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description) return;
    setLoading(true);
    const success = await addTransaction({
      amount: Number(amount),
      type,
      category,
      date,
      description,
      paymentMethod,
      isRecurring,
    });
    setLoading(false);
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-[#E5E8E3] overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-4 bg-[#173F35] text-white flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold">Record Transaction</h2>
            <p className="text-[11px] text-emerald-100/70">Updates financial sheet & live balances</p>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
          
          {/* Transaction Type Segmented Toggle */}
          <div className="grid grid-cols-2 p-1 bg-zinc-100 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setType('expense');
                if (category === 'salary') setCategory('food');
              }}
              className={`flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                type === 'expense'
                  ? 'bg-white text-red-700 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              <ArrowDownRight className="w-3.5 h-3.5 text-red-500" />
              <span>Expense</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setType('income');
                setCategory('salary');
              }}
              className={`flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                type === 'income'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
              <span>Income</span>
            </button>
          </div>

          {/* Amount Input */}
          <div>
            <label className="text-xs font-semibold text-zinc-700 block mb-1">Amount ({currency})</label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs text-zinc-400 font-semibold">{currency}</span>
              <input
                type="number"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                className="w-full pl-12 pr-3 py-2 text-base font-mono font-bold rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-semibold text-zinc-700 block mb-1">Description</label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Organic Groceries, Salary Deposit, Coffee"
              className="w-full px-3 py-2 text-sm rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
            />
          </div>

          {/* Category & Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-zinc-700 block mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-zinc-700 block mb-1">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-zinc-700 block mb-1">Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
              >
                <option value="Cash">Cash</option>
                <option value="Mobile Banking (eSewa/FonePay)">Mobile Banking</option>
                <option value="Debit Card">Debit Card</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Bank Transfer">Bank Transfer</option>
              </select>
            </div>

            <div className="flex items-center pt-5">
              <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-zinc-700 font-medium">
                <input
                  type="checkbox"
                  checked={isRecurring}
                  onChange={(e) => setIsRecurring(e.target.checked)}
                  className="rounded text-[#173F35] focus:ring-[#173F35]"
                />
                <span>Monthly Recurring</span>
              </label>
            </div>
          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl bg-[#173F35] text-white text-xs font-bold hover:bg-[#1f5446] transition-colors shadow-sm flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4 text-[#C9F36B]" />
              <span>{loading ? 'Saving...' : 'Record Transaction'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

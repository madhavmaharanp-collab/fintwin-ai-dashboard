import React, { useState, useEffect } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency } from '../../calculations/financeEngine';
import {
  FileText,
  Printer,
  CheckCircle2,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { user } = useAuth();
  const { data, currency, activeSheetId } = useFinance();
  const [review, setReview] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchReview() {
      try {
        const res = await fetch('/api/ai/monthly-review', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('finpulse_token')}`,
          },
          body: JSON.stringify({ sheetId: activeSheetId }),
        });
        if (res.ok) {
          const json = await res.json();
          setReview(json.review);
        }
      } catch (e) {
        console.error('Failed to load review', e);
      } finally {
        setLoading(false);
      }
    }
    fetchReview();
  }, [activeSheetId]);

  const profile = data.profile;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6 pb-20 print:p-0 select-none">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 border-b border-[#DCDDD8] pb-4 print:hidden">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#626861] font-bold block mb-1">
            Accounting Synthesis
          </span>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#111412] tracking-tight">
            Financial Statement & Closing Audit
          </h1>
          <p className="text-xs text-[#626861] mt-0.5">
            Synthesized cashflow statement, balance sheet audit, and strategic financial advisory report.
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#DCDDD8] bg-white text-[#111412] text-xs font-semibold hover:bg-[#F6F6F2] transition-colors self-start sm:self-auto shadow-xs"
        >
          <Printer className="w-3.5 h-3.5 text-[#173F35]" />
          <span>Print / Export Audit</span>
        </button>
      </div>

      {/* Printable Report Document Shell */}
      <div className="bg-white rounded-lg border border-[#DCDDD8] p-6 sm:p-8 shadow-xs space-y-6">
        
        {/* Document Header */}
        <div className="flex justify-between items-start border-b border-[#F0F1ED] pb-4">
          <div>
            <div className="flex items-center gap-2 text-[#111412] font-bold text-base tracking-tight font-mono">
              <span className="w-6 h-6 rounded bg-[#173F35] text-white flex items-center justify-center text-xs font-bold">fT</span>
              fin<span className="text-[#173F35] font-extrabold">TWIN</span> Monthly Closing Statement
            </div>
            <p className="text-xs text-[#626861] mt-1">Prepared for: <strong className="text-[#111412]">{user?.name}</strong></p>
            <p className="text-[11px] text-[#626861] font-mono">Ledger: {data.sheet?.name} • Statement Period: {review?.monthName || 'October 2026'}</p>
          </div>

          <div className="text-right">
            <span className="text-xs font-bold px-2.5 py-0.5 rounded bg-[#173F35] text-white font-mono">
              Health Rating {profile?.healthScore.overall || 78}/100
            </span>
            <div className="text-[10px] text-[#626861] mt-1 font-mono">Verified Deterministic Ledger</div>
          </div>
        </div>

        {/* Financial Numbers Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] text-[#626861] uppercase font-semibold block">Total Income</span>
            <div className="text-base font-bold font-mono text-[#111412] mt-0.5">
              {formatCurrency(profile?.totalMonthlyIncome || 0, currency)}
            </div>
          </div>

          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] text-[#626861] uppercase font-semibold block">Living Expenses</span>
            <div className="text-base font-bold font-mono text-[#111412] mt-0.5">
              {formatCurrency(profile?.totalMonthlyExpenses || 0, currency)}
            </div>
          </div>

          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] text-[#626861] uppercase font-semibold block">Surplus Saved</span>
            <div className="text-base font-bold font-mono text-[#173F35] mt-0.5">
              +{formatCurrency(profile?.monthlySurplus || 0, currency)}
            </div>
          </div>

          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] text-[#626861] uppercase font-semibold block">Reserve Runway</span>
            <div className="text-base font-bold font-mono text-[#111412] mt-0.5">
              {profile?.emergencyFundCoverageMonths || 0} Months
            </div>
          </div>
        </div>

        {/* Structured Executive Summary */}
        <div className="space-y-3 border-t border-[#F0F1ED] pt-4">
          <span className="text-xs font-bold uppercase tracking-wider text-[#111412] block">
            Executive Performance Summary
          </span>
          <p className="text-xs text-[#111412] leading-relaxed">
            {review?.summary ||
              `For this monthly statement closing, gross earnings reached ${formatCurrency(profile?.totalMonthlyIncome || 0, currency)}, while essential obligations consumed ${formatCurrency(profile?.totalMonthlyExpenses || 0, currency)}. This enabled a net surplus allocation of ${formatCurrency(profile?.monthlySurplus || 0, currency)} (equivalent to a ${profile?.savingsRate.toFixed(1) || 0}% savings rate).`}
          </p>
        </div>

        {/* Highlights & Optimization Directives */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-[#F0F1ED] pt-4">
          <div className="p-4 rounded border border-[#DCDDD8] bg-[#F6F6F2] space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2E7653] block">
              Observed Strengths
            </span>
            <ul className="space-y-1.5 text-xs text-[#111412]">
              {(review?.highlights || [
                'Maintained liquid reserves covering over 3 months of baseline living costs.',
                'Debt service obligations remain comfortably below the 25% threshold.',
                'Categorical housing and nutrition costs remained within scheduled limits.',
              ]).map((h: string, i: number) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-[#2E7653] font-bold">•</span>
                  <span>{h}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="p-4 rounded border border-[#DCDDD8] bg-white space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#B78327] block">
              Strategic Next Steps
            </span>
            <ul className="space-y-1.5 text-xs text-[#111412]">
              {(review?.improvements || [
                'Direct remaining monthly surplus into the core safety buffer.',
                'Review recurring SaaS software charges for inactive licenses.',
                'Commit regular monthly SIP tranches to diversify asset base.',
              ]).map((imp: string, i: number) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-[#B78327] font-bold">•</span>
                  <span>{imp}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Auditor Footnote */}
        <div className="pt-4 border-t border-[#F0F1ED] flex justify-between items-center text-[10px] text-[#626861] font-mono">
          <span>Prepared by FinTwin Core Accounting Engine</span>
          <span>Verified Non-Custodial Client Record</span>
        </div>

      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { FinTwin3DCore } from './FinTwin3DCore';
import {
  formatCurrency,
  formatCurrencyCompact,
  calculateStressTest,
  calculateTimeMachine,
} from '../../calculations/financeEngine';
import {
  Activity,
  Shield,
  Layers,
  Calendar,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Clock,
  CheckCircle2,
  Sliders,
  DollarSign,
  ChevronRight,
  Info,
  SlidersHorizontal,
} from 'lucide-react';
import { StressTestScenario, TimeMachineProjection } from '../../types/finance';

interface FinTwinViewProps {
  openAffordability: () => void;
  openAddTransaction: () => void;
}

export const FinTwinView: React.FC<FinTwinViewProps> = ({ openAffordability, openAddTransaction }) => {
  const { data, currency } = useFinance();
  const profile = data.profile;

  // Timeline horizon state (TODAY, 1Y, 3Y, 5Y, 10Y)
  const [timeHorizonMonths, setTimeHorizonMonths] = useState<number>(12);

  // Stress test active scenario
  const [activeStressType, setActiveStressType] = useState<StressTestScenario['type']>('job_loss');

  // Reminders state
  const [reminders, setReminders] = useState(profile?.upcomingReminders || []);

  const timeMachine = profile ? calculateTimeMachine(timeHorizonMonths, profile) : null;
  const stressScenario = profile ? calculateStressTest(activeStressType, profile) : null;

  const toggleReminder = (id: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isCompleted: !r.isCompleted } : r))
    );
  };

  const healthScore = profile?.healthScore?.overall || 78;
  const resilienceScore = profile?.resilienceScore?.overall || 72;
  const savingsRate = profile?.savingsRate || 25.0;
  const emergencyCoverage = profile?.emergencyFundCoverageMonths || 3.8;
  const debtRatio = profile?.debtToIncomeRatio || 12.0;

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6 pb-20 select-none">
      
      {/* Header (Section 16 spec) */}
      <div className="border-b border-[#DCDDD8] pb-4 flex flex-col sm:flex-row sm:items-baseline justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#626861] font-bold block mb-1">
            Analytical Terminal
          </span>
          <h1 className="text-2xl sm:text-3xl font-semibold text-[#111412] tracking-tight">
            Financial Twin
          </h1>
          <p className="text-xs text-[#626861] mt-1 font-medium">
            Your current financial state and forward-looking projection model.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openAffordability}
            className="px-3 py-1.5 rounded-md border border-[#DCDDD8] bg-white hover:bg-[#F6F6F2] text-xs font-semibold text-[#111412] transition-colors"
          >
            Capital Expenditure Check
          </button>
        </div>
      </div>

      {/* CURRENT POSITION METRICS (Section 16 spec) */}
      <div className="p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-3">
        <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-2.5">
          <span className="text-xs font-bold uppercase tracking-wider text-[#111412]">
            Current Position Vitals
          </span>
          <span className="text-[10px] font-mono text-[#626861]">
            Deterministic Valuation Model
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
              Financial Health
            </span>
            <div className="text-lg font-bold font-mono text-[#173F35] mt-1">
              {healthScore} <span className="text-xs text-[#626861]">/ 100</span>
            </div>
            <span className="text-[10px] text-[#2E7653] font-medium block mt-0.5">Good Standing</span>
          </div>

          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
              Resilience Score
            </span>
            <div className="text-lg font-bold font-mono text-[#111412] mt-1">
              {resilienceScore} <span className="text-xs text-[#626861]">/ 100</span>
            </div>
            <span className="text-[10px] text-[#626861] font-medium block mt-0.5">Moderate Buffer</span>
          </div>

          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
              Savings Rate
            </span>
            <div className="text-lg font-bold font-mono text-[#173F35] mt-1">
              {savingsRate.toFixed(1)}%
            </div>
            <span className="text-[10px] text-[#626861] font-medium block mt-0.5">Net cash surplus</span>
          </div>

          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2]">
            <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
              Emergency Coverage
            </span>
            <div className="text-lg font-bold font-mono text-[#111412] mt-1">
              {emergencyCoverage} <span className="text-xs text-[#626861]">months</span>
            </div>
            <span className="text-[10px] text-[#626861] font-medium block mt-0.5">Fixed expense cover</span>
          </div>

          <div className="p-3 rounded border border-[#DCDDD8] bg-[#F6F6F2] col-span-2 sm:col-span-1">
            <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
              Debt Ratio (DTI)
            </span>
            <div className="text-lg font-bold font-mono text-[#111412] mt-1">
              {debtRatio.toFixed(1)}%
            </div>
            <span className="text-[10px] text-[#2E7653] font-medium block mt-0.5">Under 25% threshold</span>
          </div>
        </div>
      </div>

      {/* 3D CORE & PROJECTION WORKSPACE (Section 17 spec) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Refined 3D Analytical Model (5 cols) */}
        <div className="lg:col-span-5">
          <FinTwin3DCore profile={profile} />
        </div>

        {/* Financial Future Timeline Projection (7 cols) */}
        <div className="lg:col-span-7 p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#F0F1ED] pb-3">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-[#111412]">
                  Future Wealth Trajectory
                </h3>
                <p className="text-xs text-[#626861]">Multi-year projection based on current financial variables</p>
              </div>

              {/* Timeline scrubber: TODAY, 1Y, 3Y, 5Y, 10Y */}
              <div className="flex p-0.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded text-xs self-start sm:self-auto font-mono">
                {[
                  { m: 3, label: '3M' },
                  { m: 12, label: '1Y' },
                  { m: 36, label: '3Y' },
                  { m: 60, label: '5Y' },
                  { m: 120, label: '10Y' },
                ].map((item) => (
                  <button
                    key={item.m}
                    onClick={() => setTimeHorizonMonths(item.m)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded transition-colors ${
                      timeHorizonMonths === item.m
                        ? 'bg-[#173F35] text-white shadow-xs'
                        : 'text-[#626861] hover:text-[#111412]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Structured Metric Readouts */}
            {timeMachine && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3">
                <div className="p-3 rounded border border-[#DCDDD8] bg-white">
                  <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
                    Projected Balance
                  </span>
                  <div className="text-base font-bold font-mono text-[#111412] mt-1">
                    {formatCurrency(timeMachine.currentPath.balance, currency)}
                  </div>
                </div>

                <div className="p-3 rounded border border-[#DCDDD8] bg-white">
                  <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
                    Estimated Net Worth
                  </span>
                  <div className="text-base font-bold font-mono text-[#173F35] mt-1">
                    {formatCurrency(timeMachine.currentPath.netWorth, currency)}
                  </div>
                </div>

                <div className="p-3 rounded border border-[#DCDDD8] bg-white">
                  <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
                    Cumulative Saved
                  </span>
                  <div className="text-base font-bold font-mono text-[#111412] mt-1">
                    {formatCurrency(timeMachine.currentPath.savings, currency)}
                  </div>
                </div>

                <div className="p-3 rounded border border-[#DCDDD8] bg-white">
                  <span className="text-[10px] uppercase tracking-wider text-[#626861] block font-semibold">
                    Funded Goals
                  </span>
                  <div className="text-base font-bold font-mono text-[#111412] mt-1">
                    {timeMachine.currentPath.goalsFundedCount} Targets Met
                  </div>
                </div>
              </div>
            )}

            {/* Projection Area Graph */}
            <div className="h-32 w-full pt-3">
              <svg viewBox="0 0 400 90" className="w-full h-full overflow-visible">
                <line x1="20" y1="80" x2="380" y2="80" stroke="#DCDDD8" strokeWidth="1" />
                <line x1="20" y1="45" x2="380" y2="45" stroke="#EAEBE6" strokeDasharray="3 3" />

                {/* Shaded projection polygon */}
                <polygon
                  points="20,70 110,62 200,50 290,35 380,15 380,80 20,80"
                  fill="#173F35"
                  opacity="0.08"
                />

                {/* Main trajectory line */}
                <polyline
                  fill="none"
                  stroke="#173F35"
                  strokeWidth="2.5"
                  points="20,70 110,62 200,50 290,35 380,15"
                />

                <circle cx="380" cy="15" r="3.5" fill="#173F35" stroke="#FFFFFF" strokeWidth="2" />
              </svg>
            </div>
          </div>

          <div className="text-[11px] text-[#626861] border-t border-[#F0F1ED] pt-2 flex justify-between items-center">
            <span>Projection Model: Constant income with 4.0% annualized compounding assumption.</span>
            <span className="font-mono text-[#173F35] font-semibold">{timeHorizonMonths} Months Horizon</span>
          </div>
        </div>

      </div>

      {/* CURRENT PATH VS OPTIMIZED PATH (Section 18 spec) */}
      <div className="p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-4">
        <div className="border-b border-[#F0F1ED] pb-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#111412]">
            Current Path vs Optimized Path (5-Year Strategic Outlook)
          </h3>
          <p className="text-xs text-[#626861]">
            Comparative projection detailing the financial impact of capital efficiency adjustments
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Current Path */}
          <div className="p-4 rounded border border-[#DCDDD8] bg-[#F6F6F2] space-y-2">
            <span className="text-[10px] uppercase tracking-wider text-[#626861] font-bold block">
              Current Path
            </span>
            <div>
              <span className="text-xs text-[#626861] block">5-Year Projected Net Worth</span>
              <div className="text-2xl font-bold font-mono text-[#111412] mt-0.5">
                {currency} 1.2M
              </div>
            </div>
            <div className="pt-2 border-t border-[#DCDDD8] text-xs text-[#626861] flex justify-between">
              <span>Savings Rate:</span>
              <strong className="font-mono text-[#111412]">24.0%</strong>
            </div>
          </div>

          {/* Optimized Path */}
          <div className="p-4 rounded border border-[#173F35] bg-white space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-[10px] uppercase tracking-wider text-[#173F35] font-bold block">
                Optimized Path
              </span>
              <span className="text-[10px] font-mono font-bold text-[#2E7653] px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200">
                +NPR 600k Strategic Surplus
              </span>
            </div>
            <div>
              <span className="text-xs text-[#626861] block">5-Year Projected Net Worth</span>
              <div className="text-2xl font-bold font-mono text-[#173F35] mt-0.5">
                {currency} 1.8M
              </div>
            </div>
            <div className="pt-2 border-t border-[#F0F1ED] text-xs text-[#626861] flex justify-between">
              <span>Optimized Savings Rate:</span>
              <strong className="font-mono text-[#173F35]">31.0%</strong>
            </div>
          </div>

        </div>

        {/* What Changes Section */}
        <div className="pt-2 border-t border-[#F0F1ED] space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-[#111412] block">
            Optimization Methodology
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs text-[#626861]">
            <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
              <strong className="text-[#111412] block mb-0.5">1. Reduce Leaks</strong>
              <span>Trim ~NPR 3,500/mo from discretionary dining spikes.</span>
            </div>
            <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
              <strong className="text-[#111412] block mb-0.5">2. Increase Savings</strong>
              <span>Route 60% of monthly surplus directly to liquid reserves.</span>
            </div>
            <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
              <strong className="text-[#111412] block mb-0.5">3. Systematic SIP</strong>
              <span>Commit NPR 5,000/mo into low-fee diversified index funds.</span>
            </div>
            <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
              <strong className="text-[#111412] block mb-0.5">4. Audit Subscriptions</strong>
              <span>Retire duplicate cloud and digital entertainment tools.</span>
            </div>
          </div>
        </div>
      </div>

      {/* FINANCIAL STRESS TEST (Section 23 spec) */}
      <div className="p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F0F1ED] pb-3">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#111412]">
              Financial Stress Testing & Risk Scenarios
            </h3>
            <p className="text-xs text-[#626861]">Simulate liquidity exhaustion under adverse macroeconomic events</p>
          </div>

          {/* Scenario Tabs: BASE CASE, JOB LOSS, SALARY -20%, RENT +20%, EMERGENCY EXPENSE */}
          <div className="flex p-0.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded text-xs overflow-x-auto self-start sm:self-auto font-mono">
            {[
              { id: 'job_loss' as const, label: 'JOB LOSS' },
              { id: 'salary_drop' as const, label: 'SALARY -20%' },
              { id: 'emergency_expense' as const, label: 'EMERGENCY EXPENSE' },
              { id: 'rent_hike' as const, label: 'RENT +20%' },
            ].map((sc) => (
              <button
                key={sc.id}
                onClick={() => setActiveStressType(sc.id)}
                className={`px-3 py-1 font-semibold rounded transition-colors whitespace-nowrap ${
                  activeStressType === sc.id
                    ? 'bg-[#173F35] text-white shadow-xs'
                    : 'text-[#626861] hover:text-[#111412]'
                }`}
              >
                {sc.label}
              </button>
            ))}
          </div>
        </div>

        {stressScenario && (
          <div className="p-4 rounded border border-[#DCDDD8] bg-[#F6F6F2] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#111412]">{stressScenario.title}</h4>
                <p className="text-xs text-[#626861] mt-0.5">{stressScenario.description}</p>
              </div>

              <div className="text-left sm:text-right">
                <span className="text-[10px] text-[#626861] uppercase tracking-wider block font-semibold">Survival Runway</span>
                <span className="text-lg font-bold font-mono text-[#B94A48]">
                  {stressScenario.survivalMonths >= 99 ? 'Indefinite' : `${stressScenario.survivalMonths} Months`}
                </span>
              </div>
            </div>

            {/* Exhaustion progression */}
            {stressScenario.cashExhaustionMonths && (
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-1 font-mono">
                {stressScenario.cashExhaustionMonths.map((m) => (
                  <div key={m.month} className="p-2 rounded bg-white border border-[#DCDDD8] text-center text-xs">
                    <span className="text-[10px] text-[#626861] block">Month {m.month}</span>
                    <span className="font-bold text-[#111412] block mt-0.5">{formatCurrencyCompact(m.remainingBuffer, currency)}</span>
                    <span className="text-[9px] text-[#626861] block">{m.status}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-2 border-t border-[#DCDDD8] space-y-1">
              <span className="text-xs font-bold uppercase tracking-wider text-[#111412] block">Mitigation Recommendations:</span>
              {stressScenario.recommendations.map((rec, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-[#626861]">
                  <span className="text-[#173F35] font-bold">•</span>
                  <span>{rec}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

    </div>
  );
};

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { FinancialProfileCalculated } from '../../types/finance';
import { Activity, Shield, RotateCw } from 'lucide-react';

interface FinTwin3DCoreProps {
  profile: FinancialProfileCalculated | null;
  interactiveMode?: boolean;
}

export const FinTwin3DCore: React.FC<FinTwin3DCoreProps> = ({ profile }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [activeInspect, setActiveInspect] = useState<'health' | 'resilience' | 'cashflow'>('health');

  const healthScore = profile?.healthScore?.overall || 78;
  const resilienceScore = profile?.resilienceScore?.overall || 72;
  const monthlySurplus = profile?.monthlySurplus || 20000;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 340;
    const height = container.clientHeight || 260;

    // Three.js Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 5.0;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Deep Forest & Slate Palette
    const coreColor = 0x173f35;
    const accentColor = 0xc9e875;
    const goldColor = 0xb78327;

    // 1. Central Core: Geometric Icosahedron with Matte Finish
    const coreGeo = new THREE.IcosahedronGeometry(1.05, 1);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0x22352e,
      wireframe: true,
      roughness: 0.5,
      metalness: 0.2,
      emissive: coreColor,
      emissiveIntensity: 0.25,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    scene.add(coreMesh);

    // Inner subtle nucleus
    const innerGeo = new THREE.SphereGeometry(0.5, 16, 16);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0x173f35,
      transparent: true,
      opacity: 0.3,
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    scene.add(innerMesh);

    // 2. Gyroscopic Income Orbital Ring
    const incomeRingGeo = new THREE.TorusGeometry(1.65, 0.02, 16, 80);
    const incomeRingMat = new THREE.MeshStandardMaterial({
      color: accentColor,
      roughness: 0.4,
    });
    const incomeRing = new THREE.Mesh(incomeRingGeo, incomeRingMat);
    incomeRing.rotation.x = Math.PI / 3;
    scene.add(incomeRing);

    // 3. Counter-Rotating Expense & Debt Orbital Ring
    const expenseRingGeo = new THREE.TorusGeometry(2.0, 0.015, 16, 80);
    const expenseRingMat = new THREE.MeshStandardMaterial({
      color: goldColor,
      roughness: 0.4,
    });
    const expenseRing = new THREE.Mesh(expenseRingGeo, expenseRingMat);
    expenseRing.rotation.y = Math.PI / 4;
    scene.add(expenseRing);

    // Subtle Particle Grid
    const particleCount = 80;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 5.5;
      positions[i + 1] = (Math.random() - 0.5) * 5.5;
      positions[i + 2] = (Math.random() - 0.5) * 5.5;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x889891,
      size: 0.03,
      transparent: true,
      opacity: 0.5,
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    scene.add(particleSystem);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.4);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(3, 4, 5);
    scene.add(keyLight);

    // Mouse & Touch Drag Controls
    let isDragging = false;
    let prevMouse = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouse = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - prevMouse.x;
      const dy = e.clientY - prevMouse.y;
      coreMesh.rotation.y += dx * 0.008;
      coreMesh.rotation.x += dy * 0.008;
      prevMouse = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const dx = e.touches[0].clientX - prevMouse.x;
      const dy = e.touches[0].clientY - prevMouse.y;
      coreMesh.rotation.y += dx * 0.01;
      coreMesh.rotation.x += dy * 0.01;
      prevMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const onTouchEnd = () => {
      isDragging = false;
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    // Animation Loop
    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      if (!isDragging) {
        coreMesh.rotation.y += 0.006;
        coreMesh.rotation.x += 0.003;
        incomeRing.rotation.z += 0.008;
        expenseRing.rotation.x -= 0.006;
        particleSystem.rotation.y -= 0.001;
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const nw = container.clientWidth || 340;
      const nh = container.clientHeight || 260;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container.contains(dom)) {
        container.removeChild(dom);
      }
    };
  }, [healthScore, resilienceScore]);

  return (
    <div className="rounded-lg bg-white border border-[#DCDDD8] p-4 flex flex-col justify-between space-y-3">
      
      {/* Title */}
      <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-2 text-xs">
        <span className="font-bold uppercase tracking-wider text-[#111412] flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-[#173F35]" />
          Valuation Core
        </span>
        <span className="text-[10px] text-[#626861] font-mono">
          Rotational Telemetry
        </span>
      </div>

      {/* 3D Canvas Viewport */}
      <div
        ref={mountRef}
        className="w-full h-52 cursor-grab active:cursor-grabbing flex items-center justify-center relative select-none"
        title="Interactive 3D model: Drag with mouse or swipe to rotate"
      />

      {/* Structured Readout */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs pt-1 border-t border-[#F0F1ED]">
        <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
          <span className="text-[9px] uppercase tracking-wider text-[#626861] block font-semibold">Health</span>
          <span className="text-sm font-bold font-mono text-[#173F35] block mt-0.5">
            {healthScore}/100
          </span>
        </div>

        <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
          <span className="text-[9px] uppercase tracking-wider text-[#626861] block font-semibold">Resilience</span>
          <span className="text-sm font-bold font-mono text-[#111412] block mt-0.5">
            {resilienceScore}/100
          </span>
        </div>

        <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
          <span className="text-[9px] uppercase tracking-wider text-[#626861] block font-semibold">Surplus</span>
          <span className="text-sm font-bold font-mono text-[#2E7653] block mt-0.5">
            +{Math.round(monthlySurplus / 1000)}k
          </span>
        </div>
      </div>

    </div>
  );
};

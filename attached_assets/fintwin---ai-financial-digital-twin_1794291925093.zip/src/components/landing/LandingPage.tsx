import React from 'react';
import {
  ArrowRight,
  ShieldCheck,
  TrendingUp,
  Target,
  Calculator,
  Bot,
  Activity,
  CheckCircle2,
} from 'lucide-react';

interface LandingPageProps {
  onOpenAuth: (mode: 'login' | 'register') => void;
  onExploreDemo: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onOpenAuth, onExploreDemo }) => {
  return (
    <div className="min-h-screen bg-[#F6F6F2] text-[#111412] flex flex-col selection:bg-[#173F35] selection:text-white select-none">
      
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#DCDDD8] px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-md bg-[#173F35] text-white flex items-center justify-center font-bold text-xs tracking-tighter">
              fT
            </div>
            <div>
              <span className="font-bold text-sm tracking-tight text-[#111412] font-mono">
                fin<span className="text-[#173F35] font-extrabold">TWIN</span>
              </span>
              <span className="text-[10px] text-[#626861] block -mt-0.5 tracking-tight font-medium">
                Financial Digital Twin
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={onExploreDemo}
              className="px-3 py-1.5 rounded-md text-xs font-semibold bg-[#F6F6F2] border border-[#DCDDD8] text-[#173F35] hover:bg-white transition-colors"
            >
              Explore Client Demo
            </button>
            <button
              onClick={() => onOpenAuth('login')}
              className="px-3 py-1.5 rounded-md text-xs font-medium text-[#626861] hover:text-[#111412] transition-colors"
            >
              Sign In
            </button>
            <button
              onClick={() => onOpenAuth('register')}
              className="px-3.5 py-1.5 rounded-md text-xs font-semibold bg-[#173F35] text-white hover:bg-[#1f5446] transition-colors shadow-xs"
            >
              Create Account
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="px-4 pt-16 pb-20 sm:pt-24 sm:pb-28 max-w-4xl mx-auto text-center space-y-6">
        
        {/* Subtitle Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded border border-[#DCDDD8] bg-white text-[#173F35] text-xs font-semibold uppercase tracking-wider">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>See tomorrow before you spend today</span>
        </div>

        <h1 className="text-3xl sm:text-5xl md:text-6xl font-semibold text-[#111412] tracking-tight leading-[1.12]">
          A Serious Instrument for Personal Wealth & Forward Planning.
        </h1>

        <p className="text-sm sm:text-base text-[#626861] max-w-2xl mx-auto leading-relaxed font-normal">
          Consolidate your real financial position, compute net surplus, stress-test economic shocks across time, and simulate capital decisions with deterministic precision.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            onClick={onExploreDemo}
            className="w-full sm:w-auto px-6 py-2.5 rounded-md bg-[#173F35] text-white text-xs font-semibold hover:bg-[#1f5446] transition-colors shadow-xs flex items-center justify-center gap-2"
          >
            <span>Explore Live Ledger</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onOpenAuth('register')}
            className="w-full sm:w-auto px-6 py-2.5 rounded-md bg-white border border-[#DCDDD8] text-[#111412] text-xs font-semibold hover:bg-[#F6F6F2] transition-colors"
          >
            Establish New Ledger
          </button>
        </div>

        {/* Consolidated Financial Summary Teaser */}
        <div className="pt-8">
          <div className="p-5 rounded-lg bg-white border border-[#DCDDD8] shadow-xs text-left grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#626861] tracking-wider block">Financial Health</span>
              <span className="text-lg font-bold font-mono text-[#173F35] block mt-1">78 / 100</span>
              <span className="text-[10px] text-[#2E7653] font-medium block">Low risk profile</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#626861] tracking-wider block">Net Monthly Surplus</span>
              <span className="text-lg font-bold font-mono text-[#111412] block mt-1">+NPR 25,000</span>
              <span className="text-[10px] text-[#626861] font-medium block">31.2% Savings Rate</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#626861] tracking-wider block">Reserve Cushion</span>
              <span className="text-lg font-bold font-mono text-[#111412] block mt-1">3.8 Months</span>
              <span className="text-[10px] text-[#626861] font-medium block">Essential coverage</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#626861] tracking-wider block">5-Year Projected</span>
              <span className="text-lg font-bold font-mono text-[#173F35] block mt-1">NPR 1.8M</span>
              <span className="text-[10px] text-[#2E7653] font-medium block">Optimized trajectory</span>
            </div>
          </div>
        </div>

      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-[#DCDDD8] bg-white py-4 px-4 text-center text-xs text-[#626861]">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>finTWIN • Financial Digital Twin & Wealth Planning Platform</span>
          <span className="font-mono text-[11px]">Client confidential data encrypted locally</span>
        </div>
      </footer>

    </div>
  );
};

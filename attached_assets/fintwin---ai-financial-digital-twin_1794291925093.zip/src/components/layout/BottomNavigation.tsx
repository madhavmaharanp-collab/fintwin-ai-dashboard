import React from 'react';
import {
  LayoutDashboard,
  Activity,
  BarChart3,
  Target,
  Calculator,
  Bot,
  Plus,
} from 'lucide-react';

export type ActiveTab = 'dashboard' | 'fintwin' | 'transactions' | 'goals' | 'simulators' | 'ai' | 'reports';

interface BottomNavigationProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  openQuickAdd: () => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  setActiveTab,
  openQuickAdd,
}) => {
  const navItems: { id: ActiveTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'transactions', label: 'Ledger', icon: BarChart3 },
    { id: 'goals', label: 'Goals', icon: Target },
    { id: 'fintwin', label: 'Twin', icon: Activity },
    { id: 'simulators', label: 'Simulate', icon: Calculator },
    { id: 'ai', label: 'Copilot', icon: Bot },
  ];

  return (
    <div className="sticky bottom-0 left-0 right-0 z-40 bg-white border-t border-[#DCDDD8] px-2 py-1 flex items-center justify-around select-none">
      {navItems.map((item, index) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;

        if (index === 3) {
          return (
            <React.Fragment key="quick-add-group">
              {/* Record Entry Quick Button */}
              <button
                onClick={openQuickAdd}
                className="w-8 h-8 rounded bg-[#173F35] text-white flex items-center justify-center hover:bg-[#1f5446] transition-colors shadow-xs"
                title="Record Financial Transaction"
              >
                <Plus className="w-4 h-4 stroke-[2.5px]" />
              </button>

              <button
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
                  isActive ? 'text-[#173F35]' : 'text-[#626861] hover:text-[#111412]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
                <span className={`text-[10px] mt-0.5 ${isActive ? 'font-bold' : 'font-medium'} tracking-tight`}>
                  {item.label}
                </span>
              </button>
            </React.Fragment>
          );
        }

        return (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
              isActive ? 'text-[#173F35]' : 'text-[#626861] hover:text-[#111412]'
            }`}
          >
            <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
            <span className={`text-[10px] mt-0.5 ${isActive ? 'font-bold' : 'font-medium'} tracking-tight`}>
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
  );
};

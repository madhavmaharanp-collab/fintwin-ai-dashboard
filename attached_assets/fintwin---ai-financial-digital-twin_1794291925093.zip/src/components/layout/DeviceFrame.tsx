import React from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface DeviceFrameProps {
  children: React.ReactNode;
  isMobileFrame: boolean;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children, isMobileFrame }) => {
  if (!isMobileFrame) {
    return <div className="min-h-screen w-full flex flex-col bg-[#F7F8F5]">{children}</div>;
  }

  // Current real-time clock for the mobile status bar
  const now = new Date();
  const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <div className="min-h-screen w-full bg-[#111412] flex items-center justify-center p-0 sm:p-4 md:p-6 lg:p-8 overflow-x-hidden">
      {/* Phone container */}
      <div className="relative w-full max-w-[430px] h-[100dvh] sm:h-[880px] bg-[#F7F8F5] sm:rounded-[52px] shadow-2xl sm:border-[10px] sm:border-[#222725] sm:ring-1 sm:ring-white/20 flex flex-col overflow-hidden">
        
        {/* Dynamic Island / Speaker Notch (Desktop frame only) */}
        <div className="hidden sm:flex absolute top-2 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-50 items-center justify-between px-3">
          <div className="w-2.5 h-2.5 rounded-full bg-[#111] ring-1 ring-zinc-700/50"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-[#173F35]/80 animate-pulse"></div>
        </div>

        {/* Mobile Status Bar */}
        <div className="w-full h-11 pt-2 px-6 flex items-center justify-between text-xs font-semibold text-[#111412] select-none shrink-0 z-40 bg-white/70 backdrop-blur-md border-b border-[#E5E8E3]">
          <span className="tracking-tight">{timeString}</span>
          <div className="flex items-center gap-1.5 opacity-80">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <Battery className="w-4 h-4" />
          </div>
        </div>

        {/* Screen Content */}
        <div className="flex-1 w-full overflow-y-auto overflow-x-hidden flex flex-col relative">
          {children}
        </div>

        {/* iOS Home Indicator Bar */}
        <div className="w-full h-5 flex items-center justify-center shrink-0 bg-white/80 backdrop-blur-md select-none">
          <div className="w-32 h-1 bg-[#111412]/30 rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

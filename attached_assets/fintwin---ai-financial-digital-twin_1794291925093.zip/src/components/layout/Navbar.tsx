import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useFinance } from '../../context/FinanceContext';
import { ActiveTab } from './BottomNavigation';
import {
  Search,
  Bell,
  LogOut,
  Smartphone,
  Monitor,
  ShieldCheck,
  Check,
  Plus,
  SlidersHorizontal,
  ChevronDown,
} from 'lucide-react';

interface NavbarProps {
  activeTab: ActiveTab;
  isMobileFrame: boolean;
  setIsMobileFrame: (val: boolean) => void;
  openCreateSheet: () => void;
  openAffordability: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  isMobileFrame,
  setIsMobileFrame,
  openCreateSheet,
  openAffordability,
}) => {
  const { user, logout, isDemoUser } = useAuth();
  const { sheets, activeSheetId, setActiveSheetId, currency } = useFinance();
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showNotifs, setShowNotifs] = useState(false);

  // Tab Title Mapping
  const getTabTitle = (tab: ActiveTab) => {
    switch (tab) {
      case 'dashboard':
        return 'Overview';
      case 'transactions':
        return 'Transactions & Ledger';
      case 'goals':
        return 'Financial Goals';
      case 'fintwin':
        return 'Financial Twin';
      case 'simulators':
        return 'Simulations & SIP Planning';
      case 'ai':
        return 'AI Copilot';
      case 'reports':
        return 'Financial Reports';
      default:
        return 'Workspace';
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-[#DCDDD8] px-4 py-2.5 select-none">
      <div className="flex items-center justify-between gap-3 max-w-7xl mx-auto">
        
        {/* Left: Page Title & Current Date Period */}
        <div>
          <h1 className="text-base sm:text-lg font-bold text-[#111412] tracking-tight leading-none">
            {getTabTitle(activeTab)}
          </h1>
          <p className="text-[11px] text-[#626861] mt-1 font-medium">
            Financial Position as of October 2026 • Ledger: <span className="font-semibold text-[#111412]">{sheets.find(s => s.id === activeSheetId)?.name || 'Personal'}</span>
          </p>
        </div>

        {/* Right: Actions, Currency, Device Frame Toggle, Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Device Frame Simulator Switch */}
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-[#DCDDD8] text-[11px] font-medium text-[#626861] hover:text-[#111412] hover:bg-[#F6F6F2] transition-colors"
            title="Toggle between Desktop Workspace and Mobile Device Mode"
          >
            {isMobileFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-[#173F35]" />
                <span className="hidden sm:inline">Desktop Mode</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-[#173F35]" />
                <span className="hidden sm:inline">Mobile Frame</span>
              </>
            )}
          </button>

          {/* Currency Pill */}
          <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-[#F6F6F2] border border-[#DCDDD8] text-[#111412]">
            {currency}
          </span>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifs(!showNotifs)}
              className="p-1.5 rounded-md border border-[#DCDDD8] text-[#626861] hover:text-[#111412] hover:bg-[#F6F6F2] transition-colors relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-[#173F35]"></span>
            </button>

            {showNotifs && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-lg shadow-lg border border-[#DCDDD8] p-3 z-50 text-xs">
                <span className="font-bold text-[#111412] block border-b border-[#F0F1ED] pb-1.5 mb-2">
                  System Notifications
                </span>
                <div className="space-y-2 text-[#626861]">
                  <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8]">
                    <span className="font-semibold text-[#111412] block">October Statement Ready</span>
                    <p className="text-[11px] text-[#626861] mt-0.5">Surplus savings rate reached 31.2% this cycle.</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowUserDropdown(!showUserDropdown)}
              className="flex items-center gap-1.5 p-1 rounded-md hover:bg-[#F6F6F2] border border-transparent hover:border-[#DCDDD8] transition-colors"
            >
              <div className="w-7 h-7 rounded-md bg-[#173F35] text-white flex items-center justify-center text-xs font-bold font-mono">
                {user?.name?.charAt(0) || 'M'}
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-[#626861]" />
            </button>

            {showUserDropdown && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-lg shadow-lg border border-[#DCDDD8] p-2 z-50 text-xs">
                <div className="px-2 py-1.5 border-b border-[#F0F1ED] mb-1">
                  <p className="font-semibold text-[#111412] truncate">{user?.name}</p>
                  <p className="text-[10px] text-[#626861] truncate font-mono">{user?.email}</p>
                </div>

                <div className="px-2 py-1 text-[11px] text-[#626861]">
                  Base Currency: <strong className="text-[#111412]">{currency}</strong>
                </div>

                <div className="border-t border-[#F0F1ED] mt-1 pt-1">
                  <button
                    onClick={logout}
                    className="w-full flex items-center gap-2 px-2 py-1.5 text-xs text-[#B94A48] hover:bg-red-50 rounded transition-colors font-medium"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};

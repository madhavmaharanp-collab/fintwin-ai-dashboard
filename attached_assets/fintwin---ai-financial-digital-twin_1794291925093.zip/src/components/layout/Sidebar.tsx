import React from 'react';
import { ActiveTab } from './BottomNavigation';
import { useAuth } from '../../context/AuthContext';
import { useFinance } from '../../context/FinanceContext';
import {
  LayoutDashboard,
  Receipt,
  Target,
  Calculator,
  Bot,
  FileText,
  Activity,
  Calendar,
  PieChart,
  Shield,
  Layers,
  ChevronRight,
  TrendingUp,
  CreditCard,
  Settings,
  Sparkles,
  LogOut,
  ChevronDown,
} from 'lucide-react';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  openCreateSheet: () => void;
  openAffordability: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  openCreateSheet,
  openAffordability,
}) => {
  const { user, logout, isDemoUser } = useAuth();
  const { sheets, activeSheetId, setActiveSheetId, currency, data } = useFinance();

  const activeSheet = sheets.find((s) => s.id === activeSheetId) || sheets[0];

  const navGroups = [
    {
      group: 'OVERVIEW',
      items: [
        { id: 'dashboard' as ActiveTab, label: 'Overview', icon: LayoutDashboard },
      ],
    },
    {
      group: 'MONEY',
      items: [
        { id: 'transactions' as ActiveTab, label: 'Transactions', icon: Receipt },
      ],
    },
    {
      group: 'PLANNING',
      items: [
        { id: 'goals' as ActiveTab, label: 'Goals & Milestones', icon: Target },
      ],
    },
    {
      group: 'FUTURE',
      items: [
        { id: 'fintwin' as ActiveTab, label: 'Financial Twin', icon: Activity, badge: 'Twin' },
        { id: 'simulators' as ActiveTab, label: 'Simulator & SIP', icon: Calculator },
      ],
    },
    {
      group: 'INTELLIGENCE',
      items: [
        { id: 'ai' as ActiveTab, label: 'AI Copilot', icon: Bot, badge: 'Insight' },
      ],
    },
    {
      group: 'REPORTS',
      items: [
        { id: 'reports' as ActiveTab, label: 'Financial Reports', icon: FileText },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-white border-r border-[#DCDDD8] flex flex-col justify-between select-none h-full shrink-0">
      
      {/* Brand Header */}
      <div className="p-4 border-b border-[#DCDDD8]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-8 h-8 rounded-md bg-[#173F35] text-white flex items-center justify-center font-bold text-xs tracking-tighter">
              fT
            </div>
            <div>
              <span className="text-sm font-bold tracking-tight text-[#111412] flex items-center gap-1 font-mono">
                fin<span className="font-extrabold text-[#173F35]">TWIN</span>
              </span>
              <span className="text-[10px] text-[#626861] block -mt-0.5 tracking-tight font-medium">
                Financial Digital Twin
              </span>
            </div>
          </div>

          <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded border border-[#DCDDD8] text-[#173F35] bg-[#F6F6F2]">
            {currency}
          </span>
        </div>

        {/* Financial Sheet Switcher */}
        <div className="mt-3 pt-2.5 border-t border-[#F0F1ED] flex items-center justify-between">
          <div className="min-w-0">
            <span className="text-[9px] uppercase tracking-wider text-[#626861] font-semibold block">Active Ledger</span>
            <span className="text-xs font-semibold text-[#111412] truncate block">
              {activeSheet?.name || 'Personal Finance'}
            </span>
          </div>
          <button
            onClick={openCreateSheet}
            className="text-[11px] text-[#173F35] hover:text-[#111412] font-semibold px-2 py-0.5 rounded hover:bg-[#F6F6F2] transition-colors"
            title="Create or switch sheet"
          >
            Switch
          </button>
        </div>
      </div>

      {/* Navigation Group Items */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-4">
        {navGroups.map((grp) => (
          <div key={grp.group} className="space-y-1">
            <span className="px-2 text-[10px] font-bold text-[#626861] tracking-wider uppercase">
              {grp.group}
            </span>
            <div className="space-y-0.5 mt-1">
              {grp.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-[#173F35] text-white'
                        : 'text-[#111412] hover:bg-[#F6F6F2] hover:text-[#173F35]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-[#C9E875]' : 'text-[#626861]'}`} />
                      <span>{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-semibold ${
                          isActive
                            ? 'bg-[#C9E875] text-[#173F35]'
                            : 'bg-[#F6F6F2] border border-[#DCDDD8] text-[#626861]'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {/* Quick Analytical Instrument */}
        <div className="pt-2">
          <button
            onClick={openAffordability}
            className="w-full flex items-center justify-between px-2.5 py-2 rounded-md border border-[#DCDDD8] bg-[#F6F6F2] hover:bg-white text-xs font-semibold text-[#173F35] transition-colors"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#B78327]" />
              <span>Purchase Assessment</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-[#626861]" />
          </button>
        </div>
      </nav>

      {/* User Status Footer */}
      <div className="p-3 border-t border-[#DCDDD8] bg-[#F6F6F2]/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-7 h-7 rounded-md bg-[#173F35] text-[#C9E875] flex items-center justify-center text-xs font-bold shrink-0">
              {user?.name?.charAt(0) || 'M'}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-[#111412] truncate">{user?.name}</p>
              <p className="text-[10px] text-[#626861] truncate font-mono">{isDemoUser ? 'Client Account' : user?.email}</p>
            </div>
          </div>

          <button
            onClick={logout}
            className="p-1.5 rounded-md hover:bg-[#DCDDD8]/50 text-[#626861] hover:text-[#B94A48] transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </aside>
  );
};

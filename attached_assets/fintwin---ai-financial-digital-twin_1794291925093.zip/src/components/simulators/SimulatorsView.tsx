import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import {
  formatCurrency,
  calculateSIPProjection,
  calculateWhatIfScenario,
  analyzeAffordability,
} from '../../calculations/financeEngine';
import {
  Calculator,
  TrendingUp,
  Sliders,
  Sparkles,
  HelpCircle,
  AlertTriangle,
  ShieldCheck,
  ChevronRight,
  Layers,
  CheckCircle2,
  DollarSign,
  ArrowRight,
} from 'lucide-react';

export const SimulatorsView: React.FC = () => {
  const { data, currency } = useFinance();
  const [activeTab, setActiveTab] = useState<'sip' | 'whatif' | 'compound' | 'education'>('sip');

  // SIP Calculator State
  const [sipMonthly, setSipMonthly] = useState<number>(5000);
  const [sipYears, setSipYears] = useState<number>(10);
  const [sipRate, setSipRate] = useState<number>(10);
  const [sipInitial, setSipInitial] = useState<number>(0);

  // What-If Simulator State
  const [salaryChange, setSalaryChange] = useState<number>(15000);
  const [rentChange, setRentChange] = useState<number>(0);
  const [newLoanAmount, setNewLoanAmount] = useState<number>(0);
  const [newLoanMonths, setNewLoanMonths] = useState<number>(36);

  const profile = data.profile;

  // SIP Projections
  const currentSip = calculateSIPProjection(sipMonthly, sipYears, sipRate, sipInitial);
  const sip3k = calculateSIPProjection(3000, sipYears, sipRate, sipInitial);
  const sip5k = calculateSIPProjection(5000, sipYears, sipRate, sipInitial);
  const sip10k = calculateSIPProjection(10000, sipYears, sipRate, sipInitial);

  // What-If Results
  const whatIfResult = profile
    ? calculateWhatIfScenario(profile, {
        incomeChangeMonthly: salaryChange,
        rentChangeMonthly: rentChange,
        newLoanAmount: newLoanAmount > 0 ? newLoanAmount : undefined,
        newLoanMonths: newLoanAmount > 0 ? newLoanMonths : undefined,
        newLoanRate: 9.5,
      })
    : null;

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6 pb-20 select-none">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 border-b border-[#DCDDD8] pb-3">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#626861] font-bold block mb-1">
            Quantitative Modeling
          </span>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#111412] tracking-tight">
            Simulations & Quantitative Planning
          </h1>
          <p className="text-xs text-[#626861]">
            Deterministic mathematical projections, compound interest models, and scenario impact tests.
          </p>
        </div>

        {/* Tab pills */}
        <div className="flex p-0.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded text-xs overflow-x-auto self-start sm:self-auto font-mono">
          <button
            onClick={() => setActiveTab('sip')}
            className={`px-3 py-1 font-semibold rounded transition-colors whitespace-nowrap ${
              activeTab === 'sip' ? 'bg-[#173F35] text-white shadow-xs' : 'text-[#626861] hover:text-[#111412]'
            }`}
          >
            SIP Calculator
          </button>
          <button
            onClick={() => setActiveTab('whatif')}
            className={`px-3 py-1 font-semibold rounded transition-colors whitespace-nowrap ${
              activeTab === 'whatif' ? 'bg-[#173F35] text-white shadow-xs' : 'text-[#626861] hover:text-[#111412]'
            }`}
          >
            What-If Simulator
          </button>
          <button
            onClick={() => setActiveTab('compound')}
            className={`px-3 py-1 font-semibold rounded transition-colors whitespace-nowrap ${
              activeTab === 'compound' ? 'bg-[#173F35] text-white shadow-xs' : 'text-[#626861] hover:text-[#111412]'
            }`}
          >
            Compound Breakdown
          </button>
          <button
            onClick={() => setActiveTab('education')}
            className={`px-3 py-1 font-semibold rounded transition-colors whitespace-nowrap ${
              activeTab === 'education' ? 'bg-[#173F35] text-white shadow-xs' : 'text-[#626861] hover:text-[#111412]'
            }`}
          >
            Investment Models
          </button>
        </div>
      </div>

      {/* TAB 1: SIP CALCULATOR */}
      {activeTab === 'sip' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            
            {/* Controls */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-[#173F35]" />
                Investment Inputs
              </h3>

              {/* Monthly Contribution */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-zinc-700 mb-1">
                  <span>Monthly Contribution</span>
                  <span className="font-mono text-[#173F35]">
                    {formatCurrency(sipMonthly, currency)}
                  </span>
                </div>
                <input
                  type="range"
                  min="1000"
                  max="50000"
                  step="1000"
                  value={sipMonthly}
                  onChange={(e) => setSipMonthly(Number(e.target.value))}
                  className="w-full accent-[#173F35]"
                />
                <div className="flex justify-between text-[10px] text-zinc-400 mt-1">
                  <span>{currency} 1k</span>
                  <span>{currency} 50k</span>
                </div>
              </div>

              {/* Duration Years */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-zinc-700 mb-1">
                  <span>Time Horizon</span>
                  <span className="font-mono text-[#173F35]">{sipYears} Years</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="30"
                  step="1"
                  value={sipYears}
                  onChange={(e) => setSipYears(Number(e.target.value))}
                  className="w-full accent-[#173F35]"
                />
                <div className="flex justify-between text-[10px] text-zinc-400 mt-1">
                  <span>1 yr</span>
                  <span>30 yrs</span>
                </div>
              </div>

              {/* Expected Return Rate */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-zinc-700 mb-1">
                  <span>Illustrative Annual Return</span>
                  <span className="font-mono text-[#173F35]">{sipRate}% p.a.</span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="18"
                  step="0.5"
                  value={sipRate}
                  onChange={(e) => setSipRate(Number(e.target.value))}
                  className="w-full accent-[#173F35]"
                />
                <div className="flex justify-between text-[10px] text-zinc-400 mt-1">
                  <span>4% (Conservative)</span>
                  <span>18% (Aggressive)</span>
                </div>
              </div>

              {/* Initial Investment */}
              <div>
                <label className="text-xs font-semibold text-zinc-700 block mb-1">
                  Initial Starting Lump Sum ({currency})
                </label>
                <input
                  type="number"
                  value={sipInitial}
                  onChange={(e) => setSipInitial(Number(e.target.value))}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-zinc-200 font-mono"
                  placeholder="0"
                />
              </div>

              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 leading-relaxed">
                <strong>Illustrative Assumption:</strong> Returns are estimates for financial planning. Market investments fluctuate and returns are never guaranteed.
              </div>
            </div>

            {/* Results & Visual Projection */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs lg:col-span-2 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-zinc-100">
                  <div>
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                      Projected Outcome
                    </span>
                    <h3 className="text-base font-bold text-zinc-900">
                      Estimated Future Wealth
                    </h3>
                  </div>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800">
                    Compound Growth
                  </span>
                </div>

                {/* Big numbers */}
                <div className="grid grid-cols-3 gap-2.5 mt-4">
                  <div className="p-3 rounded-xl bg-[#F7F8F5] border border-[#E5E8E3]">
                    <span className="text-[10px] text-zinc-500 uppercase font-semibold">Total Invested</span>
                    <div className="text-sm sm:text-base font-bold font-mono text-zinc-900 mt-0.5">
                      {formatCurrency(currentSip.totalContributed, currency)}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-100">
                    <span className="text-[10px] text-emerald-800 uppercase font-semibold">Estimated Growth</span>
                    <div className="text-sm sm:text-base font-bold font-mono text-emerald-700 mt-0.5">
                      +{formatCurrency(currentSip.estimatedGrowth, currency)}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#173F35] text-white">
                    <span className="text-[10px] text-[#C9F36B] uppercase font-semibold">Total Value</span>
                    <div className="text-sm sm:text-base font-bold font-mono text-white mt-0.5">
                      {formatCurrency(currentSip.estimatedFutureValue, currency)}
                    </div>
                  </div>
                </div>

                {/* Visual Ratio Bar */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex justify-between text-xs text-zinc-500 font-medium">
                    <span>Principal Invested ({Math.round((currentSip.totalContributed / currentSip.estimatedFutureValue) * 100)}%)</span>
                    <span>Compound Interest ({Math.round((currentSip.estimatedGrowth / currentSip.estimatedFutureValue) * 100)}%)</span>
                  </div>
                  <div className="w-full h-3 bg-zinc-100 rounded-full overflow-hidden flex">
                    <div
                      style={{
                        width: `${Math.round(
                          (currentSip.totalContributed / currentSip.estimatedFutureValue) * 100
                        )}%`,
                      }}
                      className="bg-zinc-700 h-full"
                    ></div>
                    <div
                      style={{
                        width: `${Math.round(
                          (currentSip.estimatedGrowth / currentSip.estimatedFutureValue) * 100
                        )}%`,
                      }}
                      className="bg-[#C9F36B] h-full"
                    ></div>
                  </div>
                </div>
              </div>

              {/* Scenario Comparison Grid (Section 12 spec: 3k vs 5k vs 10k) */}
              <div className="pt-3 border-t border-zinc-100">
                <span className="text-xs font-bold text-zinc-800 block mb-2">
                  Compare Monthly Scenarios ({sipYears} Years @ {sipRate}%)
                </span>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl border border-zinc-200 bg-zinc-50">
                    <div className="font-bold text-zinc-700">{formatCurrency(3000, currency)}/mo</div>
                    <div className="text-[10px] text-zinc-400 mt-1">Invested: {formatCurrency(sip3k.totalContributed, currency)}</div>
                    <div className="font-bold font-mono text-[#173F35] mt-0.5">
                      {formatCurrency(sip3k.estimatedFutureValue, currency)}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl border-2 border-[#173F35] bg-emerald-50/30">
                    <div className="font-bold text-[#173F35]">{formatCurrency(5000, currency)}/mo (Current)</div>
                    <div className="text-[10px] text-zinc-400 mt-1">Invested: {formatCurrency(sip5k.totalContributed, currency)}</div>
                    <div className="font-bold font-mono text-[#173F35] mt-0.5">
                      {formatCurrency(sip5k.estimatedFutureValue, currency)}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl border border-zinc-200 bg-zinc-50">
                    <div className="font-bold text-zinc-700">{formatCurrency(10000, currency)}/mo</div>
                    <div className="text-[10px] text-zinc-400 mt-1">Invested: {formatCurrency(sip10k.totalContributed, currency)}</div>
                    <div className="font-bold font-mono text-[#173F35] mt-0.5">
                      {formatCurrency(sip10k.estimatedFutureValue, currency)}
                    </div>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* TAB 2: WHAT-IF SIMULATOR */}
      {activeTab === 'whatif' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-zinc-900 text-white">
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#C9F36B]" />
              Safe Sandbox Environment
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              Test hypothetical financial decisions. Adjusting sliders here will <strong>never alter your real verified data</strong>.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Scenario Adjusters */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs space-y-4">
              <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                Simulated Adjustments
              </h4>

              {/* Salary Increase */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-zinc-700 mb-1">
                  <span>Salary Increase / Decrease</span>
                  <span className="font-mono text-[#173F35]">
                    {salaryChange >= 0 ? `+${salaryChange.toLocaleString()}` : salaryChange.toLocaleString()} {currency}/mo
                  </span>
                </div>
                <input
                  type="range"
                  min="-20000"
                  max="50000"
                  step="2000"
                  value={salaryChange}
                  onChange={(e) => setSalaryChange(Number(e.target.value))}
                  className="w-full accent-[#173F35]"
                />
              </div>

              {/* Rent Increase */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-zinc-700 mb-1">
                  <span>Housing / Rent Increase</span>
                  <span className="font-mono text-red-600">
                    +{rentChange.toLocaleString()} {currency}/mo
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20000"
                  step="1000"
                  value={rentChange}
                  onChange={(e) => setRentChange(Number(e.target.value))}
                  className="w-full accent-red-600"
                />
              </div>

              {/* New Loan */}
              <div>
                <div className="flex justify-between text-xs font-semibold text-zinc-700 mb-1">
                  <span>New Loan Obligation (Principal)</span>
                  <span className="font-mono text-zinc-900">
                    {formatCurrency(newLoanAmount, currency)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1000000"
                  step="50000"
                  value={newLoanAmount}
                  onChange={(e) => setNewLoanAmount(Number(e.target.value))}
                  className="w-full accent-zinc-700"
                />
              </div>
            </div>

            {/* Simulated Outcome */}
            {whatIfResult && (
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs space-y-4 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                    Calculated Scenario Impact
                  </h4>

                  <div className="grid grid-cols-2 gap-3 mt-3">
                    <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-100">
                      <span className="text-[10px] text-zinc-400 block">Baseline Monthly Surplus</span>
                      <span className="text-sm font-bold font-mono text-zinc-800">
                        {formatCurrency(whatIfResult.originalSurplus, currency)}
                      </span>
                      <span className="text-[10px] text-zinc-500 block mt-0.5">
                        {whatIfResult.originalSavingsRate}% rate
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100">
                      <span className="text-[10px] text-emerald-700 block">Simulated Monthly Surplus</span>
                      <span className="text-sm font-bold font-mono text-emerald-800">
                        {formatCurrency(whatIfResult.newSurplus, currency)}
                      </span>
                      <span className="text-[10px] text-emerald-700 block mt-0.5">
                        {whatIfResult.newSavingsRate}% rate ({whatIfResult.surplusDifference >= 0 ? '+' : ''}{formatCurrency(whatIfResult.surplusDifference, currency)})
                      </span>
                    </div>
                  </div>

                  {/* Impact points */}
                  <div className="mt-3 space-y-1.5 text-xs text-zinc-600">
                    {whatIfResult.impactAnalysis.map((item, i) => (
                      <div key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#173F35] shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#F7F8F5] border border-[#E5E8E3] text-xs text-zinc-700 leading-relaxed">
                  <strong>Recommendation:</strong> {whatIfResult.recommendation}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: COMPOUND GROWTH BREAKDOWN */}
      {activeTab === 'compound' && (
        <div className="bg-white rounded-2xl border border-[#E5E8E3] overflow-hidden shadow-xs">
          <div className="p-4 border-b border-zinc-100">
            <h3 className="text-sm font-bold text-zinc-900">
              Year-by-Year Compound Growth Progression
            </h3>
            <p className="text-xs text-zinc-500">
              Monthly contribution of {formatCurrency(sipMonthly, currency)} @ {sipRate}% annual return
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-[#F7F8F5] text-zinc-500 uppercase tracking-wider font-semibold border-b border-[#E5E8E3]">
                <tr>
                  <th className="py-2.5 px-4">Year</th>
                  <th className="py-2.5 px-4">Total Deposited</th>
                  <th className="py-2.5 px-4">Compound Earnings</th>
                  <th className="py-2.5 px-4 text-right">Estimated Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 font-mono">
                {currentSip.yearlyBreakdown.map((row) => (
                  <tr key={row.year} className="hover:bg-zinc-50">
                    <td className="py-2 px-4 font-sans font-bold text-zinc-900">Year {row.year}</td>
                    <td className="py-2 px-4 text-zinc-600">{formatCurrency(row.contributed, currency)}</td>
                    <td className="py-2 px-4 text-emerald-700">+{formatCurrency(row.interestEarned, currency)}</td>
                    <td className="py-2 px-4 text-right font-bold text-[#173F35]">
                      {formatCurrency(row.balance, currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: EXPLORE INVESTMENTS (EDUCATION & SAFETY) */}
      {activeTab === 'education' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs leading-relaxed">
            <div className="flex items-center gap-2 font-bold mb-1">
              <AlertTriangle className="w-4 h-4 text-amber-700" />
              <span>Financial Education & Safety Notice</span>
            </div>
            This educational platform does not provide licensed broker advice. Projections are illustrative. Always evaluate personal risk tolerance, liquidity requirements, expense ratios, and tax implications before investing capital.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Mutual Funds / SIP */}
            <div className="p-4 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs space-y-2">
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider bg-emerald-50 px-2 py-0.5 rounded-full">
                Regular Investing
              </span>
              <h4 className="text-sm font-bold text-zinc-900">SIP & Mutual Funds</h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Systematic Investment Plans (SIP) invest a fixed sum periodically. This utilizes Rupee Cost Averaging, buying more units when market prices dip and fewer when prices rise.
              </p>
              <div className="text-[11px] text-zinc-500 pt-1 border-t border-zinc-100">
                <strong>Risks:</strong> Market volatility, equity drawdowns, management expense ratios.
              </div>
            </div>

            {/* Fixed Deposits */}
            <div className="p-4 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs space-y-2">
              <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider bg-blue-50 px-2 py-0.5 rounded-full">
                Capital Preservation
              </span>
              <h4 className="text-sm font-bold text-zinc-900">Fixed Deposits & Treasury</h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Guaranteed interest rate locked for a fixed duration (e.g. 1-5 years). Ideal for emergency reserves and short-term capital where preservation of principal is non-negotiable.
              </p>
              <div className="text-[11px] text-zinc-500 pt-1 border-t border-zinc-100">
                <strong>Risks:</strong> Inflation drag (returns may trail inflation), penalty on early withdrawal.
              </div>
            </div>

            {/* Government Securities */}
            <div className="p-4 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs space-y-2">
              <span className="text-[10px] font-bold text-purple-700 uppercase tracking-wider bg-purple-50 px-2 py-0.5 rounded-full">
                Sovereign Backed
              </span>
              <h4 className="text-sm font-bold text-zinc-900">Government Bonds & Debentures</h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Debt securities issued by central banks or national governments. Pays periodic coupon yield with sovereign principal protection upon maturity.
              </p>
              <div className="text-[11px] text-zinc-500 pt-1 border-t border-zinc-100">
                <strong>Risks:</strong> Interest rate fluctuations, lock-in duration.
              </div>
            </div>

            {/* Equity Stocks */}
            <div className="p-4 rounded-2xl bg-white border border-[#E5E8E3] shadow-xs space-y-2">
              <span className="text-[10px] font-bold text-red-700 uppercase tracking-wider bg-red-50 px-2 py-0.5 rounded-full">
                Growth & Volatility
              </span>
              <h4 className="text-sm font-bold text-zinc-900">Public Equity Stocks</h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Direct fractional ownership in publicly listed corporations. High long-term upside potential accompanied by substantial short-term price swings.
              </p>
              <div className="text-[11px] text-zinc-500 pt-1 border-t border-zinc-100">
                <strong>Risks:</strong> Loss of principal, business risk, market sentiment.
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};

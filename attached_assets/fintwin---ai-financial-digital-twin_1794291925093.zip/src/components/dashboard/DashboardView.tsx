import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useFinance } from '../../context/FinanceContext';
import { formatCurrency, formatCurrencyCompact } from '../../calculations/financeEngine';
import { ActiveTab } from '../layout/BottomNavigation';
import {
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  Shield,
  Sparkles,
  ChevronRight,
  Calendar,
  Layers,
  ArrowRight,
  Info,
} from 'lucide-react';

interface DashboardViewProps {
  setActiveTab: (tab: ActiveTab) => void;
  openHealthScoreModal: () => void;
  openAffordabilityModal: () => void;
  openQuickAddModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  setActiveTab,
  openHealthScoreModal,
  openAffordabilityModal,
  openQuickAddModal,
}) => {
  const { user } = useAuth();
  const { data, currency, activeSheetId, sheets } = useFinance();
  const [cashFlowRange, setCashFlowRange] = useState<'1M' | '3M' | '6M' | '1Y'>('6M');

  const profile = data.profile;
  const currentSheet = sheets.find((s) => s.id === activeSheetId) || data.sheet;

  const firstName = user?.name ? user.name.split(' ')[0] : 'there';
  const hour = new Date().getHours();
  let greeting = 'Good morning';
  if (hour >= 12 && hour < 17) greeting = 'Good afternoon';
  else if (hour >= 17) greeting = 'Good evening';

  const monthlyIncome = profile?.totalMonthlyIncome || 80000;
  const monthlyExpenses = profile?.totalMonthlyExpenses || 48000;
  const netSavings = profile?.monthlySurplus || 20000;
  const totalBalance = profile?.totalLiquidSavings || 425000;
  const totalDebt = profile?.totalDebtBalance || 80000;
  const totalAssets = totalBalance + (data.goals.reduce((acc, g) => acc + g.currentAmount, 0));
  const netWorth = totalAssets - totalDebt;

  // Spending Category Breakdown
  const spendingCategories = [
    { name: 'Housing & Rent', amount: 15000, pct: 31 },
    { name: 'Food & Nutrition', amount: 8500, pct: 18 },
    { name: 'Transportation', amount: 5000, pct: 10 },
    { name: 'Utilities & Internet', amount: 4000, pct: 8 },
    { name: 'Other Living Costs', amount: 15500, pct: 33 },
  ];

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6 pb-20 select-none">
      
      {/* Editorial Welcome Header (Section 10 spec) */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 border-b border-[#DCDDD8] pb-4">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#626861] font-bold block mb-1">
            Financial Statement
          </span>
          <h1 className="text-2xl sm:text-3xl font-semibold text-[#111412] tracking-tight">
            {greeting}, {firstName}.
          </h1>
          <p className="text-xs text-[#626861] mt-1 font-medium">
            Your consolidated financial position as of October 4, 2026.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('fintwin')}
            className="px-3 py-1.5 rounded-md border border-[#173F35] bg-[#173F35] text-white text-xs font-semibold hover:bg-[#1f5446] transition-colors"
          >
            Open Financial Twin
          </button>
          <button
            onClick={openQuickAddModal}
            className="px-3 py-1.5 rounded-md border border-[#DCDDD8] bg-white hover:bg-[#F6F6F2] text-[#111412] text-xs font-semibold transition-colors"
          >
            Record Entry
          </button>
        </div>
      </div>

      {/* Compact KPI Row (Section 10 spec) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* Total Balance */}
        <div className="p-4 rounded-lg bg-white border border-[#DCDDD8]">
          <span className="text-[10px] uppercase tracking-wider text-[#626861] font-semibold block">
            Total Balance
          </span>
          <div className="text-xl font-bold font-mono tracking-tight text-[#111412] mt-1.5">
            {formatCurrency(totalBalance, currency)}
          </div>
          <span className="text-[10px] text-[#626861] block mt-1">Liquid depository accounts</span>
        </div>

        {/* Monthly Income */}
        <div className="p-4 rounded-lg bg-white border border-[#DCDDD8]">
          <span className="text-[10px] uppercase tracking-wider text-[#626861] font-semibold block">
            Monthly Income
          </span>
          <div className="text-xl font-bold font-mono tracking-tight text-[#111412] mt-1.5">
            {formatCurrency(monthlyIncome, currency)}
          </div>
          <span className="text-[10px] text-[#2E7653] font-medium block mt-1">+6.7% vs prior cycle</span>
        </div>

        {/* Monthly Expenses */}
        <div className="p-4 rounded-lg bg-white border border-[#DCDDD8]">
          <span className="text-[10px] uppercase tracking-wider text-[#626861] font-semibold block">
            Monthly Expenses
          </span>
          <div className="text-xl font-bold font-mono tracking-tight text-[#111412] mt-1.5">
            {formatCurrency(monthlyExpenses, currency)}
          </div>
          <span className="text-[10px] text-[#2E7653] font-medium block mt-1">-5.9% living cost discipline</span>
        </div>

        {/* Net Savings */}
        <div className="p-4 rounded-lg bg-white border border-[#DCDDD8]">
          <span className="text-[10px] uppercase tracking-wider text-[#626861] font-semibold block">
            Net Savings Surplus
          </span>
          <div className="text-xl font-bold font-mono tracking-tight text-[#173F35] mt-1.5">
            +{formatCurrency(netSavings, currency)}
          </div>
          <span className="text-[10px] text-[#626861] font-medium block mt-1">
            Savings Rate: <strong className="text-[#111412]">{profile?.savingsRate.toFixed(1) || 25.0}%</strong>
          </span>
        </div>

      </div>

      {/* Month Progress Strip (Section 13 spec) */}
      <div className="p-3.5 rounded-lg bg-white border border-[#DCDDD8] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <span className="font-bold tracking-wider uppercase text-[10px] px-2 py-0.5 rounded bg-[#F6F6F2] border border-[#DCDDD8] text-[#173F35]">
            October 2026
          </span>
          <div className="flex items-center gap-2 font-mono text-[11px] text-[#626861]">
            <span>26 DAYS PASSED</span>
            <span>•</span>
            <span className="text-[#111412] font-semibold">5 DAYS REMAINING</span>
            <span>•</span>
            <span>84% COMPLETE</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-32 h-1.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded-full overflow-hidden hidden sm:block">
            <div className="h-full bg-[#173F35] rounded-full" style={{ width: '84%' }}></div>
          </div>
          <div className="text-right">
            <span className="text-[#626861] text-[11px]">Safe Daily Spending: </span>
            <strong className="font-mono text-[#173F35] font-bold">{formatCurrency(profile?.safeDailySpending || 850, currency)}</strong>
          </div>
        </div>
      </div>

      {/* FINANCIAL POSITION STATEMENT (Section 11 spec) */}
      <div className="p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-4">
        <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-3">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#111412]">
              Financial Position Statement
            </h2>
            <p className="text-xs text-[#626861]">Assets and liabilities overview for solvency assessment</p>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-[#626861] uppercase tracking-wider block font-semibold">Consolidated Net Worth</span>
            <span className="text-xl font-bold font-mono text-[#173F35]">
              {formatCurrency(netWorth, currency)}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1">
          {/* Assets Column */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2E7653] block border-b border-[#F0F1ED] pb-1">
              Assets
            </span>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between py-1 border-b border-dashed border-[#F0F1ED]">
                <span className="text-[#626861]">Cash & Liquid Reserves</span>
                <span className="font-mono font-medium text-[#111412]">{formatCurrency(totalBalance, currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-[#F0F1ED]">
                <span className="text-[#626861]">Dedicated Emergency Cushion</span>
                <span className="font-mono font-medium text-[#111412]">{formatCurrency(120000, currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-[#F0F1ED]">
                <span className="text-[#626861]">Funded Investment & Goals</span>
                <span className="font-mono font-medium text-[#111412]">{formatCurrency(180000, currency)}</span>
              </div>
            </div>
            <div className="pt-2 flex justify-between font-bold text-xs">
              <span className="uppercase text-[#111412]">Total Assets</span>
              <span className="font-mono text-[#173F35]">{formatCurrency(totalAssets, currency)}</span>
            </div>
          </div>

          {/* Liabilities Column */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#B94A48] block border-b border-[#F0F1ED] pb-1">
              Liabilities
            </span>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between py-1 border-b border-dashed border-[#F0F1ED]">
                <span className="text-[#626861]">Term Loan Principal</span>
                <span className="font-mono font-medium text-[#111412]">{formatCurrency(totalDebt, currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-[#F0F1ED]">
                <span className="text-[#626861]">Short-term Revolving Credit</span>
                <span className="font-mono font-medium text-[#111412]">{formatCurrency(15000, currency)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-dashed border-[#F0F1ED]">
                <span className="text-[#626861]">Pending Commitments</span>
                <span className="font-mono font-medium text-[#111412]">{formatCurrency(0, currency)}</span>
              </div>
            </div>
            <div className="pt-2 flex justify-between font-bold text-xs">
              <span className="uppercase text-[#111412]">Total Liabilities</span>
              <span className="font-mono text-[#B94A48]">{formatCurrency(totalDebt + 15000, currency)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* MONTHLY CASH FLOW & SPENDING ANALYSIS (Sections 12 & 14 spec) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Cash Flow Chart (7 cols) */}
        <div className="lg:col-span-7 p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-4">
          <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-3">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-[#111412]">
                Monthly Cash Flow
              </h3>
              <p className="text-xs text-[#626861]">Income vs Expenses vs Net Savings Trajectory</p>
            </div>

            {/* Timeframe controls */}
            <div className="flex p-0.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded">
              {(['1M', '3M', '6M', '1Y'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setCashFlowRange(r)}
                  className={`px-2 py-0.5 text-[11px] font-semibold rounded transition-colors ${
                    cashFlowRange === r
                      ? 'bg-white text-[#173F35] shadow-xs'
                      : 'text-[#626861] hover:text-[#111412]'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Restrained 3-color SVG Line Chart */}
          <div className="h-48 w-full pt-2">
            <svg viewBox="0 0 450 140" className="w-full h-full overflow-visible">
              <line x1="30" y1="120" x2="440" y2="120" stroke="#DCDDD8" strokeWidth="1" />
              <line x1="30" y1="70" x2="440" y2="70" stroke="#EAEBE6" strokeDasharray="3 3" />
              <line x1="30" y1="20" x2="440" y2="20" stroke="#EAEBE6" strokeDasharray="3 3" />

              {/* Income Line (Deep Forest #173F35) */}
              <polyline
                fill="none"
                stroke="#173F35"
                strokeWidth="2.5"
                points="40,40 120,38 200,35 280,32 360,30 430,25"
              />

              {/* Expense Line (Muted Warm Clay #B78327) */}
              <polyline
                fill="none"
                stroke="#B78327"
                strokeWidth="2"
                strokeDasharray="4 2"
                points="40,82 120,80 200,78 280,79 360,76 430,75"
              />

              {/* Savings Line (Muted Spruce #2E7653) */}
              <polyline
                fill="none"
                stroke="#2E7653"
                strokeWidth="2"
                points="40,105 120,100 200,95 280,92 360,88 430,82"
              />

              {/* Labels */}
              <text x="40" y="135" className="text-[10px] fill-[#626861] font-mono">May</text>
              <text x="120" y="135" className="text-[10px] fill-[#626861] font-mono">Jun</text>
              <text x="200" y="135" className="text-[10px] fill-[#626861] font-mono">Jul</text>
              <text x="280" y="135" className="text-[10px] fill-[#626861] font-mono">Aug</text>
              <text x="360" y="135" className="text-[10px] fill-[#626861] font-mono">Sep</text>
              <text x="430" y="135" className="text-[10px] fill-[#111412] font-mono font-bold">Oct</text>
            </svg>
          </div>

          <div className="flex items-center justify-between text-xs pt-2 border-t border-[#F0F1ED]">
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5 text-[#111412] font-medium">
                <span className="w-2.5 h-1 bg-[#173F35] rounded-full"></span> Income
              </span>
              <span className="flex items-center gap-1.5 text-[#626861] font-medium">
                <span className="w-2.5 h-1 bg-[#B78327] rounded-full"></span> Expenses
              </span>
              <span className="flex items-center gap-1.5 text-[#2E7653] font-medium">
                <span className="w-2.5 h-1 bg-[#2E7653] rounded-full"></span> Surplus
              </span>
            </div>

            <button
              onClick={() => setActiveTab('transactions')}
              className="text-[11px] text-[#173F35] font-semibold hover:underline flex items-center gap-1"
            >
              <span>Examine Ledgers</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Spending Analysis Table & Horizontal Bars (5 cols) */}
        <div className="lg:col-span-5 p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-3.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-[#111412]">
                Spending Analysis
              </h3>
              <span className="text-[11px] font-mono text-[#626861]">Oct 2026</span>
            </div>

            <div className="space-y-3 pt-2">
              {spendingCategories.map((item, i) => (
                <div key={i} className="space-y-1 text-xs">
                  <div className="flex justify-between items-baseline">
                    <span className="text-[#111412] font-medium">{item.name}</span>
                    <span className="font-mono text-[#626861]">
                      {formatCurrency(item.amount, currency)} <strong className="text-[#111412]">({item.pct}%)</strong>
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-[#F6F6F2] rounded overflow-hidden">
                    <div className="h-full bg-[#173F35] rounded" style={{ width: `${item.pct}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-[#F0F1ED] text-[11px] text-[#626861] flex justify-between items-center">
            <span>Essential Living Ratio: <strong>76%</strong></span>
            <span className="text-[#2E7653] font-semibold">Discretionary: 24%</span>
          </div>
        </div>

      </div>

      {/* CURRENT VS LAST MONTH COMPARISON TABLE (Section 15 spec) */}
      <div className="p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-3">
        <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-3">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#111412]">
              Period Comparison Analysis
            </h3>
            <p className="text-xs text-[#626861]">Performance delta against the preceding monthly closing</p>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded bg-[#F6F6F2] border border-[#DCDDD8] font-mono text-[#626861]">
            Standard Variance Analysis
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="text-[#626861] font-semibold border-b border-[#DCDDD8]">
              <tr>
                <th className="py-2.5 px-3">Metric</th>
                <th className="py-2.5 px-3">This Month (Oct)</th>
                <th className="py-2.5 px-3">Last Month (Sep)</th>
                <th className="py-2.5 px-3 text-right">Variance Change</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F0F1ED] font-mono">
              <tr>
                <td className="py-2.5 px-3 font-sans font-medium text-[#111412]">Gross Income</td>
                <td className="py-2.5 px-3 font-semibold text-[#111412]">{formatCurrency(80000, currency)}</td>
                <td className="py-2.5 px-3 text-[#626861]">{formatCurrency(75000, currency)}</td>
                <td className="py-2.5 px-3 text-right font-semibold text-[#2E7653]">+6.7%</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-sans font-medium text-[#111412]">Total Expenses</td>
                <td className="py-2.5 px-3 font-semibold text-[#111412]">{formatCurrency(48000, currency)}</td>
                <td className="py-2.5 px-3 text-[#626861]">{formatCurrency(51000, currency)}</td>
                <td className="py-2.5 px-3 text-right font-semibold text-[#2E7653]">-5.9%</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-sans font-medium text-[#111412]">Net Savings Surplus</td>
                <td className="py-2.5 px-3 font-semibold text-[#173F35]">+{formatCurrency(20000, currency)}</td>
                <td className="py-2.5 px-3 text-[#626861]">{formatCurrency(14000, currency)}</td>
                <td className="py-2.5 px-3 text-right font-semibold text-[#2E7653]">+42.8%</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-sans font-medium text-[#111412]">Savings Rate</td>
                <td className="py-2.5 px-3 font-bold text-[#173F35]">25.0%</td>
                <td className="py-2.5 px-3 text-[#626861]">18.7%</td>
                <td className="py-2.5 px-3 text-right font-bold text-[#2E7653]">+6.3%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* REFINED AI FINANCIAL INSIGHT BANNER (Section 19 spec) */}
      <div className="p-4 rounded-lg bg-[#F6F6F2] border border-[#DCDDD8] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold text-[#173F35] tracking-wider">
              Financial Intelligence Insight
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#173F35]"></span>
          </div>
          <p className="text-[#111412] leading-relaxed max-w-2xl font-normal">
            Your savings rate improved from <strong>18.7% to 25.0%</strong> this month. Sustaining this rate will allow your 6-month emergency reserve to reach full capitalization <strong>2 months earlier</strong> than original schedule.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('ai')}
          className="text-xs font-semibold text-[#173F35] hover:text-[#111412] underline decoration-1 underline-offset-4 shrink-0 flex items-center gap-1 self-start sm:self-auto"
        >
          <span>Consult AI Copilot</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatCurrency, calculateGoalTimeline } from '../../calculations/financeEngine';
import {
  Target,
  Plus,
  Trash2,
  Calendar,
  CheckCircle2,
  TrendingUp,
  X,
  Coins,
} from 'lucide-react';
import { FinancialGoal } from '../../types/finance';

export const GoalsView: React.FC = () => {
  const { data, currency, addGoal, updateGoal, deleteGoal } = useFinance();
  const [showAddModal, setShowAddModal] = useState(false);
  const [depositGoalId, setDepositGoalId] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState('');

  // Form states for new goal
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [currentAmount, setCurrentAmount] = useState('');
  const [targetDate, setTargetDate] = useState('2027-06-30');
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('high');
  const [category, setCategory] = useState('Capital Reserve');
  const [monthlyAllocated, setMonthlyAllocated] = useState('');

  const handleCreateGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !targetAmount) return;

    const target = Number(targetAmount);
    const current = Number(currentAmount) || 0;
    const timeline = calculateGoalTimeline(target, current, 1);
    const suggestedMonthly = timeline.requiredMonthlyForDate ? timeline.requiredMonthlyForDate(targetDate) : 0;

    await addGoal({
      name,
      targetAmount: target,
      currentAmount: current,
      targetDate,
      priority,
      category,
      monthlyAllocated: monthlyAllocated ? Number(monthlyAllocated) : suggestedMonthly,
    });

    setName('');
    setTargetAmount('');
    setCurrentAmount('');
    setMonthlyAllocated('');
    setShowAddModal(false);
  };

  const handleDeposit = async (goal: FinancialGoal) => {
    const deposit = Number(depositAmount);
    if (!deposit || deposit <= 0) return;
    await updateGoal(goal.id, {
      currentAmount: goal.currentAmount + deposit,
    });
    setDepositGoalId(null);
    setDepositAmount('');
  };

  const handleAddToPlan = async (goal: FinancialGoal, requiredMonthly: number) => {
    await updateGoal(goal.id, {
      monthlyAllocated: requiredMonthly,
    });
  };

  const totalTarget = data.goals.reduce((acc, g) => acc + g.targetAmount, 0);
  const totalFunded = data.goals.reduce((acc, g) => acc + g.currentAmount, 0);
  const overallProgress = totalTarget > 0 ? Math.round((totalFunded / totalTarget) * 100) : 0;

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6 pb-20 select-none">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 border-b border-[#DCDDD8] pb-4">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#626861] font-bold block mb-1">
            Capital Allocation
          </span>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#111412] tracking-tight">
            Financial Goals & Milestones
          </h1>
          <p className="text-xs text-[#626861] mt-0.5">
            Structured milestone targets, required monthly capitalization, and completion runway.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-3.5 py-1.5 rounded-md bg-[#173F35] text-white text-xs font-semibold hover:bg-[#1f5446] transition-colors self-start sm:self-auto flex items-center gap-1.5 shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Target Goal</span>
        </button>
      </div>

      {/* Aggregate Capitalization Status */}
      <div className="p-4 rounded-lg bg-white border border-[#DCDDD8] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#626861] tracking-wider block">Total Capital Target</span>
            <div className="text-lg font-bold font-mono text-[#111412] mt-0.5">
              {formatCurrency(totalTarget, currency)}
            </div>
          </div>
          <div className="h-8 w-px bg-[#DCDDD8] hidden sm:block"></div>
          <div>
            <span className="text-[10px] uppercase font-bold text-[#626861] tracking-wider block">Funded Balance</span>
            <div className="text-lg font-bold font-mono text-[#173F35] mt-0.5">
              {formatCurrency(totalFunded, currency)}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[10px] text-[#626861] uppercase tracking-wider block font-semibold">Portfolio Capitalization</span>
            <span className="text-sm font-bold font-mono text-[#111412]">{overallProgress}% Complete</span>
          </div>
          <div className="w-28 h-2 bg-[#F6F6F2] border border-[#DCDDD8] rounded overflow-hidden">
            <div className="h-full bg-[#173F35] rounded" style={{ width: `${overallProgress}%` }}></div>
          </div>
        </div>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.goals.map((goal) => {
          const pct = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
          const remaining = Math.max(0, goal.targetAmount - goal.currentAmount);
          const timeline = calculateGoalTimeline(goal.targetAmount, goal.currentAmount, goal.monthlyAllocated || 1000);
          const requiredMonthly = timeline.requiredMonthlyForDate ? timeline.requiredMonthlyForDate(goal.targetDate) : 0;
          const isDepositOpen = depositGoalId === goal.id;

          return (
            <div
              key={goal.id}
              className="p-5 rounded-lg bg-white border border-[#DCDDD8] space-y-4 flex flex-col justify-between"
            >
              <div>
                {/* Header & Badges */}
                <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-2">
                  <span className="text-[10px] font-bold text-[#626861] uppercase tracking-wider">
                    {goal.category}
                  </span>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-semibold uppercase ${
                        goal.priority === 'high'
                          ? 'bg-amber-50 text-[#B78327] border border-amber-200'
                          : 'bg-[#F6F6F2] text-[#626861] border border-[#DCDDD8]'
                      }`}
                    >
                      {goal.priority} Priority
                    </span>
                    <button
                      onClick={() => deleteGoal(goal.id)}
                      className="text-[#626861] hover:text-[#B94A48] transition-colors p-1"
                      title="Retire Goal"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Title & Balances */}
                <div className="mt-3">
                  <h3 className="text-sm font-bold text-[#111412]">{goal.name}</h3>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-xl font-bold font-mono text-[#173F35]">
                      {formatCurrency(goal.currentAmount, currency)}
                    </span>
                    <span className="text-xs text-[#626861] font-mono">
                      / {formatCurrency(goal.targetAmount, currency)}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-[11px] text-[#626861]">
                    <span>Capitalization</span>
                    <span className="font-mono font-bold text-[#111412]">{pct}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded overflow-hidden">
                    <div
                      className="h-full bg-[#173F35] rounded transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    ></div>
                  </div>
                </div>

                {/* Structured Metrics */}
                <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-[#F0F1ED] text-xs">
                  <div>
                    <span className="text-[10px] text-[#626861] block">Remaining</span>
                    <span className="font-mono font-bold text-[#111412]">
                      {formatCurrency(remaining, currency)}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-[#626861] block">Target Date</span>
                    <span className="font-mono text-[#111412] flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#626861]" />
                      {goal.targetDate}
                    </span>
                  </div>
                </div>

                {/* Deposit Form Expansion */}
                {isDepositOpen && (
                  <div className="mt-3 p-3 rounded bg-[#F6F6F2] border border-[#DCDDD8] space-y-2">
                    <span className="text-[10px] uppercase font-bold text-[#111412] block">
                      Allocate Capital to Goal
                    </span>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        placeholder={`Amount in ${currency}`}
                        className="flex-1 px-2.5 py-1.5 text-xs bg-white border border-[#DCDDD8] rounded text-[#111412] font-mono focus:outline-none focus:border-[#173F35]"
                      />
                      <button
                        onClick={() => handleDeposit(goal)}
                        className="px-3 py-1.5 bg-[#173F35] text-white text-xs font-semibold rounded hover:bg-[#1f5446]"
                      >
                        Confirm
                      </button>
                      <button
                        onClick={() => setDepositGoalId(null)}
                        className="px-2.5 py-1.5 bg-white border border-[#DCDDD8] text-[#626861] text-xs rounded"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-[#F0F1ED] flex items-center justify-between gap-2">
                <button
                  onClick={() => setDepositGoalId(isDepositOpen ? null : goal.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded border border-[#DCDDD8] bg-white text-[#111412] text-xs font-semibold hover:bg-[#F6F6F2] transition-colors"
                >
                  <Coins className="w-3.5 h-3.5 text-[#173F35]" />
                  <span>Allocate Capital</span>
                </button>

                <button
                  onClick={() => handleAddToPlan(goal, requiredMonthly)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#F6F6F2] border border-[#DCDDD8] text-[#173F35] text-xs font-semibold hover:bg-white transition-colors"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>
                    {goal.monthlyAllocated && goal.monthlyAllocated > 0
                      ? 'In Monthly Plan'
                      : 'Assign to Monthly Plan'}
                  </span>
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Add Goal Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-3 select-none">
          <div className="w-full max-w-md bg-white rounded-lg shadow-xl border border-[#DCDDD8] overflow-hidden flex flex-col">
            <div className="p-4 border-b border-[#DCDDD8] flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-[#626861] font-bold block">
                  Capital Planning
                </span>
                <h3 className="text-base font-bold text-[#111412]">Establish New Goal</h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded text-[#626861] hover:text-[#111412]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateGoal} className="p-4 space-y-3 text-xs">
              <div>
                <label className="text-[#626861] font-medium block mb-1">Goal Designation</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. 6-Month Emergency Cushion"
                  className="w-full px-2.5 py-1.5 border border-[#DCDDD8] rounded text-[#111412] focus:outline-none focus:border-[#173F35]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#626861] font-medium block mb-1">Target Amount ({currency})</label>
                  <input
                    type="number"
                    required
                    value={targetAmount}
                    onChange={(e) => setTargetAmount(e.target.value)}
                    placeholder="250000"
                    className="w-full px-2.5 py-1.5 border border-[#DCDDD8] rounded text-[#111412] font-mono focus:outline-none focus:border-[#173F35]"
                  />
                </div>
                <div>
                  <label className="text-[#626861] font-medium block mb-1">Current Balance ({currency})</label>
                  <input
                    type="number"
                    value={currentAmount}
                    onChange={(e) => setCurrentAmount(e.target.value)}
                    placeholder="0"
                    className="w-full px-2.5 py-1.5 border border-[#DCDDD8] rounded text-[#111412] font-mono focus:outline-none focus:border-[#173F35]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#626861] font-medium block mb-1">Target Maturity Date</label>
                  <input
                    type="date"
                    required
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-[#DCDDD8] rounded text-[#111412] font-mono focus:outline-none focus:border-[#173F35]"
                  />
                </div>
                <div>
                  <label className="text-[#626861] font-medium block mb-1">Priority Class</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 border border-[#DCDDD8] rounded text-[#111412] focus:outline-none focus:border-[#173F35]"
                  >
                    <option value="high">High Priority</option>
                    <option value="medium">Medium Priority</option>
                    <option value="low">Discretionary</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-[#DCDDD8] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 border border-[#DCDDD8] rounded text-[#626861] hover:text-[#111412]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#173F35] text-white font-semibold rounded hover:bg-[#1f5446]"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { X, Sparkles, ShieldCheck, Check, ArrowRight } from 'lucide-react';
import { CurrencyCode } from '../../types/finance';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
  onRegisterSuccess?: (defaultSheetId?: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  onRegisterSuccess,
}) => {
  const { login, register, demoLogin } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [currency, setCurrency] = useState<CurrencyCode>('NPR');
  const [ageRange, setAgeRange] = useState('25-34');
  const [country, setCountry] = useState('Nepal');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleDemo = async () => {
    setLoading(true);
    setError('');
    const ok = await demoLogin();
    setLoading(false);
    if (ok) {
      onClose();
    } else {
      setError('Failed to connect to demo account.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (mode === 'login') {
        const ok = await login(email, password);
        if (ok) {
          onClose();
        } else {
          setError('Invalid email or password.');
        }
      } else {
        const sheetId = await register({
          name,
          email,
          password,
          currency,
          country,
          ageRange,
        });
        if (sheetId && onRegisterSuccess) {
          onRegisterSuccess(sheetId);
        }
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Authentication error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-[#E5E8E3] overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-4 bg-[#173F35] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-xl bg-[#C9F36B] text-[#173F35] flex items-center justify-center font-bold text-xs">
              FP
            </span>
            <span className="font-bold text-sm tracking-tight">FinPulse AI</span>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1-Click Demo Login Banner */}
        <div className="p-4 bg-emerald-50/70 border-b border-emerald-100 flex items-center justify-between gap-2">
          <div className="min-w-0">
            <span className="text-xs font-bold text-emerald-900 block truncate">
              Instant Demo Account Available
            </span>
            <span className="text-[11px] text-emerald-700 block truncate">
              Maya Sharma • NPR 80,000/mo • Pre-seeded live numbers
            </span>
          </div>

          <button
            onClick={handleDemo}
            disabled={loading}
            className="px-3 py-1.5 rounded-xl bg-[#173F35] text-[#C9F36B] text-xs font-bold hover:bg-[#1f5446] transition-colors shrink-0 shadow-xs flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Explore Demo</span>
          </button>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-1 mx-5 mt-4 bg-zinc-100 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError('');
            }}
            className={`py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              mode === 'login' ? 'bg-white text-zinc-900 shadow-xs' : 'text-zinc-600'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setError('');
            }}
            className={`py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              mode === 'register' ? 'bg-white text-zinc-900 shadow-xs' : 'text-zinc-600'
            }`}
          >
            Create Account
          </button>
        </div>

        {error && (
          <div className="mx-5 mt-3 p-2.5 rounded-xl bg-red-50 text-red-700 text-xs font-medium border border-red-200">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-3.5">
          {mode === 'register' && (
            <div>
              <label className="text-xs font-semibold text-zinc-700 block mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Madhav Mahara"
                className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
              />
            </div>
          )}

          <div>
            <label className="text-xs font-semibold text-zinc-700 block mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-zinc-700 block mb-1">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 focus:outline-hidden focus:ring-2 focus:ring-[#173F35]"
            />
          </div>

          {mode === 'register' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-zinc-700 block mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 bg-white"
                >
                  <option value="NPR">NPR (Nepalese Rupee)</option>
                  <option value="USD">USD (US Dollar)</option>
                  <option value="INR">INR (Indian Rupee)</option>
                  <option value="GBP">GBP (British Pound)</option>
                  <option value="EUR">EUR (Euro)</option>
                  <option value="AUD">AUD (Australian Dollar)</option>
                  <option value="CAD">CAD (Canadian Dollar)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-zinc-700 block mb-1">Age Range</label>
                <select
                  value={ageRange}
                  onChange={(e) => setAgeRange(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-zinc-200 bg-white"
                >
                  <option value="18-24">18 - 24</option>
                  <option value="25-34">25 - 34</option>
                  <option value="35-44">35 - 44</option>
                  <option value="45-54">45 - 54</option>
                  <option value="55+">55+</option>
                </select>
              </div>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl bg-[#173F35] text-white text-xs font-bold hover:bg-[#1f5446] transition-colors shadow-sm flex items-center justify-center gap-1.5"
            >
              <span>{loading ? 'Processing...' : mode === 'login' ? 'Sign In' : 'Create My Account'}</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#C9F36B]" />
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};

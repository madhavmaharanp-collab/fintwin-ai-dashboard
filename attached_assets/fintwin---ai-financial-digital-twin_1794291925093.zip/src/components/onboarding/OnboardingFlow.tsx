import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { useAuth } from '../../context/AuthContext';
import {
  TrendingUp,
  Wallet,
  Receipt,
  CreditCard,
  Target,
  ArrowRight,
  ArrowLeft,
  Check,
  Plus,
  Trash2,
  Sparkles,
} from 'lucide-react';
import { formatCurrency } from '../../calculations/financeEngine';

interface OnboardingFlowProps {
  onComplete: () => void;
}

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete }) => {
  const { user } = useAuth();
  const { saveOnboarding, currency } = useFinance();
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);

  // Step 1: Incomes
  const [incomes, setIncomes] = useState<{ title: string; amount: number; frequency: any; category: any }[]>([
    { title: 'Primary Salary', amount: 80000, frequency: 'monthly', category: 'salary' },
    { title: 'Freelance & Side Gig', amount: 10000, frequency: 'monthly', category: 'freelance' },
  ]);

  // Step 2: Savings
  const [savings, setSavings] = useState<{ title: string; amount: number; type: any }[]>([
    { title: 'Emergency Liquid Reserve', amount: 60000, type: 'emergency_fund' },
    { title: 'Bank Checking & Savings', amount: 25000, type: 'bank' },
  ]);

  // Step 3: Expenses
  const [expenses, setExpenses] = useState<{ title: string; amount: number; category: any; isFixed: boolean }[]>([
    { title: 'Apartment Rent', amount: 18000, category: 'housing', isFixed: true },
    { title: 'Groceries & Provisions', amount: 12000, category: 'food', isFixed: false },
    { title: 'Commute & Fuel', amount: 5000, category: 'transportation', isFixed: true },
    { title: 'Utilities & Internet', amount: 4000, category: 'utilities', isFixed: true },
    { title: 'Dining Out & Entertainment', amount: 7000, category: 'entertainment', isFixed: false },
  ]);

  // Step 4: Debt
  const [debts, setDebts] = useState<{ name: string; remainingBalance: number; monthlyPayment: number; loanType: any; interestRate: number }[]>([
    { name: 'Education Loan', remainingBalance: 120000, monthlyPayment: 5000, loanType: 'education', interestRate: 8.5 },
  ]);

  // Step 5: Goals
  const [goals, setGoals] = useState<{ name: string; targetAmount: number; currentAmount: number; targetDate: string; priority: any; category: string }[]>([
    { name: '6-Month Emergency Cushion', targetAmount: 150000, currentAmount: 60000, targetDate: '2027-08-31', priority: 'high', category: 'Safety' },
    { name: 'MacBook Pro Tech Upgrade', targetAmount: 150000, currentAmount: 90000, targetDate: '2027-02-28', priority: 'medium', category: 'Tech' },
  ]);

  const handleFinish = async () => {
    setSaving(true);
    await saveOnboarding({
      incomes,
      expenses,
      debts,
      savings,
      goals,
    });
    setSaving(false);
    onComplete();
  };

  const stepsList = [
    { num: 1, title: 'Income', icon: TrendingUp },
    { num: 2, title: 'Savings', icon: Wallet },
    { num: 3, title: 'Expenses', icon: Receipt },
    { num: 4, title: 'Debt', icon: CreditCard },
    { num: 5, title: 'Goals', icon: Target },
  ];

  return (
    <div className="min-h-screen bg-[#F7F8F5] flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-xl border border-[#E5E8E3] overflow-hidden flex flex-col">
        
        {/* Header Progress */}
        <div className="p-5 bg-[#173F35] text-white">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-xl bg-[#C9F36B] text-[#173F35] flex items-center justify-center font-bold text-xs">
                FP
              </span>
              <span className="font-bold text-sm tracking-tight">FinPulse Setup</span>
            </div>
            <span className="text-xs text-emerald-100 font-mono">Step {step} of 5</span>
          </div>

          {/* Stepper Dots */}
          <div className="grid grid-cols-5 gap-2">
            {stepsList.map((s) => (
              <div
                key={s.num}
                className={`h-1.5 rounded-full transition-all ${
                  step >= s.num ? 'bg-[#C9F36B]' : 'bg-emerald-950/60'
                }`}
              ></div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <div className="p-5 sm:p-8 flex-1 space-y-5">
          
          {/* STEP 1: INCOME */}
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-zinc-900">Tell us about your income</h2>
                <p className="text-xs text-zinc-500 mt-1">
                  Add salary, freelance, or other earnings. Currency: <strong>{currency}</strong>
                </p>
              </div>

              <div className="space-y-2.5">
                {incomes.map((inc, i) => (
                  <div key={i} className="flex gap-2 items-center p-2.5 bg-zinc-50 rounded-xl border border-zinc-200">
                    <input
                      type="text"
                      value={inc.title}
                      onChange={(e) => {
                        const copy = [...incomes];
                        copy[i].title = e.target.value;
                        setIncomes(copy);
                      }}
                      placeholder="Income source"
                      className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-zinc-200 bg-white"
                    />
                    <div className="relative w-32 sm:w-40">
                      <span className="absolute left-2.5 top-1.5 text-[10px] text-zinc-400 font-mono">{currency}</span>
                      <input
                        type="number"
                        value={inc.amount}
                        onChange={(e) => {
                          const copy = [...incomes];
                          copy[i].amount = Number(e.target.value);
                          setIncomes(copy);
                        }}
                        className="w-full pl-10 pr-2 py-1.5 text-xs font-mono font-bold rounded-lg border border-zinc-200 bg-white"
                      />
                    </div>
                    {incomes.length > 1 && (
                      <button
                        onClick={() => setIncomes(incomes.filter((_, idx) => idx !== i))}
                        className="text-zinc-400 hover:text-red-500 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={() =>
                  setIncomes([...incomes, { title: 'Secondary Income', amount: 5000, frequency: 'monthly', category: 'other' }])
                }
                className="flex items-center gap-1.5 text-xs font-semibold text-[#173F35] hover:underline"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add another income source</span>
              </button>
            </div>
          )}

          {/* STEP 2: SAVINGS */}
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-zinc-900">Your current savings & reserves</h2>
                <p className="text-xs text-zinc-500 mt-1">
                  Cash reserves protect you from debt when life happens.
                </p>
              </div>

              <div className="space-y-2.5">
                {savings.map((sav, i) => (
                  <div key={i} className="flex gap-2 items-center p-2.5 bg-zinc-50 rounded-xl border border-zinc-200">
                    <input
                      type="text"
                      value={sav.title}
                      onChange={(e) => {
                        const copy = [...savings];
                        copy[i].title = e.target.value;
                        setSavings(copy);
                      }}
                      className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-zinc-200 bg-white"
                    />
                    <div className="relative w-32 sm:w-40">
                      <span className="absolute left-2.5 top-1.5 text-[10px] text-zinc-400 font-mono">{currency}</span>
                      <input
                        type="number"
                        value={sav.amount}
                        onChange={(e) => {
                          const copy = [...savings];
                          copy[i].amount = Number(e.target.value);
                          setSavings(copy);
                        }}
                        className="w-full pl-10 pr-2 py-1.5 text-xs font-mono font-bold rounded-lg border border-zinc-200 bg-white"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 3: MONTHLY EXPENSES */}
          {step === 3 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-zinc-900">Your planned monthly expenses</h2>
                <p className="text-xs text-zinc-500 mt-1">
                  Approximate amounts for housing, groceries, transport, utilities.
                </p>
              </div>

              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {expenses.map((exp, i) => (
                  <div key={i} className="flex gap-2 items-center p-2 bg-zinc-50 rounded-xl border border-zinc-200">
                    <input
                      type="text"
                      value={exp.title}
                      onChange={(e) => {
                        const copy = [...expenses];
                        copy[i].title = e.target.value;
                        setExpenses(copy);
                      }}
                      className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-zinc-200 bg-white"
                    />
                    <div className="relative w-32 sm:w-36">
                      <span className="absolute left-2.5 top-1.5 text-[10px] text-zinc-400 font-mono">{currency}</span>
                      <input
                        type="number"
                        value={exp.amount}
                        onChange={(e) => {
                          const copy = [...expenses];
                          copy[i].amount = Number(e.target.value);
                          setExpenses(copy);
                        }}
                        className="w-full pl-10 pr-2 py-1.5 text-xs font-mono font-bold rounded-lg border border-zinc-200 bg-white"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 4: DEBT */}
          {step === 4 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-zinc-900">Active loans & debt obligations</h2>
                <p className="text-xs text-zinc-500 mt-1">
                  Monthly debt payments lower your free cashflow and financial health score.
                </p>
              </div>

              <div className="space-y-2.5">
                {debts.map((d, i) => (
                  <div key={i} className="p-3 bg-zinc-50 rounded-xl border border-zinc-200 space-y-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={d.name}
                        onChange={(e) => {
                          const copy = [...debts];
                          copy[i].name = e.target.value;
                          setDebts(copy);
                        }}
                        placeholder="Loan Name"
                        className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-zinc-200 bg-white"
                      />
                      <button
                        onClick={() => setDebts(debts.filter((_, idx) => idx !== i))}
                        className="text-zinc-400 hover:text-red-500 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Remaining Balance</label>
                        <input
                          type="number"
                          value={d.remainingBalance}
                          onChange={(e) => {
                            const copy = [...debts];
                            copy[i].remainingBalance = Number(e.target.value);
                            setDebts(copy);
                          }}
                          className="w-full px-2.5 py-1 text-xs font-mono rounded-lg border border-zinc-200 bg-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Monthly EMI</label>
                        <input
                          type="number"
                          value={d.monthlyPayment}
                          onChange={(e) => {
                            const copy = [...debts];
                            copy[i].monthlyPayment = Number(e.target.value);
                            setDebts(copy);
                          }}
                          className="w-full px-2.5 py-1 text-xs font-mono rounded-lg border border-zinc-200 bg-white"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={() =>
                  setDebts([...debts, { name: 'Personal Loan', remainingBalance: 50000, monthlyPayment: 3000, loanType: 'personal', interestRate: 10 }])
                }
                className="flex items-center gap-1.5 text-xs font-semibold text-[#173F35] hover:underline"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add another loan</span>
              </button>
            </div>
          )}

          {/* STEP 5: GOALS */}
          {step === 5 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-zinc-900">Define your financial goals</h2>
                <p className="text-xs text-zinc-500 mt-1">
                  What are you saving towards? We'll calculate the exact monthly amount needed.
                </p>
              </div>

              <div className="space-y-2.5">
                {goals.map((g, i) => (
                  <div key={i} className="p-3 bg-zinc-50 rounded-xl border border-zinc-200 space-y-2">
                    <input
                      type="text"
                      value={g.name}
                      onChange={(e) => {
                        const copy = [...goals];
                        copy[i].name = e.target.value;
                        setGoals(copy);
                      }}
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-zinc-200 bg-white font-semibold"
                    />

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Target Amount ({currency})</label>
                        <input
                          type="number"
                          value={g.targetAmount}
                          onChange={(e) => {
                            const copy = [...goals];
                            copy[i].targetAmount = Number(e.target.value);
                            setGoals(copy);
                          }}
                          className="w-full px-2.5 py-1 text-xs font-mono rounded-lg border border-zinc-200 bg-white font-bold"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Target Date</label>
                        <input
                          type="date"
                          value={g.targetDate}
                          onChange={(e) => {
                            const copy = [...goals];
                            copy[i].targetDate = e.target.value;
                            setGoals(copy);
                          }}
                          className="w-full px-2.5 py-1 text-xs rounded-lg border border-zinc-200 bg-white"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer Navigation */}
        <div className="p-4 bg-zinc-50 border-t border-[#E5E8E3] flex items-center justify-between">
          {step > 1 ? (
            <button
              onClick={() => setStep(step - 1)}
              className="flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-semibold text-zinc-600 hover:bg-zinc-200 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          ) : (
            <div></div>
          )}

          {step < 5 ? (
            <button
              onClick={() => setStep(step + 1)}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#173F35] text-white text-xs font-bold hover:bg-[#1f5446] transition-colors shadow-sm"
            >
              <span>Next Step</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#C9F36B]" />
            </button>
          ) : (
            <button
              onClick={handleFinish}
              disabled={saving}
              className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-[#173F35] text-white text-xs font-bold hover:bg-[#1f5446] transition-colors shadow-md disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-[#C9F36B]" />
              <span>{saving ? 'Building Profile...' : 'Build My Financial Plan'}</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { formatCurrency } from '../../calculations/financeEngine';
import { FinancialHistoryGraphs } from '../history/FinancialHistoryGraphs';
import {
  Search,
  Plus,
  Trash2,
  PieChart,
  BarChart3,
  Receipt,
} from 'lucide-react';

interface TransactionsViewProps {
  openAddModal: () => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({ openAddModal }) => {
  const { data, currency, deleteTransaction, setBudget } = useFinance();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'history_graphs' | 'transactions' | 'budgets'>('history_graphs');
  const [editingBudgetCategory, setEditingBudgetCategory] = useState<string | null>(null);
  const [budgetLimitInput, setBudgetLimitInput] = useState('');

  // Calculate actual spending per category from transactions
  const categorySpending: Record<string, number> = {};
  for (const tx of data.transactions) {
    if (tx.type === 'expense') {
      categorySpending[tx.category] = (categorySpending[tx.category] || 0) + tx.amount;
    }
  }

  // Filtered transactions
  const filteredTransactions = data.transactions.filter((tx) => {
    const matchesSearch =
      tx.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || tx.type === filterType;
    const matchesCategory = filterCategory === 'all' || tx.category === filterCategory;
    return matchesSearch && matchesType && matchesCategory;
  });

  const uniqueCategories = Array.from(new Set(data.transactions.map((t) => t.category)));

  const handleSaveBudget = async (category: string) => {
    if (!budgetLimitInput) return;
    await setBudget(category, Number(budgetLimitInput));
    setEditingBudgetCategory(null);
    setBudgetLimitInput('');
  };

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6 pb-20 select-none">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 border-b border-[#DCDDD8] pb-4">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#626861] font-bold block mb-1">
            Cashflow Ledger
          </span>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#111412] tracking-tight">
            Financial History & Transactions
          </h1>
          <p className="text-xs text-[#626861] mt-0.5">
            Audit historical multi-month cashflow ledgers, transaction records, and category budget limits.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Segmented Tab */}
          <div className="flex p-0.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded text-xs font-mono">
            <button
              onClick={() => setViewMode('history_graphs')}
              className={`flex items-center gap-1.5 px-3 py-1 font-semibold rounded transition-colors ${
                viewMode === 'history_graphs'
                  ? 'bg-[#173F35] text-white shadow-xs'
                  : 'text-[#626861] hover:text-[#111412]'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>History Graphs</span>
            </button>
            <button
              onClick={() => setViewMode('transactions')}
              className={`flex items-center gap-1.5 px-3 py-1 font-semibold rounded transition-colors ${
                viewMode === 'transactions'
                  ? 'bg-[#173F35] text-white shadow-xs'
                  : 'text-[#626861] hover:text-[#111412]'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Ledger ({data.transactions.length})</span>
            </button>
            <button
              onClick={() => setViewMode('budgets')}
              className={`flex items-center gap-1.5 px-3 py-1 font-semibold rounded transition-colors ${
                viewMode === 'budgets'
                  ? 'bg-[#173F35] text-white shadow-xs'
                  : 'text-[#626861] hover:text-[#111412]'
              }`}
            >
              <PieChart className="w-3.5 h-3.5" />
              <span>Budgets</span>
            </button>
          </div>

          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#173F35] text-white text-xs font-semibold hover:bg-[#1f5446] transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Entry</span>
          </button>
        </div>
      </div>

      {viewMode === 'history_graphs' ? (
        <FinancialHistoryGraphs />
      ) : viewMode === 'transactions' ? (
        <>
          {/* Search & Filters */}
          <div className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#626861]" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search transactions, payees, reference notes..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-md border border-[#DCDDD8] bg-white text-[#111412] placeholder-[#626861] focus:outline-none focus:border-[#173F35]"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="px-3 py-2 text-xs rounded-md border border-[#DCDDD8] bg-white font-medium text-[#111412] focus:outline-none"
              >
                <option value="all">All Types</option>
                <option value="expense">Expenses Only</option>
                <option value="income">Incomes Only</option>
              </select>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-2 text-xs rounded-md border border-[#DCDDD8] bg-white font-medium text-[#111412] focus:outline-none"
              >
                <option value="all">All Categories</option>
                {uniqueCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Transactions List */}
          <div className="bg-white rounded-lg border border-[#DCDDD8] overflow-hidden shadow-xs">
            {filteredTransactions.length === 0 ? (
              <div className="p-8 text-center text-[#626861] space-y-1">
                <p className="text-sm font-medium text-[#111412]">No transactions found</p>
                <p className="text-xs">Adjust your search query or record a new transaction.</p>
              </div>
            ) : (
              <div className="divide-y divide-[#F0F1ED]">
                {filteredTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="p-3 sm:p-4 flex items-center justify-between hover:bg-[#F6F6F2]/70 transition-colors gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-7 h-7 rounded flex items-center justify-center text-xs font-mono font-bold shrink-0 ${
                          tx.type === 'income'
                            ? 'bg-emerald-50 text-[#2E7653] border border-emerald-200'
                            : 'bg-[#F6F6F2] text-[#626861] border border-[#DCDDD8]'
                        }`}
                      >
                        {tx.type === 'income' ? '+' : '-'}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-[#111412] truncate">{tx.description}</p>
                        <div className="flex items-center gap-2 text-[10px] text-[#626861] font-mono mt-0.5">
                          <span>{tx.date}</span>
                          <span>•</span>
                          <span className="uppercase">{tx.category}</span>
                          {tx.paymentMethod && (
                            <>
                              <span>•</span>
                              <span>{tx.paymentMethod}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span
                        className={`font-mono font-bold text-xs sm:text-sm ${
                          tx.type === 'income' ? 'text-[#2E7653]' : 'text-[#111412]'
                        }`}
                      >
                        {tx.type === 'income' ? '+' : '-'}
                        {formatCurrency(tx.amount, currency)}
                      </span>

                      <button
                        onClick={() => deleteTransaction(tx.id)}
                        className="text-[#626861] hover:text-[#B94A48] p-1 rounded transition-colors"
                        title="Delete Entry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      ) : (
        /* Monthly Budgets View */
        <div className="space-y-4">
          <div className="p-4 rounded-lg bg-white border border-[#DCDDD8] flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[#111412] uppercase tracking-wider">
                Monthly Category Budget Caps
              </h3>
              <p className="text-xs text-[#626861]">
                Enforce categorical spending discipline against projected limits
              </p>
            </div>
            <span className="text-[11px] font-mono text-[#626861]">
              October Active Cycle
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {data.budgets.map((b) => {
              const category = b.category;
              const limit = b.monthlyLimit || 0;
              const spent = categorySpending[category] || 0;
              const pct = limit > 0 ? Math.min(100, Math.round((spent / limit) * 100)) : 0;
              const isOver = limit > 0 && spent > limit;
              const isEditing = editingBudgetCategory === category;

              return (
                <div
                  key={category}
                  className="p-4 rounded-lg bg-white border border-[#DCDDD8] space-y-3"
                >
                  <div className="flex items-center justify-between border-b border-[#F0F1ED] pb-2">
                    <span className="text-xs font-bold text-[#111412] uppercase tracking-wider">
                      {category}
                    </span>
                    <button
                      onClick={() => {
                        setEditingBudgetCategory(isEditing ? null : category);
                        setBudgetLimitInput(limit.toString());
                      }}
                      className="text-[11px] text-[#173F35] hover:text-[#111412] font-semibold"
                    >
                      {isEditing ? 'Cancel' : 'Edit Limit'}
                    </button>
                  </div>

                  {isEditing ? (
                    <div className="flex gap-2 text-xs">
                      <input
                        type="number"
                        value={budgetLimitInput}
                        onChange={(e) => setBudgetLimitInput(e.target.value)}
                        placeholder={`Limit in ${currency}`}
                        className="flex-1 px-2.5 py-1.5 border border-[#DCDDD8] rounded font-mono text-[#111412] focus:outline-none focus:border-[#173F35]"
                      />
                      <button
                        onClick={() => handleSaveBudget(category)}
                        className="px-3 py-1.5 bg-[#173F35] text-white font-semibold rounded hover:bg-[#1f5446]"
                      >
                        Save
                      </button>
                    </div>
                  ) : (
                    <div>
                      <div className="flex justify-between items-baseline text-xs">
                        <span className="font-mono text-[#111412]">
                          Spent: <strong>{formatCurrency(spent, currency)}</strong>
                        </span>
                        <span className="font-mono text-[#626861]">
                          Limit: {formatCurrency(limit, currency)}
                        </span>
                      </div>

                      <div className="w-full h-1.5 bg-[#F6F6F2] border border-[#DCDDD8] rounded mt-2 overflow-hidden">
                        <div
                          className={`h-full rounded ${
                            isOver ? 'bg-[#B94A48]' : pct > 80 ? 'bg-[#B78327]' : 'bg-[#173F35]'
                          }`}
                          style={{ width: `${pct}%` }}
                        ></div>
                      </div>

                      <div className="flex justify-between items-center text-[10px] text-[#626861] mt-1.5 font-mono">
                        <span>{pct}% Consumed</span>
                        <span className={isOver ? 'text-[#B94A48] font-bold' : ''}>
                          {isOver
                            ? `Over by ${formatCurrency(spent - limit, currency)}`
                            : `${formatCurrency(Math.max(0, limit - spent), currency)} Remaining`}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

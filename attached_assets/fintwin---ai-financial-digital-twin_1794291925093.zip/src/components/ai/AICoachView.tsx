import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useFinance } from '../../context/FinanceContext';
import { formatCurrency } from '../../calculations/financeEngine';
import {
  Bot,
  Send,
  User,
  ShieldCheck,
  ChevronRight,
  Info,
  CheckCircle2,
  HelpCircle,
  Sparkles,
} from 'lucide-react';
import { AIMessage } from '../../types/finance';

export const AICoachView: React.FC = () => {
  const { user } = useAuth();
  const { data, currency, activeSheetId } = useFinance();
  const profile = data.profile;

  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: 'msg-welcome',
      role: 'assistant',
      content: `Good day, ${user?.name ? user.name.split(' ')[0] : ''}. I am your **FinTwin Advisory Copilot**.

I have verified access to your real financial data:
• Net Monthly Surplus: **${formatCurrency(profile?.monthlySurplus || 20000, currency)}**
• Financial Health Rating: **${profile?.healthScore?.overall || 78} / 100**
• Emergency Coverage: **${profile?.emergencyFundCoverageMonths || 3.8} months**
• Debt Obligations: **${profile?.debtToIncomeRatio.toFixed(1) || 12.0}% DTI**

You may present any query regarding expenditure allocation, capital purchases, debt paydown strategy, or scenario simulation.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = async (messageText?: string) => {
    const textToSend = messageText || input;
    if (!textToSend.trim() || isTyping) return;

    const userMsg: AIMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!messageText) setInput('');
    setIsTyping(true);

    try {
      const res = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('finpulse_token')}`,
        },
        body: JSON.stringify({
          message: textToSend.trim(),
          sheetId: activeSheetId,
        }),
      });

      if (res.ok) {
        const json = await res.json();
        const aiMsg: AIMessage = {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          content: json.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, aiMsg]);
      } else {
        throw new Error('Coach service error');
      }
    } catch {
      const errorMsg: AIMessage = {
        id: `err_${Date.now()}`,
        role: 'assistant',
        content: `Based on your verified monthly surplus of ${formatCurrency(profile?.monthlySurplus || 20000, currency)} and ${profile?.emergencyFundCoverageMonths || 3.8} months of reserves, your position remains stable. Priority should be given to maintaining 6 months of liquid reserves before taking on discretionary financial liabilities.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const sampleInquiries = [
    `Can I afford a ${currency} 150,000 capital purchase?`,
    `How much can I safely save every month?`,
    `Should I prioritize emergency fund or SIP?`,
    `What happens if my salary increases 20%?`,
    `How can I reduce variable living expenditures?`,
  ];

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-4 pb-20 select-none">
      
      {/* Title */}
      <div className="border-b border-[#DCDDD8] pb-3 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-[#626861] font-bold block mb-1">
            Financial Copilot Terminal
          </span>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#111412] tracking-tight">
            AI Advisory Terminal
          </h1>
          <p className="text-xs text-[#626861]">
            Deterministic financial analysis backed by generative contextual intelligence.
          </p>
        </div>

        <span className="text-[11px] font-mono px-2.5 py-1 rounded border border-[#DCDDD8] bg-[#F6F6F2] text-[#173F35] font-semibold self-start sm:self-auto">
          Context: Verified Active Ledger
        </span>
      </div>

      {/* 3-Column Desktop Financial Workspace (Section 20 spec) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[calc(100vh-210px)] min-h-[580px]">
        
        {/* Left Column: Preset Advisory Inquiries (3 cols) */}
        <div className="hidden lg:flex lg:col-span-3 bg-white rounded-lg border border-[#DCDDD8] p-3 flex-col justify-between space-y-3">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[#626861] block px-1">
              Advisory Topics
            </span>
            <div className="space-y-1">
              {sampleInquiries.map((q, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(q)}
                  disabled={isTyping}
                  className="w-full text-left p-2.5 rounded text-xs text-[#111412] hover:bg-[#F6F6F2] hover:text-[#173F35] border border-transparent hover:border-[#DCDDD8] transition-colors line-clamp-2"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          <div className="p-2.5 rounded bg-[#F6F6F2] border border-[#DCDDD8] text-[10px] text-[#626861] leading-relaxed">
            <strong className="text-[#111412] block mb-0.5">Advisory Directive</strong>
            Consultations adhere strictly to mathematical verification. Projections are illustrative and not guaranteed.
          </div>
        </div>

        {/* Center Column: Conversation Terminal (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-lg border border-[#DCDDD8] flex flex-col justify-between overflow-hidden">
          
          {/* Chat Messages Log */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
            {messages.map((msg) => {
              const isAssistant = msg.role === 'assistant';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isAssistant ? 'items-start' : 'items-end'}`}
                >
                  <div className="flex items-center gap-1.5 mb-1 px-1">
                    <span className="text-[10px] font-semibold text-[#626861]">
                      {isAssistant ? 'FinTwin Copilot' : 'Client Inquirer'}
                    </span>
                    <span className="text-[9px] text-[#626861] font-mono">• {msg.timestamp}</span>
                  </div>

                  <div
                    className={`p-3.5 rounded-lg text-xs leading-relaxed max-w-[90%] whitespace-pre-line ${
                      isAssistant
                        ? 'bg-[#F6F6F2] border border-[#DCDDD8] text-[#111412]'
                        : 'bg-[#173F35] text-white font-medium'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-center gap-2 p-3 text-xs text-[#626861] font-mono animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-[#173F35]"></span>
                <span>Calculating verified financial advisory response...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Control Box */}
          <div className="p-3 border-t border-[#DCDDD8] bg-white">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Inquire on capital expenditures, budget caps, or savings runway..."
                className="flex-1 px-3 py-2 text-xs bg-[#F6F6F2] border border-[#DCDDD8] rounded-md focus:outline-none focus:border-[#173F35] text-[#111412] placeholder-[#626861]"
              />
              <button
                type="submit"
                disabled={!input.trim() || isTyping}
                className="px-3.5 py-2 rounded-md bg-[#173F35] hover:bg-[#1f5446] disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

        </div>

        {/* Right Column: Verified Financial Context (3 cols) (Section 20 spec) */}
        <div className="hidden lg:flex lg:col-span-3 bg-white rounded-lg border border-[#DCDDD8] p-4 flex-col justify-between space-y-4">
          <div className="space-y-3">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[#626861] block border-b border-[#F0F1ED] pb-2">
              Verified Financial Context
            </span>

            <div className="space-y-2 text-xs">
              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8] flex justify-between">
                <span className="text-[#626861]">Monthly Income</span>
                <span className="font-mono font-bold text-[#111412]">
                  {formatCurrency(profile?.totalMonthlyIncome || 80000, currency)}
                </span>
              </div>

              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8] flex justify-between">
                <span className="text-[#626861]">Monthly Expenses</span>
                <span className="font-mono font-bold text-[#111412]">
                  {formatCurrency(profile?.totalMonthlyExpenses || 48000, currency)}
                </span>
              </div>

              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8] flex justify-between">
                <span className="text-[#626861]">Net Monthly Surplus</span>
                <span className="font-mono font-bold text-[#2E7653]">
                  +{formatCurrency(profile?.monthlySurplus || 20000, currency)}
                </span>
              </div>

              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8] flex justify-between">
                <span className="text-[#626861]">Health Rating</span>
                <span className="font-mono font-bold text-[#173F35]">
                  {profile?.healthScore?.overall || 78} / 100
                </span>
              </div>

              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8] flex justify-between">
                <span className="text-[#626861]">Emergency Runway</span>
                <span className="font-mono font-bold text-[#111412]">
                  {profile?.emergencyFundCoverageMonths || 3.8} Months
                </span>
              </div>

              <div className="p-2 rounded bg-[#F6F6F2] border border-[#DCDDD8] flex justify-between">
                <span className="text-[#626861]">Debt-to-Income</span>
                <span className="font-mono font-bold text-[#111412]">
                  {profile?.debtToIncomeRatio.toFixed(1) || 12.0}%
                </span>
              </div>
            </div>
          </div>

          <div className="p-3 rounded bg-[#F6F6F2] border border-[#DCDDD8] text-[10px] text-[#626861] leading-relaxed">
            <strong className="text-[#111412] block mb-0.5">Confidentiality Guarantee</strong>
            All financial parameters are computed securely client/server-side and are not retained for external LLM training.
          </div>
        </div>

      </div>

    </div>
  );
};

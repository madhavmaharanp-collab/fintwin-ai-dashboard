import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import {
  FinancialSheet,
  IncomeSource,
  Expense,
  Debt,
  SavingsAsset,
  FinancialGoal,
  Transaction,
  BudgetLimit,
  FinancialProfileCalculated,
  SheetType,
  CurrencyCode,
} from '../types/finance';
import { buildFinancialProfile } from '../calculations/financeEngine';

interface SheetData {
  sheet: FinancialSheet | null;
  incomes: IncomeSource[];
  expenses: Expense[];
  debts: Debt[];
  savings: SavingsAsset[];
  goals: FinancialGoal[];
  transactions: Transaction[];
  budgets: BudgetLimit[];
  profile: FinancialProfileCalculated | null;
}

interface FinanceContextType {
  sheets: FinancialSheet[];
  activeSheetId: string | null;
  setActiveSheetId: (id: string) => void;
  data: SheetData;
  loading: boolean;
  refreshData: () => Promise<void>;
  createSheet: (name: string, type: SheetType, description?: string, membersCount?: number) => Promise<string | null>;
  deleteSheet: (id: string) => Promise<boolean>;
  saveOnboarding: (payload: {
    incomes: Partial<IncomeSource>[];
    expenses: Partial<Expense>[];
    debts: Partial<Debt>[];
    savings: Partial<SavingsAsset>[];
    goals: Partial<FinancialGoal>[];
  }) => Promise<boolean>;
  addIncome: (income: Omit<IncomeSource, 'id' | 'sheetId'>) => Promise<boolean>;
  deleteIncome: (id: string) => Promise<boolean>;
  addExpense: (expense: Omit<Expense, 'id' | 'sheetId'>) => Promise<boolean>;
  deleteExpense: (id: string) => Promise<boolean>;
  addDebt: (debt: Omit<Debt, 'id' | 'sheetId'>) => Promise<boolean>;
  deleteDebt: (id: string) => Promise<boolean>;
  addGoal: (goal: Omit<FinancialGoal, 'id' | 'sheetId'>) => Promise<boolean>;
  updateGoal: (id: string, updates: Partial<FinancialGoal>) => Promise<boolean>;
  deleteGoal: (id: string) => Promise<boolean>;
  addTransaction: (tx: Omit<Transaction, 'id' | 'sheetId'>) => Promise<boolean>;
  deleteTransaction: (id: string) => Promise<boolean>;
  setBudget: (category: string, monthlyLimit: number) => Promise<boolean>;
  currency: CurrencyCode;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { token, user } = useAuth();
  const [sheets, setSheets] = useState<FinancialSheet[]>([]);
  const [activeSheetId, setActiveSheetId] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [data, setData] = useState<SheetData>({
    sheet: null,
    incomes: [],
    expenses: [],
    debts: [],
    savings: [],
    goals: [],
    transactions: [],
    budgets: [],
    profile: null,
  });

  const currency: CurrencyCode = data.sheet?.currency || user?.currency || 'NPR';

  // Fetch all sheets for the user
  const fetchSheets = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/sheets', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const json = await res.json();
        setSheets(json.sheets || []);
        if (json.sheets && json.sheets.length > 0) {
          if (!activeSheetId || !json.sheets.find((s: FinancialSheet) => s.id === activeSheetId)) {
            const defaultSheet = json.sheets.find((s: FinancialSheet) => s.isDefault) || json.sheets[0];
            setActiveSheetId(defaultSheet.id);
          }
        }
      }
    } catch (err) {
      console.error('Failed to fetch sheets:', err);
    }
  }, [token, activeSheetId]);

  // Fetch sheet details & records
  const fetchSheetData = useCallback(async (sheetId: string) => {
    if (!token || !sheetId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/sheets/${sheetId}/data`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const json = await res.json();
        // Compute calculated profile
        const calculatedProfile = buildFinancialProfile({
          incomes: json.incomes || [],
          expenses: json.expenses || [],
          debts: json.debts || [],
          savings: json.savings || [],
          goals: json.goals || [],
        });
        setData({
          sheet: json.sheet,
          incomes: json.incomes || [],
          expenses: json.expenses || [],
          debts: json.debts || [],
          savings: json.savings || [],
          goals: json.goals || [],
          transactions: json.transactions || [],
          budgets: json.budgets || [],
          profile: calculatedProfile,
        });
      }
    } catch (err) {
      console.error('Failed to fetch sheet data:', err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    if (token) {
      fetchSheets();
    } else {
      setSheets([]);
      setActiveSheetId(null);
      setData({
        sheet: null,
        incomes: [],
        expenses: [],
        debts: [],
        savings: [],
        goals: [],
        transactions: [],
        budgets: [],
        profile: null,
      });
      setLoading(false);
    }
  }, [token, fetchSheets]);

  useEffect(() => {
    if (activeSheetId) {
      fetchSheetData(activeSheetId);
    }
  }, [activeSheetId, fetchSheetData]);

  const refreshData = async () => {
    if (activeSheetId) {
      await fetchSheetData(activeSheetId);
    }
    await fetchSheets();
  };

  const createSheet = async (
    name: string,
    type: SheetType,
    description?: string,
    membersCount?: number
  ): Promise<string | null> => {
    if (!token) return null;
    try {
      const res = await fetch('/api/sheets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ name, type, description, membersCount, currency: user?.currency }),
      });
      if (res.ok) {
        const json = await res.json();
        await fetchSheets();
        setActiveSheetId(json.sheet.id);
        return json.sheet.id;
      }
      return null;
    } catch {
      return null;
    }
  };

  const deleteSheet = async (id: string): Promise<boolean> => {
    if (!token) return false;
    try {
      const res = await fetch(`/api/sheets/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const remaining = sheets.filter((s) => s.id !== id);
        setSheets(remaining);
        if (remaining.length > 0) {
          setActiveSheetId(remaining[0].id);
        }
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const saveOnboarding = async (payload: {
    incomes: Partial<IncomeSource>[];
    expenses: Partial<Expense>[];
    debts: Partial<Debt>[];
    savings: Partial<SavingsAsset>[];
    goals: Partial<FinancialGoal>[];
  }): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/onboarding`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const addIncome = async (income: Omit<IncomeSource, 'id' | 'sheetId'>): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/incomes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(income),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const deleteIncome = async (id: string): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/incomes/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const addExpense = async (expense: Omit<Expense, 'id' | 'sheetId'>): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/expenses`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(expense),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const deleteExpense = async (id: string): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/expenses/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const addDebt = async (debt: Omit<Debt, 'id' | 'sheetId'>): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/debts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(debt),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const deleteDebt = async (id: string): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/debts/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const addGoal = async (goal: Omit<FinancialGoal, 'id' | 'sheetId'>): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/goals`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(goal),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const updateGoal = async (id: string, updates: Partial<FinancialGoal>): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/goals/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const deleteGoal = async (id: string): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/goals/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const addTransaction = async (tx: Omit<Transaction, 'id' | 'sheetId'>): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/transactions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(tx),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const deleteTransaction = async (id: string): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/transactions/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const setBudget = async (category: string, monthlyLimit: number): Promise<boolean> => {
    if (!token || !activeSheetId) return false;
    try {
      const res = await fetch(`/api/sheets/${activeSheetId}/budgets`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ category, monthlyLimit }),
      });
      if (res.ok) {
        await refreshData();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  return (
    <FinanceContext.Provider
      value={{
        sheets,
        activeSheetId,
        setActiveSheetId,
        data,
        loading,
        refreshData,
        createSheet,
        deleteSheet,
        saveOnboarding,
        addIncome,
        deleteIncome,
        addExpense,
        deleteExpense,
        addDebt,
        deleteDebt,
        addGoal,
        updateGoal,
        deleteGoal,
        addTransaction,
        deleteTransaction,
        setBudget,
        currency,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) throw new Error('useFinance must be used within FinanceProvider');
  return context;
};

import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import {
  User,
  FinancialSheet,
  IncomeSource,
  Expense,
  Debt,
  SavingsAsset,
  FinancialGoal,
  Transaction,
  BudgetLimit,
} from './src/types/finance';
import { buildFinancialProfile, analyzeAffordability } from './src/calculations/financeEngine';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

interface DatabaseSchema {
  users: (User & { passwordHash: string })[];
  sheets: FinancialSheet[];
  incomes: IncomeSource[];
  expenses: Expense[];
  debts: Debt[];
  savings: SavingsAsset[];
  goals: FinancialGoal[];
  transactions: Transaction[];
  budgets: BudgetLimit[];
}

// Ensure database directory & seed initial data
function loadDatabase(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(content);
    } catch (e) {
      console.error('Error reading db.json, re-initializing...', e);
    }
  }

  // Initial Seed for Maya Sharma
  const defaultDb: DatabaseSchema = {
    users: [
      {
        id: 'user-maya-1',
        name: 'Maya Sharma',
        email: 'maya@example.com',
        passwordHash: 'demo123',
        country: 'Nepal',
        currency: 'NPR',
        ageRange: '25-34',
        occupation: 'Product Designer',
        riskTolerance: 'moderate',
        investmentHorizonYears: 7,
        createdAt: '2026-09-01T00:00:00.000Z',
      },
    ],
    sheets: [
      {
        id: 'sheet-maya-personal',
        userId: 'user-maya-1',
        name: 'My Personal Finance',
        type: 'personal',
        description: 'Primary day-to-day income, living costs, and personal goals',
        isDefault: true,
        currency: 'NPR',
        createdAt: '2026-09-01T00:00:00.000Z',
      },
      {
        id: 'sheet-maya-family',
        userId: 'user-maya-1',
        name: 'Family Household Finance',
        type: 'family',
        description: 'Joint family budget, house maintenance, and shared solar roof goal',
        isDefault: false,
        currency: 'NPR',
        membersCount: 3,
        createdAt: '2026-09-15T00:00:00.000Z',
      },
    ],
    incomes: [
      {
        id: 'inc-1',
        sheetId: 'sheet-maya-personal',
        title: 'Lead Designer Salary',
        amount: 80000,
        frequency: 'monthly',
        category: 'salary',
        notes: 'Monthly net direct deposit',
      },
      {
        id: 'inc-2',
        sheetId: 'sheet-maya-personal',
        title: 'UI/UX Freelance & Mentorship',
        amount: 10000,
        frequency: 'monthly',
        category: 'freelance',
        notes: 'Weekend client work',
      },
      // Family Sheet Incomes
      {
        id: 'inc-fam-1',
        sheetId: 'sheet-maya-family',
        title: 'Father Income',
        amount: 80000,
        frequency: 'monthly',
        category: 'salary',
      },
      {
        id: 'inc-fam-2',
        sheetId: 'sheet-maya-family',
        title: 'Mother Income',
        amount: 50000,
        frequency: 'monthly',
        category: 'salary',
      },
      {
        id: 'inc-fam-3',
        sheetId: 'sheet-maya-family',
        title: 'Ground Floor Rental Unit',
        amount: 15000,
        frequency: 'monthly',
        category: 'rental',
      },
    ],
    expenses: [
      {
        id: 'exp-1',
        sheetId: 'sheet-maya-personal',
        title: 'Apartment Rent',
        amount: 18000,
        frequency: 'monthly',
        category: 'housing',
        isFixed: true,
      },
      {
        id: 'exp-2',
        sheetId: 'sheet-maya-personal',
        title: 'Groceries & Farmers Market',
        amount: 12000,
        frequency: 'monthly',
        category: 'food',
        isFixed: false,
      },
      {
        id: 'exp-3',
        sheetId: 'sheet-maya-personal',
        title: 'Fuel & Commute',
        amount: 5000,
        frequency: 'monthly',
        category: 'transportation',
        isFixed: true,
      },
      {
        id: 'exp-4',
        sheetId: 'sheet-maya-personal',
        title: 'Fiber Internet & Utilities',
        amount: 4000,
        frequency: 'monthly',
        category: 'utilities',
        isFixed: true,
      },
      {
        id: 'exp-5',
        sheetId: 'sheet-maya-personal',
        title: 'Dining Out & Specialty Coffee',
        amount: 7000,
        frequency: 'monthly',
        category: 'entertainment',
        isFixed: false,
      },
      {
        id: 'exp-6',
        sheetId: 'sheet-maya-personal',
        title: 'Software, Figma & Cloud Subscriptions',
        amount: 2000,
        frequency: 'monthly',
        category: 'subscriptions',
        isFixed: true,
      },
      // Family Sheet Expenses
      {
        id: 'exp-fam-1',
        sheetId: 'sheet-maya-family',
        title: 'Household Groceries & Provisions',
        amount: 32000,
        frequency: 'monthly',
        category: 'food',
        isFixed: false,
      },
      {
        id: 'exp-fam-2',
        sheetId: 'sheet-maya-family',
        title: 'Home Maintenance & Electricity',
        amount: 14000,
        frequency: 'monthly',
        category: 'housing',
        isFixed: true,
      },
      {
        id: 'exp-fam-3',
        sheetId: 'sheet-maya-family',
        title: 'Family Healthcare & Insurance',
        amount: 12000,
        frequency: 'monthly',
        category: 'healthcare',
        isFixed: true,
      },
    ],
    debts: [
      {
        id: 'debt-1',
        sheetId: 'sheet-maya-personal',
        name: 'Higher Education Loan',
        principal: 200000,
        remainingBalance: 120000,
        interestRate: 8.5,
        monthlyPayment: 5000,
        remainingMonths: 26,
        loanType: 'education',
      },
      // Family Debt
      {
        id: 'debt-fam-1',
        sheetId: 'sheet-maya-family',
        name: 'Property Upgrade Loan',
        principal: 1000000,
        remainingBalance: 450000,
        interestRate: 9.0,
        monthlyPayment: 22000,
        remainingMonths: 24,
        loanType: 'home',
      },
    ],
    savings: [
      {
        id: 'sav-1',
        sheetId: 'sheet-maya-personal',
        type: 'emergency_fund',
        title: 'Emergency Fund (Liquid High-Yield)',
        amount: 60000,
        institution: 'Nabil Bank',
      },
      {
        id: 'sav-2',
        sheetId: 'sheet-maya-personal',
        type: 'bank',
        title: 'Checking & Buffer Reserve',
        amount: 25000,
        institution: 'Global IME Bank',
      },
      // Family Savings
      {
        id: 'sav-fam-1',
        sheetId: 'sheet-maya-family',
        type: 'emergency_fund',
        title: 'Joint Family Emergency Fixed Deposit',
        amount: 220000,
      },
    ],
    goals: [
      {
        id: 'goal-1',
        sheetId: 'sheet-maya-personal',
        name: 'MacBook Pro M3 Max',
        targetAmount: 150000,
        currentAmount: 90000,
        targetDate: '2027-02-28',
        priority: 'high',
        category: 'Electronics',
        monthlyAllocated: 12000,
      },
      {
        id: 'goal-2',
        sheetId: 'sheet-maya-personal',
        name: '6-Month Emergency Reserve (NPR 150k)',
        targetAmount: 150000,
        currentAmount: 60000,
        targetDate: '2027-08-31',
        priority: 'high',
        category: 'Safety',
        monthlyAllocated: 8000,
      },
      {
        id: 'goal-3',
        sheetId: 'sheet-maya-personal',
        name: 'Annapurna Circuit Trek & Gear',
        targetAmount: 50000,
        currentAmount: 18000,
        targetDate: '2027-11-15',
        priority: 'low',
        category: 'Travel',
        monthlyAllocated: 4000,
      },
      // Family Goal
      {
        id: 'goal-fam-1',
        sheetId: 'sheet-maya-family',
        name: 'Residential Solar Power System (5kW)',
        targetAmount: 350000,
        currentAmount: 120000,
        targetDate: '2027-12-31',
        priority: 'medium',
        category: 'Home Upgrade',
        monthlyAllocated: 15000,
      },
    ],
    transactions: [
      {
        id: 'tx-1',
        sheetId: 'sheet-maya-personal',
        amount: 80000,
        type: 'income',
        category: 'salary',
        date: '2026-10-01',
        description: 'Monthly Salary Credit - Tech Corp',
        paymentMethod: 'Bank Transfer',
        isRecurring: true,
      },
      {
        id: 'tx-2',
        sheetId: 'sheet-maya-personal',
        amount: 18000,
        type: 'expense',
        category: 'housing',
        date: '2026-10-02',
        description: 'Apartment Rent Oct 2026',
        paymentMethod: 'Mobile Banking (eSewa)',
        isRecurring: true,
      },
      {
        id: 'tx-3',
        sheetId: 'sheet-maya-personal',
        amount: 5000,
        type: 'expense',
        category: 'debt_payment',
        date: '2026-10-03',
        description: 'Higher Education Loan Auto-Debit',
        paymentMethod: 'Auto Debit',
        isRecurring: true,
      },
      {
        id: 'tx-4',
        sheetId: 'sheet-maya-personal',
        amount: 4200,
        type: 'expense',
        category: 'food',
        date: '2026-10-03',
        description: 'Bhat-Bhateni Organic Supermarket',
        paymentMethod: 'Debit Card',
      },
      {
        id: 'tx-5',
        sheetId: 'sheet-maya-personal',
        amount: 10000,
        type: 'income',
        category: 'freelance',
        date: '2026-10-04',
        description: 'Design Sprint Consultation (Remote)',
        paymentMethod: 'Direct Deposit',
      },
      {
        id: 'tx-6',
        sheetId: 'sheet-maya-personal',
        amount: 2400,
        type: 'expense',
        category: 'entertainment',
        date: '2026-10-04',
        description: 'Dinner with Team @ Himalayan Java',
        paymentMethod: 'QR Pay',
      },
    ],
    budgets: [
      {
        id: 'bgt-1',
        sheetId: 'sheet-maya-personal',
        category: 'food',
        monthlyLimit: 14000,
      },
      {
        id: 'bgt-2',
        sheetId: 'sheet-maya-personal',
        category: 'entertainment',
        monthlyLimit: 8000,
      },
      {
        id: 'bgt-3',
        sheetId: 'sheet-maya-personal',
        category: 'transportation',
        monthlyLimit: 6000,
      },
      {
        id: 'bgt-4',
        sheetId: 'sheet-maya-personal',
        category: 'subscriptions',
        monthlyLimit: 3000,
      },
    ],
  };

  fs.writeFileSync(DB_FILE, JSON.stringify(defaultDb, null, 2), 'utf-8');
  return defaultDb;
}

let db = loadDatabase();

function saveDatabase(): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist database:', err);
  }
}

// Token helper for sessions
function getUserIdFromRequest(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/, '');
  // Token is formatted as: `token_<userId>` or demo token
  if (token.startsWith('token_')) {
    return token.replace('token_', '');
  }
  return token; // fallback to direct id
}

// Middleware to authenticate
function authenticate(req: Request, res: Response, next: NextFunction) {
  const userId = getUserIdFromRequest(req);
  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized. Please sign in.' });
  }
  const user = db.users.find((u) => u.id === userId);
  if (!user) {
    return res.status(401).json({ error: 'User session not found.' });
  }
  (req as any).user = user;
  next();
}

// -------------------------------------------------------------
// API ROUTES
// -------------------------------------------------------------

// Auth: Demo Login
app.post('/api/auth/demo', (req: Request, res: Response) => {
  const user = db.users.find((u) => u.email === 'maya@example.com');
  if (!user) {
    return res.status(404).json({ error: 'Demo user not found' });
  }
  const token = `token_${user.id}`;
  const { passwordHash, ...safeUser } = user;
  res.json({ token, user: safeUser });
});

// Auth: Register
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { name, email, password, country, currency, ageRange, occupation } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  const existing = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: 'An account with this email already exists.' });
  }

  const userId = `user_${Date.now()}`;
  const newUser = {
    id: userId,
    name,
    email: email.toLowerCase(),
    passwordHash: password, // For prototype; hashed in production
    country: country || 'Nepal',
    currency: currency || 'NPR',
    ageRange: ageRange || '25-34',
    occupation: occupation || 'Professional',
    riskTolerance: 'moderate' as const,
    investmentHorizonYears: 5,
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);

  // Create default personal sheet
  const defaultSheet: FinancialSheet = {
    id: `sheet_${Date.now()}`,
    userId,
    name: 'My Personal Finance',
    type: 'personal',
    description: 'Main personal financial plan',
    isDefault: true,
    currency: newUser.currency,
    createdAt: new Date().toISOString(),
  };

  db.sheets.push(defaultSheet);
  saveDatabase();

  const token = `token_${userId}`;
  const { passwordHash, ...safeUser } = newUser;
  res.status(201).json({ token, user: safeUser, defaultSheetId: defaultSheet.id });
});

// Auth: Login
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required.' });
  }

  const user = db.users.find(
    (u) => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === password
  );

  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const token = `token_${user.id}`;
  const { passwordHash, ...safeUser } = user;
  res.json({ token, user: safeUser });
});

// Auth: Get current user
app.get('/api/auth/me', authenticate, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { passwordHash, ...safeUser } = user;
  res.json({ user: safeUser });
});

// Auth: Update Profile
app.put('/api/auth/profile', authenticate, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { name, country, currency, ageRange, occupation, riskTolerance, investmentHorizonYears } = req.body;

  if (name) user.name = name;
  if (country) user.country = country;
  if (currency) user.currency = currency;
  if (ageRange) user.ageRange = ageRange;
  if (occupation !== undefined) user.occupation = occupation;
  if (riskTolerance) user.riskTolerance = riskTolerance;
  if (investmentHorizonYears) user.investmentHorizonYears = Number(investmentHorizonYears);

  saveDatabase();
  const { passwordHash, ...safeUser } = user;
  res.json({ user: safeUser });
});

// -------------------------------------------------------------
// FINANCIAL SHEETS
// -------------------------------------------------------------

// List user sheets
app.get('/api/sheets', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const userSheets = db.sheets.filter((s) => s.userId === userId);
  res.json({ sheets: userSheets });
});

// Create new sheet
app.post('/api/sheets', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const { name, type, description, currency, membersCount } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Sheet name is required.' });
  }

  const newSheet: FinancialSheet = {
    id: `sheet_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    name,
    type: type || 'personal',
    description: description || '',
    isDefault: false,
    currency: currency || (req as any).user.currency || 'NPR',
    membersCount: membersCount ? Number(membersCount) : undefined,
    createdAt: new Date().toISOString(),
  };

  db.sheets.push(newSheet);
  saveDatabase();
  res.status(201).json({ sheet: newSheet });
});

// Delete sheet
app.delete('/api/sheets/:id', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;

  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) {
    return res.status(404).json({ error: 'Sheet not found.' });
  }

  if (sheet.isDefault) {
    return res.status(400).json({ error: 'Cannot delete primary default sheet.' });
  }

  // Remove sheet and associated sub-records
  db.sheets = db.sheets.filter((s) => s.id !== sheetId);
  db.incomes = db.incomes.filter((i) => i.sheetId !== sheetId);
  db.expenses = db.expenses.filter((e) => e.sheetId !== sheetId);
  db.debts = db.debts.filter((d) => d.sheetId !== sheetId);
  db.savings = db.savings.filter((s) => s.sheetId !== sheetId);
  db.goals = db.goals.filter((g) => g.sheetId !== sheetId);
  db.transactions = db.transactions.filter((t) => t.sheetId !== sheetId);
  db.budgets = db.budgets.filter((b) => b.sheetId !== sheetId);

  saveDatabase();
  res.json({ success: true, message: 'Sheet removed.' });
});

// Get comprehensive data for a sheet
app.get('/api/sheets/:id/data', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;

  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) {
    return res.status(404).json({ error: 'Sheet not found.' });
  }

  const incomes = db.incomes.filter((i) => i.sheetId === sheetId);
  const expenses = db.expenses.filter((e) => e.sheetId === sheetId);
  const debts = db.debts.filter((d) => d.sheetId === sheetId);
  const savings = db.savings.filter((s) => s.sheetId === sheetId);
  const goals = db.goals.filter((g) => g.sheetId === sheetId);
  const transactions = db.transactions.filter((t) => t.sheetId === sheetId);
  const budgets = db.budgets.filter((b) => b.sheetId === sheetId);

  const profile = buildFinancialProfile({
    incomes,
    expenses,
    debts,
    savings,
    goals,
  });

  res.json({
    sheet,
    incomes,
    expenses,
    debts,
    savings,
    goals,
    transactions,
    budgets,
    profile,
  });
});

// Onboarding submission: batch save initial data
app.post('/api/sheets/:id/onboarding', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;

  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) {
    return res.status(404).json({ error: 'Sheet not found.' });
  }

  const { incomes, expenses, debts, savings, goals } = req.body;

  if (Array.isArray(incomes)) {
    db.incomes = db.incomes.filter((i) => i.sheetId !== sheetId);
    incomes.forEach((item) => {
      db.incomes.push({
        id: `inc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        sheetId,
        title: item.title || 'Income Source',
        amount: Number(item.amount) || 0,
        frequency: item.frequency || 'monthly',
        category: item.category || 'salary',
        notes: item.notes,
      });
    });
  }

  if (Array.isArray(expenses)) {
    db.expenses = db.expenses.filter((e) => e.sheetId !== sheetId);
    expenses.forEach((item) => {
      db.expenses.push({
        id: `exp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        sheetId,
        title: item.title || 'Expense',
        amount: Number(item.amount) || 0,
        frequency: item.frequency || 'monthly',
        category: item.category || 'other',
        isFixed: Boolean(item.isFixed),
        notes: item.notes,
      });
    });
  }

  if (Array.isArray(debts)) {
    db.debts = db.debts.filter((d) => d.sheetId !== sheetId);
    debts.forEach((item) => {
      db.debts.push({
        id: `debt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        sheetId,
        name: item.name || 'Loan',
        principal: Number(item.principal) || 0,
        remainingBalance: Number(item.remainingBalance) || 0,
        interestRate: Number(item.interestRate) || 0,
        monthlyPayment: Number(item.monthlyPayment) || 0,
        remainingMonths: Number(item.remainingMonths) || 12,
        loanType: item.loanType || 'personal',
      });
    });
  }

  if (Array.isArray(savings)) {
    db.savings = db.savings.filter((s) => s.sheetId !== sheetId);
    savings.forEach((item) => {
      db.savings.push({
        id: `sav_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        sheetId,
        type: item.type || 'bank',
        title: item.title || 'Savings',
        amount: Number(item.amount) || 0,
        institution: item.institution,
      });
    });
  }

  if (Array.isArray(goals)) {
    db.goals = db.goals.filter((g) => g.sheetId !== sheetId);
    goals.forEach((item) => {
      db.goals.push({
        id: `goal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        sheetId,
        name: item.name || 'Goal',
        targetAmount: Number(item.targetAmount) || 0,
        currentAmount: Number(item.currentAmount) || 0,
        targetDate: item.targetDate || '2027-12-31',
        priority: item.priority || 'medium',
        category: item.category || 'General',
        monthlyAllocated: Number(item.monthlyAllocated) || 0,
      });
    });
  }

  saveDatabase();
  res.json({ success: true, message: 'Onboarding data saved successfully.' });
});

// Income: Add or Delete
app.post('/api/sheets/:id/incomes', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;
  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) return res.status(404).json({ error: 'Sheet not found.' });

  const { title, amount, frequency, category, notes } = req.body;
  if (!title || amount === undefined) {
    return res.status(400).json({ error: 'Title and amount required.' });
  }

  const newIncome: IncomeSource = {
    id: `inc_${Date.now()}`,
    sheetId,
    title,
    amount: Number(amount),
    frequency: frequency || 'monthly',
    category: category || 'salary',
    notes,
  };

  db.incomes.push(newIncome);
  saveDatabase();
  res.status(201).json({ income: newIncome });
});

app.delete('/api/sheets/:id/incomes/:incomeId', authenticate, (req: Request, res: Response) => {
  const { id: sheetId, incomeId } = req.params;
  db.incomes = db.incomes.filter((i) => !(i.sheetId === sheetId && i.id === incomeId));
  saveDatabase();
  res.json({ success: true });
});

// Expenses: Add or Delete
app.post('/api/sheets/:id/expenses', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;
  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) return res.status(404).json({ error: 'Sheet not found.' });

  const { title, amount, frequency, category, isFixed, notes } = req.body;
  if (!title || amount === undefined) {
    return res.status(400).json({ error: 'Title and amount required.' });
  }

  const newExpense: Expense = {
    id: `exp_${Date.now()}`,
    sheetId,
    title,
    amount: Number(amount),
    frequency: frequency || 'monthly',
    category: category || 'other',
    isFixed: Boolean(isFixed),
    notes,
  };

  db.expenses.push(newExpense);
  saveDatabase();
  res.status(201).json({ expense: newExpense });
});

app.delete('/api/sheets/:id/expenses/:expenseId', authenticate, (req: Request, res: Response) => {
  const { id: sheetId, expenseId } = req.params;
  db.expenses = db.expenses.filter((e) => !(e.sheetId === sheetId && e.id === expenseId));
  saveDatabase();
  res.json({ success: true });
});

// Debts: Add or Delete
app.post('/api/sheets/:id/debts', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;
  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) return res.status(404).json({ error: 'Sheet not found.' });

  const { name, principal, remainingBalance, interestRate, monthlyPayment, remainingMonths, loanType } = req.body;
  if (!name || remainingBalance === undefined || monthlyPayment === undefined) {
    return res.status(400).json({ error: 'Name, remaining balance, and monthly payment required.' });
  }

  const newDebt: Debt = {
    id: `debt_${Date.now()}`,
    sheetId,
    name,
    principal: Number(principal || remainingBalance),
    remainingBalance: Number(remainingBalance),
    interestRate: Number(interestRate || 0),
    monthlyPayment: Number(monthlyPayment),
    remainingMonths: Number(remainingMonths || 12),
    loanType: loanType || 'personal',
  };

  db.debts.push(newDebt);
  saveDatabase();
  res.status(201).json({ debt: newDebt });
});

app.delete('/api/sheets/:id/debts/:debtId', authenticate, (req: Request, res: Response) => {
  const { id: sheetId, debtId } = req.params;
  db.debts = db.debts.filter((d) => !(d.sheetId === sheetId && d.id === debtId));
  saveDatabase();
  res.json({ success: true });
});

// Goals: Add, Update, Delete
app.post('/api/sheets/:id/goals', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;
  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) return res.status(404).json({ error: 'Sheet not found.' });

  const { name, targetAmount, currentAmount, targetDate, priority, category, monthlyAllocated } = req.body;
  if (!name || targetAmount === undefined) {
    return res.status(400).json({ error: 'Name and target amount required.' });
  }

  const newGoal: FinancialGoal = {
    id: `goal_${Date.now()}`,
    sheetId,
    name,
    targetAmount: Number(targetAmount),
    currentAmount: Number(currentAmount || 0),
    targetDate: targetDate || '2027-12-31',
    priority: priority || 'medium',
    category: category || 'General',
    monthlyAllocated: Number(monthlyAllocated || 0),
  };

  db.goals.push(newGoal);
  saveDatabase();
  res.status(201).json({ goal: newGoal });
});

app.put('/api/sheets/:id/goals/:goalId', authenticate, (req: Request, res: Response) => {
  const { id: sheetId, goalId } = req.params;
  const goal = db.goals.find((g) => g.sheetId === sheetId && g.id === goalId);
  if (!goal) return res.status(404).json({ error: 'Goal not found.' });

  const { currentAmount, monthlyAllocated, targetAmount, targetDate } = req.body;
  if (currentAmount !== undefined) goal.currentAmount = Number(currentAmount);
  if (monthlyAllocated !== undefined) goal.monthlyAllocated = Number(monthlyAllocated);
  if (targetAmount !== undefined) goal.targetAmount = Number(targetAmount);
  if (targetDate) goal.targetDate = targetDate;

  saveDatabase();
  res.json({ goal });
});

app.delete('/api/sheets/:id/goals/:goalId', authenticate, (req: Request, res: Response) => {
  const { id: sheetId, goalId } = req.params;
  db.goals = db.goals.filter((g) => !(g.sheetId === sheetId && g.id === goalId));
  saveDatabase();
  res.json({ success: true });
});

// Transactions: Add, List, Delete
app.post('/api/sheets/:id/transactions', authenticate, (req: Request, res: Response) => {
  const userId = (req as any).user.id;
  const sheetId = req.params.id;
  const sheet = db.sheets.find((s) => s.id === sheetId && s.userId === userId);
  if (!sheet) return res.status(404).json({ error: 'Sheet not found.' });

  const { amount, type, category, date, description, paymentMethod, isRecurring } = req.body;
  if (!amount || !description) {
    return res.status(400).json({ error: 'Amount and description required.' });
  }

  const newTx: Transaction = {
    id: `tx_${Date.now()}`,
    sheetId,
    amount: Number(amount),
    type: type || 'expense',
    category: category || 'other',
    date: date || new Date().toISOString().split('T')[0],
    description,
    paymentMethod: paymentMethod || 'Cash',
    isRecurring: Boolean(isRecurring),
  };

  db.transactions.unshift(newTx);
  saveDatabase();
  res.status(201).json({ transaction: newTx });
});

app.delete('/api/sheets/:id/transactions/:txId', authenticate, (req: Request, res: Response) => {
  const { id: sheetId, txId } = req.params;
  db.transactions = db.transactions.filter((t) => !(t.sheetId === sheetId && t.id === txId));
  saveDatabase();
  res.json({ success: true });
});

// Budgets: Set category limit
app.post('/api/sheets/:id/budgets', authenticate, (req: Request, res: Response) => {
  const { id: sheetId } = req.params;
  const { category, monthlyLimit } = req.body;

  if (!category || monthlyLimit === undefined) {
    return res.status(400).json({ error: 'Category and monthly limit required.' });
  }

  const existing = db.budgets.find((b) => b.sheetId === sheetId && b.category === category);
  if (existing) {
    existing.monthlyLimit = Number(monthlyLimit);
  } else {
    db.budgets.push({
      id: `bgt_${Date.now()}`,
      sheetId,
      category,
      monthlyLimit: Number(monthlyLimit),
    });
  }

  saveDatabase();
  res.json({ success: true, budgets: db.budgets.filter((b) => b.sheetId === sheetId) });
});

// -------------------------------------------------------------
// AI FINANCIAL COACH & INTELLIGENT ADVISOR
// -------------------------------------------------------------

app.post('/api/ai/coach', authenticate, async (req: Request, res: Response) => {
  const { message, sheetId } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'Message is required.' });
  }

  const userId = (req as any).user.id;
  const user = (req as any).user as User;

  // Build clean financial context for this user and sheet
  const targetSheetId = sheetId || db.sheets.find((s) => s.userId === userId && s.isDefault)?.id;
  const incomes = db.incomes.filter((i) => i.sheetId === targetSheetId);
  const expenses = db.expenses.filter((e) => e.sheetId === targetSheetId);
  const debts = db.debts.filter((d) => d.sheetId === targetSheetId);
  const savings = db.savings.filter((s) => s.sheetId === targetSheetId);
  const goals = db.goals.filter((g) => g.sheetId === targetSheetId);

  const profile = buildFinancialProfile({ incomes, expenses, debts, savings, goals });

  const financialContext = {
    userName: user.name,
    currency: user.currency || 'NPR',
    riskProfile: user.riskTolerance || 'moderate',
    totalMonthlyIncome: profile.totalMonthlyIncome,
    totalMonthlyExpenses: profile.totalMonthlyExpenses,
    totalMonthlyDebt: profile.totalMonthlyDebt,
    monthlySurplus: profile.monthlySurplus,
    savingsRatePct: profile.savingsRate,
    emergencyFundCoverageMonths: profile.emergencyFundCoverageMonths,
    healthScore: profile.healthScore.overall,
    healthStatus: profile.healthScore.status,
    activeGoals: goals.map((g) => ({
      name: g.name,
      target: g.targetAmount,
      saved: g.currentAmount,
      targetDate: g.targetDate,
    })),
    debtsSummary: debts.map((d) => ({
      name: d.name,
      monthlyPayment: d.monthlyPayment,
      remaining: d.remainingBalance,
      rate: d.interestRate,
    })),
  };

  const systemInstruction = `You are "Money AI", a world-class certified financial planning coach and educator.
The user's real, verified financial profile is:
- Name: ${financialContext.userName}
- Currency: ${financialContext.currency}
- Total Monthly Income: ${financialContext.currency} ${financialContext.totalMonthlyIncome.toLocaleString()}
- Monthly Living Expenses: ${financialContext.currency} ${financialContext.totalMonthlyExpenses.toLocaleString()}
- Monthly Debt Obligations: ${financialContext.currency} ${financialContext.totalMonthlyDebt.toLocaleString()}
- Calculated Net Monthly Surplus: ${financialContext.currency} ${financialContext.monthlySurplus.toLocaleString()}
- Savings Rate: ${financialContext.savingsRatePct.toFixed(1)}%
- Emergency Fund: ${financialContext.emergencyFundCoverageMonths} months of essential expenses
- Financial Health Score: ${financialContext.healthScore}/100 (${financialContext.healthStatus})
- Active Goals: ${JSON.stringify(financialContext.activeGoals)}
- Active Debts: ${JSON.stringify(financialContext.debtsSummary)}

CRITICAL FINANCIAL SAFETY & ETHICAL RULES:
1. Always base answers strictly on the mathematical numbers provided above. Never invent or hallucinate different financial figures.
2. NEVER give guaranteed investment advice or say "Buy X to make money".
3. Always frame investment options as educational scenarios ("Based on your numbers, researching low-cost index funds or regular SIP may align with your moderate risk tolerance, considering risks, fees, liquidity, and time horizon.").
4. If asked about a purchase ("Can I afford X?"), clearly break down the impact on their monthly surplus (${financialContext.currency} ${financialContext.monthlySurplus.toLocaleString()}) and emergency reserve (${financialContext.emergencyFundCoverageMonths} months).
5. All future projections must explicitly state: "Illustrative projection — not guaranteed. Actual returns will vary."
6. Keep answers structured, empathetic, concise, and actionable with clear next steps.`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: message,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const reply = response.text || 'I analyzed your financial data and am ready to assist.';
      return res.json({ reply });
    }
  } catch (error) {
    console.warn('Gemini API call failed or not configured, using smart deterministic coach:', error);
  }

  // Smart Deterministic Fallback Coach
  const msgLower = message.toLowerCase();
  let fallbackReply = '';

  if (msgLower.includes('save') && msgLower.includes('month')) {
    fallbackReply = `Based on your verified numbers, your total monthly income is ${financialContext.currency} ${financialContext.totalMonthlyIncome.toLocaleString()} and your committed expenses plus debt total ${financialContext.currency} ${(financialContext.totalMonthlyExpenses + financialContext.totalMonthlyDebt).toLocaleString()}.

This leaves you with an uncommitted monthly surplus of **${financialContext.currency} ${financialContext.monthlySurplus.toLocaleString()}** (a ${financialContext.savingsRatePct.toFixed(1)}% savings rate).

💡 **Coach Recommendation:**
- Target putting **50% of your surplus (${financialContext.currency} ${Math.round(financialContext.monthlySurplus * 0.5).toLocaleString()})** toward strengthening your emergency fund until you reach 6 months of expenses.
- Route the remaining **${financialContext.currency} ${Math.round(financialContext.monthlySurplus * 0.5).toLocaleString()}** directly to your active goals.`;
  } else if (msgLower.includes('laptop') || msgLower.includes('afford')) {
    const analysis = analyzeAffordability(150000, profile);
    fallbackReply = `### Can I Afford This Purchase?

**Verdict:** **${analysis.verdictTitle}**

${analysis.reason}

**Financial Impact Breakdown:**
- Current Monthly Surplus: ${financialContext.currency} ${profile.monthlySurplus.toLocaleString()}
- Emergency Buffer Coverage: ${profile.emergencyFundCoverageMonths} months
- Estimated Goal Delay: ~${analysis.details.goalDelayEstimateMonths} months

**Recommended Action:**
${analysis.recommendations.map((r) => `- ${r}`).join('\n')}`;
  } else if (msgLower.includes('sip') || msgLower.includes('invest')) {
    fallbackReply = `### Exploring Regular SIP & Investing

Based on your current financial health score of **${profile.healthScore.overall}/100** and **${profile.emergencyFundCoverageMonths} months** of emergency reserves:

1. **Safety First:** We recommend keeping at least 3-6 months of expenses in a liquid high-yield account before taking on market volatility.
2. **SIP Allocation:** With your monthly surplus of ${financialContext.currency} ${profile.monthlySurplus.toLocaleString()}, starting a modest SIP of ${financialContext.currency} 5,000 to 10,000 monthly is mathematically comfortable without squeezing daily life.
3. **Illustrative Projection:** At an illustrative 10% annual return over 10 years, a ${financialContext.currency} 5,000 monthly contribution totals ${financialContext.currency} 600,000 invested with an estimated future value of ~${financialContext.currency} 1,024,000.
*(Note: Illustrative projection only — not guaranteed. Investments carry market risk.)*`;
  } else {
    fallbackReply = `Hello ${user.name}! I am reviewing your **${financialContext.currency}** financial plan.

**Snapshot:**
- Monthly Income: **${financialContext.currency} ${profile.totalMonthlyIncome.toLocaleString()}**
- Free Monthly Surplus: **${financialContext.currency} ${profile.monthlySurplus.toLocaleString()}**
- Emergency Cushion: **${profile.emergencyFundCoverageMonths} months** (${profile.healthScore.status} status)
- Financial Health Score: **${profile.healthScore.overall}/100**

How would you like to optimize your plan today? Ask me about:
1. *"Can I afford a NPR 100,000 purchase?"*
2. *"How long to reach my emergency goal?"*
3. *"What happens if my rent increases?"*
4. *"Simulate a monthly SIP investment"*`;
  }

  res.json({ reply: fallbackReply });
});

// AI Monthly Review Endpoint
app.post('/api/ai/monthly-review', authenticate, async (req: Request, res: Response) => {
  const { sheetId } = req.body;
  const userId = (req as any).user.id;
  const targetSheetId = sheetId || db.sheets.find((s) => s.userId === userId && s.isDefault)?.id;

  const incomes = db.incomes.filter((i) => i.sheetId === targetSheetId);
  const expenses = db.expenses.filter((e) => e.sheetId === targetSheetId);
  const debts = db.debts.filter((d) => d.sheetId === targetSheetId);
  const savings = db.savings.filter((s) => s.sheetId === targetSheetId);
  const goals = db.goals.filter((g) => g.sheetId === targetSheetId);

  const profile = buildFinancialProfile({ incomes, expenses, debts, savings, goals });

  const review = {
    monthName: 'October 2026',
    incomeTotal: profile.totalMonthlyIncome,
    expensesTotal: profile.totalMonthlyExpenses,
    surplusTotal: profile.monthlySurplus,
    savingsRate: profile.savingsRate,
    healthScore: profile.healthScore.overall,
    whatWentWell: [
      `Maintained a solid ${profile.savingsRate.toFixed(1)}% savings rate, putting you ahead of typical peers.`,
      `Debt obligations kept under control at ${profile.debtToIncomeRatio.toFixed(1)}% of total earnings.`,
      `Active progress recorded on ${goals.length} primary financial milestones.`,
    ],
    watchOut: [
      profile.emergencyFundCoverageMonths < 6
        ? `Emergency reserve currently sits at ${profile.emergencyFundCoverageMonths} months. Increasing this toward 6 months will significantly enhance risk resilience.`
        : 'Variable dining and discretionary expenses should be monitored against monthly budget caps.',
      'Ensure upcoming recurring bill dates align with primary income salary cycles.',
    ],
    nextMonthStrategy: [
      `Automate a transfer of at least 50% of your ${profile.monthlySurplus.toLocaleString()} surplus right on payday.`,
      'Review subscription services to eliminate unused monthly recurring fees.',
    ],
  };

  res.json({ review });
});

// -------------------------------------------------------------
// FRONTEND INTEGRATION (Dev vs Production)
// -------------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`FinPulse AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
